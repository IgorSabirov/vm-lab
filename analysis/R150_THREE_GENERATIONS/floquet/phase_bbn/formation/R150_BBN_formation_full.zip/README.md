# R150, CCC+TL и формирование ядер

Два полных разбора в порядке исследования.

1. [Две границы и взаимное формирование](floquet/phase_bbn/formation/README.md). Геометрия фаз A и B, конечная модель, прямое и обратное действие, когерентное считывание, постотбор и границы переноса в ядерную сеть. Рядом лежат программа, численный эталон и исходный исследовательский текст.
2. [Оператор контакта и сборка ядер во времени](floquet/phase_bbn/formation/response_audit/README.md). Вывод знака для C, четыре управления связью, проверка базиса, поправка к бюджету реликта, архивная история CONTROL и время, доступное графу для перестройки. Исходный Markdown содержит все десять блоков и авторский вывод.

Из корня распакованного комплекта выполните команды Python 3 с NumPy и SciPy. Для рисунка нужен Matplotlib.

```sh
python floquet/phase_bbn/formation/check.py > formation.replayed.json
python floquet/phase_bbn/formation/response_audit/audit.py > response.replayed.json
python floquet/phase_bbn/formation/response_audit/extract.py floquet/phase_bbn/formation/response_audit/input.md recovered_cells
python floquet/phase_bbn/formation/response_audit/figure.py
```

Ожидаемые численные таблицы записаны в results.json возле каждой программы. Четвёртый исходный блок останавливается при попытке найти конечный корень для контраста 1/2. Остальные девять завершаются. В SHA256SUMS указаны контрольные суммы всех остальных файлов. Ссылки на дополнительные разделы корпуса в первом отчёте разрешаются в [репозитории](https://github.com/IgorSabirov/vm-lab/tree/45f34fce881d5860b918fff2001bbd149a788a5b/analysis/R150_THREE_GENERATIONS/floquet/phase_bbn/formation).

Физическая амплитуда контакта и отображение на прямые и обратные скорости ядерной сети остаются открытыми. Траектория CONTROL описывает базовую сеть. Значения сдвига итоговых D/H и массовой доли гелия от взаимодействия с R150 в этих двух работах не вычислялись.
