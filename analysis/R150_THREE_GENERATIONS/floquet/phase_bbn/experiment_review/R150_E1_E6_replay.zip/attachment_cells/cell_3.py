import math
hbar=6.582119569e-16; Mpl=1.22089e28
def Hs(T,gs=3.36): return 1.66*math.sqrt(gs)*(T*1e6)**2/Mpl/hbar
Q=1.293332; BD=2.224566; taun=879.4; sig=0.0013
t_nuc=1/(2*Hs(0.07)); t_f=1/(2*Hs(0.7,10.75)); dt=t_nuc-t_f
r=1/7; k=(2/(1+r)**2)*r
print("=== ЦЕЛЕВОЕ ЧИСЛО ДЛЯ ШАГА 2: требуемое подавление ванны ===")
print("  Gamma_r = nu * |M|^2 * bath ;  nu = 1/tau_tick ;  tau_tick = hbar/J  =>  nu = J/hbar")
for L,J,M2,lab in [(7,0.1186,0.308179,"Z_seam (опубликовано)"),(7,0.1186,0.078544,"V_merge (вершина правила)"),
                   (7,0.2278,0.078544,"V_merge, J=J_max(106.75)"),(9,0.2206,0.078544,"L=9"),(3,0.0072,0.078544,"L=3")]:
    om=J*1e6/hbar; G=om*M2; H=Hs(0.08)
    Sreq=math.log(G/H)
    print(f"  L={L:2d} J={J:.4f} {lab:28s}: Gamma/H={G/H:.3e}  S_req=ln(Gamma/H)={Sreq:.2f}  => DeltaE=S_req*T={Sreq*0.08:.3f} МэВ")
print()
print("  T_frz при ФИКСИРОВАННОМ зазоре DeltaE (S=DeltaE/T): решение Gamma=H")
from scipy.optimize import brentq
for dE in (2.0,4.0,4.01,6.0):
    J=0.1186; M2=0.078544; om=J*1e6/hbar
    f=lambda T: math.log(om*M2)-dE/T-math.log(Hs(T,10.75 if T>0.4 else 3.36))
    Tf=brentq(f,0.01,3.0)
    print(f"    DeltaE={dE:4.2f} МэВ -> T_frz={Tf:.4f} МэВ   (дейтронное горло 0.07-0.08)")
print()
print("=== ПОЛНЫЙ КОРРЕЛИРОВАННЫЙ ВЕКТОР: оба шаблона ===")
for nm,R,S in [("Unification",36.,160.),("Dilaton",109.4,0.)]:
    cBD=-6.5*(1+S)+18*R; cQ=0.1+0.7*S-0.6*R; ctau=-0.2-2.0*S+3.8*R; cG=1.6*R+0.4*(1+S)
    bd=7.7e-3; da=(bd/BD)/cBD
    parts={"B_D":k*(dt/taun)*2*1.057*(bd/BD),
           "Q_np":k*(-1/0.7)*(cQ*da*Q),
           "tau_n":k*(dt/taun)*(ctau*da),
           "G_N":k*((Q/0.7)/3+(dt/taun))*0.5*(cG*da)}
    tot=sum(parts.values()); two=parts["B_D"]+parts["Q_np"]
    print(f"  {nm:12s}: "+"  ".join(f"{a}={b/sig:+.3f}s" for a,b in parts.items()))
    print(f"                 2 канала={two/sig:+.3f}sigma  4 канала={tot/sig:+.3f}sigma  поправка={100*(tot/two-1):+.1f}%")
print()
print("=== Паули против Аррениуса: показатель n в Gamma ~ T^n ===")
print("  Gamma/H ~ T^(n-2):  n<=2 -> нет замерзания (шов всегда равновесен, памяти нет)")
print("                     n>2  -> T_frz существует")
for n in (1,2,3,5):
    print(f"   n={n}: Gamma/H ~ T^{n-2}  {'НЕТ замерзания' if n<=2 else 'замерзание есть'}")