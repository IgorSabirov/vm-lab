import numpy as np, math
# --- точная копия word_rule.py ---
def interact_word(x, eps=(1,-1), trace=None):
    split={3 << (2*c): ((1 << (2*c), 2 << (2*c)) if e==1 else (2 << (2*c),1 << (2*c))) for c,e in enumerate(eps)}
    merge={v:k for k,v in split.items()}
    n=len(x)
    starts={i for i in range(n) if n>1 and (x[i],x[(i+1)%n]) in merge}
    ends={(i+1)%n for i in starts}
    start=next(i for i in range(n) if i not in ends)
    out=[]; k=0
    while k<n:
        i=(start+k)%n; s=x[i]
        if i in starts:
            ev=("merge",(s,x[(i+1)%n]),i)
            if trace is not None: trace.append(ev)
            out.append(merge[(s,x[(i+1)%n])]); k+=2
        elif s in split:
            if trace is not None: trace.append(("split",s,i))
            out.extend(split[s]); k+=1
        else:
            out.append(s); k+=1
    return tuple(out)
def transport_word(x, channels=2):
    a=sum(1 << (2*c) for c in range(channels)); b=2*a
    return tuple((s & b) | (x[(i+1)%len(x)] & a) for i,s in enumerate(x))
def F_word(x): return transport_word(interact_word(x))
def state_to_word(key,L):
    x2,x3,x4=key; m=[0]*L
    for pos,bit in [(0,1),(x2,2),(x3,4),(x4,8)]: m[pos]|=bit
    return tuple(m)
def word_to_state(w):
    pos={}
    for bit in (1,2,4,8):
        p=[i for i,s in enumerate(w) if s&bit]
        if len(p)!=1: return None
        pos[bit]=p[0]
    p1=pos[1]; return tuple((pos[b]-p1)%len(w) for b in (2,4,8))

print("=== ЛОКАЛИЗАЦИЯ СОБЫТИЙ НА ОРБИТАХ (какое событие на каком ребре) ===")
for L in (3,5,7,9,15):
    u,v=(L+1)//2,(L-1)//2
    order=[0,*range(2,L)]
    rows=[]
    for t in range(L):
        key=(t,u,(t+v)%L); w=state_to_word(key,L)
        tr=[]; iw=interact_word(w,trace=tr); out=word_to_state(F_word(w))
        t2=out[0]
        rows.append((t,t2,tr))
    # сверка с графом
    ok=all(t2==order[(order.index(t)+1)%(L-1)] if t!=1 else t2==1 for t,t2,_ in rows)
    merges=[(t,t2,e) for t,t2,tr in rows for e in tr if e[0]=="merge" and e[1]==(8,4)]
    splits=[(t,t2,e) for t,t2,tr in rows for e in tr if e[0]=="split" and e[1]==12]
    print(f" L={L:2d}: орбита совпадает с графом={ok} | merge(8,4)->12 на ребре {[(a,b) for a,b,_ in merges]} | split 12->(8,4) на ребре {[(a,b) for a,b,_ in splits]}")