import numpy as np, math
from scipy.special import expit
def graph(L,phi):
    n=L-1; order=[0,*range(2,L)]
    step=np.zeros((L,L),complex); step[1,1]=1
    h=-1 if phi==np.pi else np.exp(1j*phi)
    for j,t in enumerate(order): step[order[(j+1)%n],t]=h if j==n-1 else 1
    ph=np.r_[0,(phi+2*np.pi*np.arange(n))/n]
    B=np.zeros_like(step); B[1,0]=1
    for j,t in enumerate(order): B[t,1:]=np.exp(-1j*j*ph[1:])/math.sqrt(n)
    return step,B,ph
L=7;x=4.0
F,V0,p0=graph(L,0); G,Vp,pp=graph(L,np.pi)
E0=-x*np.cos(p0); Ep=-x*np.cos(pp)
Sth=np.array([[expit(E0[i]-Ep[j]) for i in range(L)] for j in range(L)])
def haz(V): return (np.abs(Vp.conj().T@V@V0)**2*Sth).sum(axis=0)
idx=[0,1,1+(L-1)//2]
Zclose=np.eye(L); Zclose[L-1,L-1]=-1                 # калибровка графа: минус на замыкающем ребре
Vmerge=np.zeros((L,L)); Vmerge[2,0]=1; Vmerge[0,2]=1 # ФИЗИЧЕСКАЯ вершина: ребро слияния 0->2
Vhop=np.zeros((L,L)); Vhop[0,L-1]=1; Vhop[L-1,0]=1   # хоп по ребру шва (прошлый контроль)
print("=== ГОЛОВНОЙ ТЕСТ: вершина на ребре СЛИЯНИЯ против Z на замыкающем ребре ===")
for nm,V in [("Z_seam (замыкающее ребро)",Zclose),("V_merge (ребро слияния 0->2)",Vmerge),("hop по ребру шва",Vhop)]:
    h=haz(V); print(f"  {nm:30s} hazard(фикс,равн,знак)={np.round(h[idx],6)}  sum={h.sum():.4f}")
# калибровочное преобразование, переносящее минус с ребра слияния на замыкающее
D=np.ones(L); D[2:]=-1
Fm=F.copy(); Fm[2,0]=-1                              # правило слов: минус на слиянии
print("\n  D F_rule D^dag == F_pi(граф) ?", np.allclose(np.diag(D)@Fm@np.diag(D), G))
print("  голономия цикла: правило=",np.prod([Fm[2,0]]+[1]*(L-2))," граф=",np.prod([G[0,L-1]]+[1]*(L-2)))
print("  => одно и то же Z2-расслоение в РАЗНЫХ калибровках; вершина физически на ребре 0->2")
print()
print("=== СОГЛАСОВАННЫЕ РЫЧАГИ Y_p ===")
Q=1.293332; BD=2.224566; taun=879.4; Mpl=1.22089e28; hbar=6.582119569e-16
def Hs(T,gs): return 1.66*math.sqrt(gs)*(T*1e6)**2/Mpl/hbar
t_nuc=1/(2*Hs(0.07,3.36)); t_f=1/(2*Hs(0.7,10.75)); dt=t_nuc-t_f
dec=math.exp(-dt/taun)
for Tf in (0.700,0.788):
    rf=math.exp(-Q/Tf); r=rf*dec; Yp=2*r/(1+r); dYdr=2/(1+r)**2
    lQ=dYdr*r*(-1/Tf)*1e-3
    lBD=dYdr*r*(dt/taun)*2*1.057/BD*1e-3
    print(f"  Tf={Tf:.3f}: r_final=1/{1/r:.2f}  Y_p={Yp:.4f}  lever_Q={lQ:.3e}  lever_BD={lBD:.3e}  ratio={abs(lQ/lBD):.2f}")
print(f"  (их вход: r=1/7, Y_p=0.2500, lever_Q=-3.125e-4, lever_BD=6.370e-5, ratio=4.91)")
rf=math.exp(-Q/0.7); print(f"  мгновенное замерзание при Tf=0.7 даёт r=1/{1/(rf*dec):.2f}, Y_p={2*rf*dec/(1+rf*dec):.4f} — на {100*(1-2*rf*dec/(1+rf*dec)/0.247):.0f}% ниже наблюдаемого")
print()
lQ=-3.125e-4; lBD=6.370e-5; sig=0.0013
print("=== СЛЕПАЯ ТОЧКА И ПОРОГ 2 sigma ПО ОТНОШЕНИЮ rho = dQ/dB_D ===")
print(f"  rho* (dY_p=0) = -lever_BD/lever_Q = {-lBD/lQ:+.4f}")
for bd in (1.0,7.7):
    need=2*sig
    rho_minus=(need/bd-lBD)/lQ; rho_plus=(-need/bd-lBD)/lQ
    print(f"  dBD={bd:4.1f} кэВ: |dY_p|>=2sigma при rho <= {rho_minus:+.3f} или rho >= {rho_plus:+.3f}")
print()
print("=== ПРОПУЩЕННЫЕ КАНАЛЫ ТОГО ЖЕ ОПЕРАТОРА (шаблон R=36,S=160) ===")
R,S=36.,160.
cBD=-6.5*(1+S)+18*R; cQ=0.1+0.7*S-0.6*R; ctau=-0.2-2.0*S+3.8*R; cG=1.6*R+0.4*(1+S); cme=0.5*(1+S)
bd=7.7e-3  # МэВ
da=(bd/BD)/cBD
r=1/7; dYdr=2/(1+r)**2; k=dYdr*r
dY_Q=k*(-1/0.7)*(cQ*da*Q)*1e3/1e3
dY_BD=k*(dt/taun)*2*1.057*(bd/BD)
dY_tau=k*(dt/taun)*(ctau*da)
dlnH=0.5*(cG*da); dY_G=k*((Q/0.7)*(1/3)+(dt/taun))*dlnH
print(f"  delta alpha/alpha = {da:.3e}")
print(f"  dY_p(B_D)  = {dY_BD:+.3e} = {abs(dY_BD)/sig:.3f} sigma")
print(f"  dY_p(Q_np) = {dY_Q:+.3e} = {abs(dY_Q)/sig:.3f} sigma")
print(f"  dY_p(tau_n)= {dY_tau:+.3e} = {abs(dY_tau)/sig:.3f} sigma   (dTau={ctau*da*taun:+.2f} c)")
print(f"  dY_p(G_N)  = {dY_G:+.3e} = {abs(dY_G)/sig:.3f} sigma   (dlnH={dlnH:+.2e})")
tot=dY_BD+dY_Q+dY_tau+dY_G
print(f"  сумма четырёх = {tot:+.3e} = {abs(tot)/sig:.3f} sigma  (против {abs(dY_BD+dY_Q)/sig:.3f} sigma без tau и G)")