"""Repeat the finite tests and optionally both weak-network pilots, entirely offline."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
def main():
    args=argparse.ArgumentParser()
    args.add_argument('--network',action='store_true',help='Also run two 16-integration network pilots')
    args.add_argument('--out',type=Path,default=Path('replayed'))
    cfg=args.parse_args()
    cfg.out.mkdir(exist_ok=True,parents=True)
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('Input checksum: '+name)
    env={**os.environ,'R150_BENCH':str(ROOT/'upstream/floquet/phase_bbn/network_bench'),
         'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
    rev=json.loads((ROOT/'results/replay.json').read_text())['blocks']
    for i,name in enumerate(sorted((ROOT/'attachment_cells').glob('*.py'))):
        record=rev[i]
        if hashlib.sha256(name.read_bytes()).hexdigest()!=record['sha256']: raise ValueError(name)
        result=subprocess.run([sys.executable,'-I',str(name)],capture_output=True,text=True,check=True,env=env)
        (cfg.out/(name.stem+'.txt')).write_text(result.stdout)
    tasks=[('finite_results','finite_audit',[])]
    if cfg.network:tasks += [('weak_results','weak_pilot',[]),('weak_refined','weak_pilot',['7e-10'])]
    for name,script,argv in tasks:
        text=subprocess.check_output([sys.executable,str(ROOT/(script+'.py')),*argv],text=True,env=env)
        payload=json.loads(text)
        if name.startswith('weak'):
            assert all(abs(v['D_relative_mismatch'])<5e-7 for k,v in payload.items() if k.endswith('_comparison'))
        (cfg.out/(name+'.json')).write_text(text)
        print(name,'saved')

if __name__=='__main__':main()
