import math, numpy as np
np.set_printoptions(precision=12, suppress=False)

# ---------- 1. КИНЕМАТИЧЕСКИЙ ПАСПОРТ R150: проверка формул по results.json ----------
cyc = {2:{2:3},3:{1:1,2:1,3:5},4:{1:2,3:2,4:7},5:{1:3,4:3,5:9},6:{1:4,5:4,6:11},
       7:{1:5,6:5,7:13},8:{1:6,7:6,8:15},9:{1:7,8:7,9:17},10:{1:8,9:8,10:19},
       11:{1:9,10:9,11:21},12:{1:10,11:10,12:23},13:{1:11,12:11,13:25},
       14:{1:12,13:12,14:27},15:{1:13,14:13,15:29}}
obs = {2:(6,6,2,2,2),3:(18,8,4,4,4),4:(36,18,2,6,2),5:(60,18,4,10,4),6:(90,30,2,10,2),
       7:(126,28,4,16,4),8:(168,42,2,14,2),9:(216,38,4,22,4),10:(270,54,2,18,2),
       11:(330,48,4,28,4),12:(396,66,2,66,2),13:(468,58,4,34,4),14:(546,78,2,26,2),
       15:(630,68,4,40,4)}   # (carrier, dim_iD, trT, chi_zeros, combined_zeros)

print("L |V|pred |V|obs  cyc_type_ok  ker_iD_pred/obs  TrT  chi_pred/obs  comb")
for L in range(2,16):
    carrier_pred = 3*L*(L-1)
    type_pred = {1:L-2, L-1:L-2, L:2*L-1}
    type_pred = {k:v for k,v in type_pred.items() if v>0}
    ok_type = (type_pred == cyc[L])
    ncyc = sum(cyc[L].values()); neven = sum(v for n,v in cyc[L].items() if n%2==0)
    ker_pred = ncyc + neven
    ker_formula = 5*L-7 if L%2 else 6*L-6
    chi_pred = (3*L-5 if L%2 else (6*L-6 if L%12==0 else 2*L-2))
    trT = 3-(-1)**L
    c,ki,t,ch,cb = obs[L]
    print(f"{L:2d} {carrier_pred:4d} {c:4d}  {str(ok_type):5s}  {ker_pred:3d}/{ki:3d} (f={ker_formula:3d})  {t}={trT}  {ch:3d}/{chi_pred:3d}  {cb}")

# чётности ядра F-1 / F+1 и iD для нечётных L
print("\nнечётные L: (n0+,n0-)=(2L-1,2L-4); (npi+,npi-)=((L-1)/2,(L-3)/2); ker iD=((5L-3)/2,(5L-11)/2)")
for L in [3,5,7,9,11,13,15]:
    print(L, (2*L-1,2*L-4), ((L-1)//2,(L-3)//2), ((5*L-3)//2,(5*L-11)//2),
          "net:", (2*L-1-(2*L-4), (L-1)//2-(L-3)//2))

# активный/пассивный раскрой
print("\nL  active=L(L-2)  passive=L(2L-1)  sum  3L(L-1)  доля 3(L-1)/L^2")
for L in [5,7,9,15,101]:
    print(L, L*(L-2), L*(2*L-1), L*(L-2)+L*(2*L-1), 3*L*(L-1), round(3*(L-1)/L**2,6))

# ---------- 2. ЩЕЛИ ----------
print("\nактивная щель min(2mu, g-mu*m_max), mu=c*g/m_max, g=2sin(2pi/(L-1)), m_max=(L-1)/2")
meas = {(5,0.1):0.19999999999999976,(5,0.6):0.8,(5,0.95):0.10000000000000009,
        (7,0.1):0.1154700538379249,(7,0.6):0.6928203230275505,(7,0.95):0.0866025403784434,
        (9,0.1):0.0707106781186545,(9,0.6):0.42426406871192823,(9,0.95):0.07071067811865483,
        (11,0.1):0.04702282018339761,(11,0.6):0.2821369211003869,(11,0.95):0.0587785252292472,
        (13,0.1):0.03333333333333309,(13,0.6):0.1999999999999997,(13,0.95):0.04999999999999971}
worst=0
for (L,c),m in meas.items():
    g = 2*math.sin(2*math.pi/(L-1)); mmax=(L-1)//2; mu = c*g/mmax
    pred = min(2*mu, g-mu*mmax); worst=max(worst,abs(pred-m))
print("max |pred-meas| =", worst)
print("пределы L*gap: pi*sqrt(3)/6 =", math.pi*math.sqrt(3)/6, " pi*sqrt(3)/2 =", math.pi*math.sqrt(3)/2)
print("izolyaciya triple <= 2/L^2:", {L: 2/L**2 for L in [7,15,101]})

