import math, itertools, numpy as np

L=7
Q=np.zeros((L,L)); 
for t in range(L): Q[(t+1)%L,t]=1
I=np.eye(L); I[0,0]=I[1,1]=0; I[0,1]=I[1,0]=1
F=Q@I                      # перестановка самосопряжённого слоя в координате t
Finv=F.T
print("F: fixed points:",[t for t in range(L) if F[t,t]==1])
D=1j*(F-F.T); ev=np.linalg.eigvalsh(D)
print("ker iD dim:",int(np.sum(abs(ev)<1e-10)), " spectrum:",np.round(ev,9))

# базис ядра: b=e1, s и a на 6-цикле
cyc=[0,2,3,4,5,6]
b=np.zeros(L); b[1]=1
s=np.zeros(L); s[cyc]=1/math.sqrt(6)
a=np.zeros(L)
for k,t in enumerate(cyc): a[t]=(-1)**k/math.sqrt(6)
B=np.column_stack([b,s,a])
print("F на (b,s,a):",np.round(B.T@F@B,9).tolist())
print("iD на (b,s,a):",np.round(B.T@D@B,9).real.tolist())

# поиск допустимых T: инволюции с T F T = F^{-1}
def perm_mat(p):
    M=np.zeros((L,L))
    for j,i in enumerate(p): M[i,j]=1
    return M
sols=[]
for p in itertools.permutations(range(L)):
    if any(p[p[j]]!=j for j in range(L)): continue
    T=perm_mat(p)
    if np.max(np.abs(T@F@T-Finv))<1e-12:
        sols.append((p,int(round(np.trace(T))),T))
print("\nинволюций с TFT=F^-1:",len(sols)," из них Tr T=3:",sum(1 for _,tr,_ in sols if tr==3))
for p,tr,T in sols:
    Tp=F@T
    kerpar=[]
    for sign in [+1,-1]:
        P=(B.T@T@B)
        pass
    Tp2=np.max(np.abs(Tp@Tp-np.eye(L)))
    rel=np.max(np.abs(Tp@F@Tp-Finv))
    print(f"T={p} TrT={tr} | T'=FT: (T')^2 err={Tp2:.1e}, T'FT'=F^-1 err={rel:.1e}, TrT'={int(round(np.trace(Tp)))}, T' на (b,s,a) diag={np.round(np.diag(B.T@Tp@B),6)}")

# градуировка: чётности ядра iD при данном T
for p,tr,T in sols:
    if tr!=3: continue
    M=B.T@T@B
    evv,evec=np.linalg.eigh(M)
    print("\nT на ядре: eig",np.round(evv,9)," -> (T+,T-)=",int(np.sum(evv>0)),int(np.sum(evv<0)))
    Tp=F@T; M2=B.T@Tp@B
    evv2,_=np.linalg.eigh(M2)
    print("T' на ядре: eig",np.round(evv2,9)," -> (T'+,T'-)=",int(np.sum(evv2>0)),int(np.sum(evv2<0)))
    # деформация O в плоскости (e0,e1)
    O=np.eye(L); O[0,0]=4/5; O[0,1]=-3/5; O[1,0]=3/5; O[1,1]=4/5
    J=F@T; Up=O@J@O.T@T
    print("T U' T = U'^dag err:",np.max(np.abs(T@Up@T-Up.conj().T)))
    e=np.linalg.eigvals(Up); print("(n0,npi)=",int(np.sum(abs(e-1)<1e-9)),int(np.sum(abs(e+1)<1e-9)),
          " e1 неподвижно?",np.max(np.abs(Up[:,1]-np.eye(L)[:,1]))<1e-9)
    # микродвижение: проекция I e1 и Q e1 обратно на тройку
    for name,vec in [("I e1",I@np.eye(L)[:,1]),("Q e1",Q@np.eye(L)[:,1])]:
        w=B.T@vec; print(name,"-> ||proj||^2 =",round(float(w@w),12))
    break

