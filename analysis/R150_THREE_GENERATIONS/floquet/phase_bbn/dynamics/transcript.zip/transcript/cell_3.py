import math, numpy as np, sympy as sp

def W(L,zv,hv):
    Q=np.zeros((L,L),complex)
    for j in range(L-1): Q[j+1,j]=1
    Q[0,L-1]=hv
    v=np.zeros((L,1),complex); v[0,0]=1/math.sqrt(2); v[1,0]=-1/math.sqrt(2)
    return Q@(np.eye(L,dtype=complex)+(zv-1)*(v@v.conj().T))

print("=== W_h charpoly vs x^L+(z-1)x^(L-1)/2+h((z-1)x/2-z) ===")
for L in [7,9]:
    for zv,hv in [(-1,1),(-1j,1),(-1j,1j),(-1j,(3-4j)/5)]:
        M=W(L,zv,hv); co=np.poly(M)
        tgt=np.zeros(L+1,complex); tgt[0]=1; tgt[1]=(zv-1)/2; tgt[L-1]=hv*(zv-1)/2; tgt[L]=-hv*zv
        ev=np.linalg.eigvals(M)
        n0=int(np.sum(np.abs(ev-1)<1e-9)); npi=int(np.sum(np.abs(ev+1)<1e-9))
        print(f"L={L} z={zv} h={hv}: err={np.max(np.abs(co-tgt)):.2e} (n0,npi)=({n0},{npi}) det={np.linalg.det(M):.6f} (det=z? {abs(np.linalg.det(M)-zv):.1e})")

# T-preserving deformation O J O^T T на самосопряжённом слое (базис b,s,a), F=diag(1,1,-1)
print("\n=== деформация, сохраняющая T: U'=O J O^T T, J=FT, O: cos=4/5,sin=3/5 в плоскости (e0,e1) ===")
L=7
F=np.diag([1,1,-1]).astype(complex)   # базис (b,s,a)
T=np.eye(3,dtype=complex)
J=F@T
O=np.eye(3,dtype=complex); O[0,0]=4/5; O[0,1]=-3/5; O[1,0]=3/5; O[1,1]=4/5
Up=O@J@O.T@T
print("T U' T == U'^dag :", np.max(np.abs(T@Up@T-Up.conj().T)))
ev=np.linalg.eigvals(Up)
print("eig:",np.round(ev,9)," (n0,npi)=",int(np.sum(abs(ev-1)<1e-9)),int(np.sum(abs(ev+1)<1e-9)))
print("e1 остаётся неподвижным?", abs(Up[0,0]-1)<1e-12, " U'e1=",np.round(Up[:,0],6))

# ---------- λ-масштабирование такта: статический индекс против часов ----------
print("\n=== F_lambda=exp(-i lambda H_F tau/hbar): на слое F=diag(1,1,-1) -> diag(1,1,e^{i pi lambda}) ===")
for lam in [1.0,1+1e-15,1+1.54261e-15,1+1e-12,1+1e-6,1.5,2.0]:
    Fl=np.diag([1,1,np.exp(1j*math.pi*lam)])
    iD=1j*(Fl-Fl.conj().T)
    d=np.diag(iD).real
    for tol in [1e-12]:
        print(f"lam-1={lam-1:.3e}: diag iD={d}, ker(tol=1e-12)={int(np.sum(abs(d)<tol))}, ker(tol=1e-16)={int(np.sum(abs(d)<1e-16))}")
tol=1e-12
print("окно такта, в котором tol-считывание ещё даёт 3: |lam-1| <= tol/(2pi) =", tol/(2*math.pi))
eps_ccc=1.54261e-15
print("CCC-дрейф за 1000 с:",eps_ccc," -> 2|sin(pi*lam)| =",2*abs(math.sin(math.pi*(1+eps_ccc))),
      "; дефект pi-фазы =",math.pi*eps_ccc)
print("отношение окно/дрейф =", (tol/(2*math.pi))/eps_ccc)
print("отношение невязка аудита (5.208e-12) / дефект pi =", 5.207834163911685e-12/(math.pi*eps_ccc))

