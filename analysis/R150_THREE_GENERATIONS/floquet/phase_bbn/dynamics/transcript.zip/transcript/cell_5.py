import math, numpy as np, sympy as sp

# ---------- CCC-сторона: арифметика часов из REPORT ----------
Mpc_km = 3.0856775814913673e19
Hc = 59.5/Mpc_km            # 1/c
alpha = -0.8*Hc
print("Hc [1/c] =",Hc," alpha=-0.8Hc =",alpha)
for dt in [1000.0]:
    print(f"dt={dt} c: dc/c = {alpha*dt:.9e}   dG/G = 3*alpha*dt = {3*alpha*dt:.9e}")
print("REPORT: -1.54261e-15 и -4.62783e-15  -> совпадение:",
      abs(alpha*1000+1.54261e-15)<1e-20, abs(3*alpha*1000+4.62783e-15)<1e-20)

# SN-арифметика S4
tl=1.159294; lb=8.359470/7.306235
print("\nSN z=1: TL-множитель",tl," дефицит 1-1/TL =",1-1/tl)
print("lookback ratio =",lb," совместный дефицит 1-lb/TL =",1-lb/tl, " (REPORT ~1.31%)")

# ---------- Koide / theta=2/9 ----------
me, mmu, mtau, stau = 0.51099895000, 105.6583755, 1776.86, 0.12
Qk = (me+mmu+mtau)/(math.sqrt(me)+math.sqrt(mmu)+math.sqrt(mtau))**2
print("\nKoide Q =",repr(Qk)," (audit 0.6666644634026365)")
# sigma_Q по tau
h=1e-6
dQ=( (me+mmu+mtau+h)/(math.sqrt(me)+math.sqrt(mmu)+math.sqrt(mtau+h))**2 - Qk)/h
sQ=abs(dQ)*stau
print("sigma_Q =",sQ," (audit 5.080958197563941e-06)  standardized:",(Qk-2/3)/sQ," (audit -0.4336316)")
# тяжёлый корень Коиде при фиксированных me,mmu
x=sp.symbols('x',positive=True)
sol=sp.solve(sp.Eq((me+mmu+x**2)/(sp.sqrt(me)+sp.sqrt(mmu)+x)**2, sp.Rational(2,3)),x)
roots=[float(s)**2 for s in sol]
print("корни Koide по m_tau:",roots," (audit heavy 1776.9690272931578)")
print("тяжёлый корень в sigma_tau:",(max(roots)-mtau)/stau)
# жёсткая фаза 2/9
th=2/9
r=[(1+math.sqrt(2)*math.cos(th+2*math.pi*k/3))**2 for k in range(3)]
r=sorted(r)
print("\ntheta=2/9: массы ~",r," m_mu/m_e =",r[1]/r[0]," (audit 206.7703159727297)")
cod, scod = 206.7682830, 4.6e-6
print("CODATA m_mu/m_e =",cod,"(46) -> отклонение в sigma:",(r[1]/r[0]-cod)/scod," (audit 442.01581)")

# ---------- масштабные сопоставления ----------
print("\n=== масштабные числа ===")
print("R150: mu=1/L^2, изоляция тройки <= 2/L^2:", {L:2/L**2 for L in [7,15,101]})
print("R150: пассивная щель ~ pi*sqrt(3)/(6L) или /(2L):", {L:(math.pi*math.sqrt(3)/(6*L), math.pi*math.sqrt(3)/(2*L)) for L in [17,19,21]})
print("CCC: |alpha|*tau_BBN ~", abs(alpha)*1000, "; f≈3.66 (из отчёта, не пересчитано)")
print("R150: доля устойчивых 3(L-1)/L^2:", {L:3*(L-1)/L**2 for L in [7,15,101]})
print("возвраты длины: 343-126 =",343-126,"; 217-145 =",217-145,"; сумма first_return =",8+17+26+35+38+18+2+1)

