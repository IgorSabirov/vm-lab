import math
me, mmu = 0.51099895000, 105.6583755
def Qk(mt): return (me+mmu+mt)/(math.sqrt(me)+math.sqrt(mmu)+math.sqrt(mt))**2
def dQ(mt,h=1e-7): return (Qk(mt+h)-Qk(mt-h))/(2*h)
for mt,st in [(1776.86,0.12),(1776.93,0.09)]:
    Q=Qk(mt); s=abs(dQ(mt))*st
    print(f"m_tau={mt}({st}): Q={Q:.16f} sigma_Q={s:.10e} standardized={(Q-2/3)/s:.10f}")
print("audit: Q=0.6666644634026365 sigma=5.080958197563941e-06 z=-0.4336315994817396")
print("тяжёлый корень 1776.9690272931578 -> в sigma_tau:", (1776.9690272931578-1776.93)/0.09, "и", (1776.9690272931578-1776.86)/0.12)
r=206.77031597272907
for cod in [206.7682830,206.7682827]:
    print(f"CODATA {cod}: z={(r-cod)/4.6e-6:.8f}")
print("audit ratio_standardized = 442.01581080533686")

