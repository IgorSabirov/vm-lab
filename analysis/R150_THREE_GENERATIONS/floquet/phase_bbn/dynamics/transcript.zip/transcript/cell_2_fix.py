import math, numpy as np, sympy as sp

# ---------- 3. СОВМЕСТНЫЙ ОТКЛИК: две ручки -> одна матрица 2x2 ----------
print("=== joint (delta,phi): diag(delta/2, delta/(2n)+phi/n), offdiag -delta/(2 sqrt(n)) ===")
meas = {7:{(0.001,0.0):(0.0,0.0005833332826967913,8.333333767404637e-05),
           (0.001,0.0008):(0.00010986580850822418,0.0006068008237260187,0.00021666666961785445),
           (0.001,-0.0005):(-7.274861208405921e-05,0.0005727485513202438,5.207834163911685e-12)},
        9:{(0.001,0.0):(0.0,0.0005624999282226894,6.250000341795398e-05),
           (0.001,0.0008):(8.685981524600695e-05,0.0005756401293827736,0.00016250000263714175),
           (0.001,-0.0005):(-5.618621779960021e-05,0.0005561861357682503,3.9067638013534666e-12)}}
for L,d in meas.items():
    n=L-1
    for (de,ph),(m1,m2,mpi) in d.items():
        M=np.array([[de/2, -de/(2*math.sqrt(n))],[-de/(2*math.sqrt(n)), de/(2*n)+ph/n]])
        ev=sorted(np.linalg.eigvalsh(M))
        print(f"L={L} d={de} p={ph}: eig={ev[0]:.12e},{ev[1]:.12e} | meas={m1:.12e},{m2:.12e}"
              f" | det={np.linalg.det(M):.6e} vs d*p/(2n)={de*ph/(2*n):.6e}"
              f" | pi_lin=(d/2+p)/n={(de/2+ph)/n:.12e} meas={mpi:.3e}")

# ---------- 4. характеристический многочлен со швом ----------
x,z,h,Ls = sp.symbols('x z h Ls')
print("\n=== p(x)=x^L+(z-1)x^(L-1)/2 + h((z-1)x/2 - z) ===")
for L in [7,9]:
    p = x**L + (z-1)*x**(L-1)/2 + h*((z-1)*x/2 - z)
    print(L, "p(1)=",sp.factor(sp.expand(p.subs(x,1))), " p(-1)=",sp.factor(sp.expand(p.subs(x,-1))))
zz=-sp.I
for hh in [sp.I,(3-4*sp.I)/5, 1]:
    p = x**7 + (zz-1)*x**6/2 + hh*((zz-1)*x/2 - zz)
    print("z=-i,h=",hh," p(1)=",sp.simplify(p.subs(x,1))," p(-1)=",sp.simplify(p.subs(x,-1)))
print("h-кривая pi: h=(3-z)/(1-3z) при z=-i ->", sp.simplify((3-zz)/(1-3*zz)))

# численная сборка W_h = Q_h (1+(z-1) v v^dag), v=(e0-e1)/sqrt2, Q e_{L-1}=h e_0
def W(L,zv,hv):
    Q=np.zeros((L,L),complex)
    for j in range(L-1): Q[j+1,j]=1
    Q[0,L-1]=hv
    v=np.zeros((L,1),complex); v[0,0]=1/math.sqrt(2); v[1,0]=-1/math.sqrt(2)
    P=np.eye(L,dtype=complex)+(zv-1)*(v@v.conj().T)
    return Q@P
for L in [7,9]:
    for zv,hv in [(-1j,1),(-1j,1j),(-1j,(3-4j)/5),(-1,1)]:
        M=W(L,zv,hv); co=np.poly(M)
        tgt=[1]+[0]*L
        tgt[1]=(zv-1)/2; tgt[L-1]=hv*(zv-1)/2; tgt[L]=-hv*zv
        err=np.max(np.abs(co-np.array(tgt)))
        ev=np.linalg.eigvals(M)
        n0=int(np.sum(np.abs(ev-1)<1e-10)); npi=int(np.sum(np.abs(ev+1)<1e-10))
        print(f"L={L} z={zv} h={hv}: charpoly_err={err:.2e}  (n0,npi)=({n0},{npi})  det={np.linalg.det(M):.6f}")

# ---------- 5. шов: разрезанный путь vs замкнутый цикл ----------
print("\n=== голономия: спектр iD на C_n с потоком phi ===")
def iD_cycle(n,phi):
    S=np.zeros((n,n),complex)
    for j in range(n-1): S[j+1,j]=1
    S[0,n-1]=np.exp(1j*phi)
    return 1j*(S-S.conj().T)
def iD_path(n,phi):
    S=np.zeros((n,n),complex)
    for j in range(n-1): S[j+1,j]=1
    S[0,n-1]=np.exp(1j*phi)     # шов на "замыкающем" элементе, но путь разомкнут оператором
    S[0,n-1]=0
    S[n-1,0]=0
    # разомкнутый путь с фазой на одном ребре
    S[1,0]=np.exp(1j*phi)
    return 1j*(S-S.conj().T)
for n in [6,7,8,9]:
    for phi in [0.0,0.3,math.pi]:
        ec=np.linalg.eigvalsh(iD_cycle(n,phi)); ep=np.linalg.eigvalsh(iD_path(n,phi))
        zc=int(np.sum(np.abs(ec)<1e-10)); zp=int(np.sum(np.abs(ep)<1e-10))
        print(f"n={n} phi={phi:.4f}: цикл zeros={zc}, путь zeros={zp}")
print("путь: спектр не зависит от phi (калибровка снимается):",
      np.max(np.abs(np.linalg.eigvalsh(iD_path(7,0.0))-np.linalg.eigvalsh(iD_path(7,0.777)))))
print("C6 phi=0.3 энергии:", np.round(np.linalg.eigvalsh(iD_cycle(6,0.3)),9))
print("C9 phi=pi энергии:", np.round(np.linalg.eigvalsh(iD_cycle(9,math.pi)),9))
print("наклоны 2/n: 2sin(0.1/6)=",2*math.sin(0.1/6)," 2sin(0.1/7)=",2*math.sin(0.1/7),
      " ratio=",2*math.sin(0.1/6)/(2*math.sin(0.1/7)), " 7/6=",7/6)

