"""Reproduce the R130 and nuclear table checks offline. Run with Python 3."""
from bisect import bisect_right
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
from math import exp, log
from pathlib import Path
import hashlib
import json

import r130

HERE = Path(__file__).resolve().parent
ORIENTATION = (1, -1)


def step(word, eps=ORIENTATION):
    return r130.word(r130.forward(r130.named(word), eps))


def block_counts(word, width):
    doubled = word + word
    return Counter(doubled[i:i + width] for i in range(len(word)))


def hist(word):
    return tuple(word.count(i) for i in range(16))


def census():
    groups = defaultdict(lambda: (set(), set(), set()))
    words = 0
    for length in range(1, 5):
        for w in product(range(16), repeat=length):
            if r130.cyclic(w) != w:
                continue
            words += 1
            pairs = Counter(zip(w, w[1:] + w[:1]))
            key = (length, hist(w), pairs[1, 2], pairs[8, 4])
            first, second_hist, second = groups[key]
            y = step(w)
            first.add(len(y))
            second_hist.add(hist(y))
            second.add(len(step(y)))
            assert len(y) == length + w.count(3) + w.count(12) - pairs[1, 2] - pairs[8, 4]
    ambiguous = [sum(len(v[j]) > 1 for v in groups.values()) for j in range(3)]
    assert (len(groups), ambiguous[:2]) == (5141, [0, 4050])
    return dict(rotation_classes=words, groups=len(groups), ambiguous_next_length=ambiguous[0],
                ambiguous_next_histogram=ambiguous[1], ambiguous_second_length=ambiguous[2],
                witness=[(w, step(w), step(step(w))) for w in [(0, 3, 1), (0, 1, 3)]])


def sparse_ring(n, position):
    w = [0] * n
    w[0], w[position] = 2, 1
    return tuple(w)


def general_family():
    for k in range(1, 65):
        n = 2 * k + 3
        x, y = sparse_ring(n, k), sparse_ring(n, k + 1)
        assert all(block_counts(x, j) == block_counts(y, j) for j in range(1, k + 1))
        assert block_counts(step(x), k) != block_counts(step(y), k)
        for t in range(k + 1):
            assert len(x) == len(y) == n
            x, y = step(x), step(y)
        assert (len(x), len(y)) == (n + 1, n)
    return dict(first_k=1, last_k=64, rings_per_k=2, first_different_length_at='k+1')


def features(s):
    a, b, c, d = ((s >> i) & 1 for i in range(4))
    return a, b, c, d, a*c, b*d


def rank(rows):
    """Exact incremental row reduction of integer rows."""
    pivots = {}
    for row in rows:
        row = list(map(Fraction, row))
        for col, pivot in sorted(pivots.items()):
            if row[col]:
                m = row[col]
                row = [a - m*b for a, b in zip(row, pivot)]
        col = next((c for c, x in enumerate(row) if x), None)
        if col is not None:
            pivots[col] = [x/row[col] for x in row]
    return len(pivots)


def invariants():
    out = []
    f = [features(s) for s in range(16)]
    assert rank(f) == 6
    for eps in product((1, -1), repeat=2):
        rows = set()
        for w in product(range(16), repeat=3):
            y = step(w, eps)
            rows.add(tuple(b-a for a, b in zip(hist(w), hist(y))))
        assert all(all(sum(v*x for v, x in zip(row, col)) == 0 for col in zip(*f)) for row in rows)
        assert rank(rows) == 10
        w = (5, 10, 0, 0)
        orbit = []
        for _ in range(4):
            orbit.append(r130.cyclic(w))
            w = step(w, eps)
        assert len(set(orbit)) == 4 and r130.cyclic(w) == orbit[0]
        obs = [int(15 in x) - Fraction(1, 4) for x in orbit]
        corr = sum(obs[(j-1) % 4] * obs[(j+1) % 4] for j in range(4)) / 4
        assert corr == Fraction(-1, 16)
        out.append(dict(eps=eps, rank=10, nullity=6, orbit=orbit, correlation=str(corr)))
    return out


def read(name):
    return [tuple(map(float, line.split())) for line in (HERE/'rates'/name).read_text().splitlines()
            if line.strip() and not line.lstrip().startswith('#')]


def interpolate(t, x, y, u, v):
    m = (v-y)/(u-x)
    gamma = log(v/y)/log(u/x)
    return y+(t-x)*m, y*exp(gamma*log(t/x))


def table_comparison():
    tpag = read('linx_t_p__a_g.txt')
    differences = []
    for (x, y, _), (u, v, _) in zip(tpag, tpag[1:]):
        left, right = max(0.1, x), min(1.0, u)
        if right < left:
            continue
        m = (v-y)/(u-x)
        gamma = log(v/y)/log(u/x)
        candidates = [left, right]
        if m and gamma != 1:
            t = gamma*(y-m*x)/((1-gamma)*m)
            if left < t < right:
                candidates.append(t)
        for t in candidates:
            lin, power = interpolate(t, x, y, u, v)
            differences.append((100*(lin/power-1), t, (x,u)))
    peak = max(differences, key=lambda r:abs(r[0]))
    linx = read('linx_He3_a__Be7_g.txt')
    primat = read('primat_He3_a__Be7_g.txt')
    t = 0.2179407
    p, factor = next((r,f) for temp,r,f in primat if temp == t)
    i = bisect_right([v[0] for v in linx], t)
    (x,y,_), (u,v,_) = linx[i-1:i+1]
    lin, power = interpolate(t, x, y, u, v)
    be7 = read('linx_Be7_n__Li7_p.txt')
    return dict(tpag_max_percent_linear_over_loglog=peak, tpag_factors=sorted({s for _,_,s in tpag}),
                He3_alpha=dict(T9=t, PRIMAT=p, PRIMAT_factor=factor, LINX_linear=lin, LINX_loglog=power,
                               percent_relative_PRIMAT=[100*(a/p-1) for a in (lin,power)]),
                Be7_np_selected_rows=[row for row in be7 if row[0] in (0.001,1,1.25,1.5)])


if __name__ == '__main__':
    digest = hashlib.sha256((HERE/'r130.py').read_bytes()).hexdigest()
    assert digest == 'd46a47443e610ffe42a0160aaae0487e6c0a9be9e6b96bf72ce39962cf7cf9a1'
    out = dict(r130_sha256=digest, census=census(), family=general_family(), invariants=invariants(),
               rates=table_comparison())
    (HERE/'checks.json').write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k != 'invariants'}, ensure_ascii=False))
