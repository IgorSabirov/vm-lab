"""Horizon-limited census on rotation classes of all length-three seeds in R130 (+,-)."""
from itertools import product
from functools import lru_cache
from pathlib import Path
import json
import r130 as r

def least_rotation(w):
    return min(w[i:]+w[:i] for i in range(len(w)))

@lru_cache(maxsize=8192)
def move(w):
    x=r.named(w)
    interaction=r.interact(x,(1,-1))
    active=not r.equal(interaction,x)
    y=r.word(r.transport(interaction,2))
    v=least_rotation(y)
    return v,active

def run():
    found=set()
    cycles=set()
    unresolved=0
    for seed in {least_rotation(w) for w in product(range(16),repeat=3)}:
        seen={}
        history=[]
        flags=[]
        w=seed
        for _ in range(41):
            if w in seen:
                j=seen[w]
                orbit=tuple(history[j:])
                cycles.add(least_rotation(orbit))
                if any(flags[j:]):
                    found.add(least_rotation(orbit))
                break
            if len(history)==40 or len(w)>256:
                unresolved+=1
                break
            seen[w]=len(history)
            history.append(w)
            w,active=move(w)
            flags.append(active)
    return dict(horizon=40,length_cap=256,total_cycles_detected=len(cycles),active_cycles=len(found),unresolved_seed_classes=unresolved,active_orbits=sorted(found))
if __name__=='__main__':
    res=run()
    Path(__file__).with_name('cycles_results.json').write_text(json.dumps(res,indent=2)+'\n')
    print(str(res)[:1050])
