"""Check the four frozen-I transport/reflection combinations and the explicit growth family."""
from itertools import product
import json
from pathlib import Path
import sympy as sp
import frozen
import r130 as r
from compare import canon_graph, charges, n, words
HERE=Path(__file__).parent

def reverse(x):
    return tuple(reversed(x))

def Q(x):
    return r.transport(x,2)

def Qinv(x):
    return r.transport(x,2,True)

def literal(x):
    return reverse(Qinv(x))

def literal_inverse(x):
    return Q(reverse(x))

def port_swap(x):
    return reverse(r.r2(x))

def old_interact(x):
    # On channel 2 the frozen rule puts the right named child first in traversal.
    starts={i for i,(_,s) in enumerate(x) if (s,x[(i+1)%len(x)][1]) in ((1,2),(4,8))}
    ends={(i+1)%len(x) for i in starts}
    i=next(i for i in range(len(x)) if i not in ends)
    out=[]
    used=0
    while used<len(x):
        u,s=x[i]
        step=1
        if i in starts:
            v=x[(i+1)%len(x)][0]
            out.append((r.join(u,v),3) if s==1 else (r.join(v,u),12))
            step=2
        elif s==3:
            out.extend(((r.left(u),1),(r.right(u),2)))
        elif s==12:
            out.extend(((r.right(u),4),(r.left(u),8)))
        else:
            out.append((u,s))
        used+=step
        i=(i+step)%len(x)
    return tuple(out)

def check():
    keys=('RI_IR','RQR_Qinv','T_squared','TFT_Finv')
    transport_modes=(('Fig2a',Q,Qinv),('literal',literal,literal_inverse))
    swap_modes=(('bits',r.r2),('bits_ports',port_swap))
    counts={qm+'_'+rm:{k:0 for k in keys} for qm,_,_ in transport_modes for rm,_ in swap_modes}
    for w in words((1,2,3)):
        x=r.named(w)
        old=frozen.ring_graph([n.bits(s) for s in w])
        for fn,original in [(literal,frozen.sqrt_tau),(literal_inverse,frozen.sqrt_tau_inverse),
                            (old_interact,frozen.I2),(port_swap,frozen.R_c2)]:
            assert r.canonical(fn(x))==canon_graph(original(old))
        for qm,q,qi in transport_modes:
            for rm,op in swap_modes:
                row=counts[qm+'_'+rm]
                def T(z):
                    return old_interact(op(z))
                vals=[(op(old_interact(x)),T(x)),(op(q(op(x))),qi(x)),(T(T(x)),x),
                      (T(q(old_interact(T(x)))),old_interact(qi(x)))]
                for key,(a,b) in zip(keys,vals):
                    row[key]+=not r.equal(a,b)
    seed=(0,3,12)
    def step(w):
        return r.cyclic(r.word(r.forward(r.named(w),(1,-1))))
    def family(m):
        return (2,12,0,1)+(0,)*m
    assert step(seed)==r.cyclic(family(1))
    assert all(step(family(m))==r.cyclic(family(m+1)) for m in range(1,65))
    bounded=(1,2,12)
    assert step(bounded)==r.cyclic(bounded) and charges(seed)==charges(bounded)
    t,rad=sp.symbols('t r',positive=True)
    f=sp.Function('F')(t,rad)
    S=-sp.diff(f,t)
    C=t*sp.diff(S,t)
    D=f+t*S+rad*sp.diff(f,rad)
    drift=1-rad*sp.diff(S,rad)/C
    assert sp.simplify(drift-sp.diff(D,t)/C)==0
    return dict(frozen_I_gate_failure_counts=counts,growth_family_first_step=step(seed),
                growth_family_verified_m=[1,64],BH1_symbolic_residual='0')
if __name__=='__main__':
    data=check()
    (HERE/'extra_results.json').write_text(json.dumps(data,indent=2)+'\n')
    print(data)
