"""Check the R130 verifier, the frozen port graph, and the parametrization in the submitted review."""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
import hashlib
import json
from pathlib import Path
import sympy as sp
import frozen
import r130 as r
import neighbor as n

HERE = Path(__file__).parent
BASE = (1, -1)
def convert_name(name):
    if name.tag == 'base':
        return ('atom', name.x)
    if name.tag == 'merge':
        return r.join(convert_name(name.x), convert_name(name.y))
    child = convert_name(name.x)
    return r.left(child) if name.tag == 'left' else r.right(child)

def canon_graph(graph):
    states = frozenset((convert_name(k), sum(bit << i for i, bit in enumerate(v)))
                       for k,v in graph.states.items())
    edges = frozenset((convert_name(p.node), convert_name(q.node)) for p,q in graph.edges)
    return states, edges

def features(s):
    a,b,c,d=n.bits(s)
    return [a,b,c,d,a*c,b*d]

def charges(w):
    return tuple(map(sum,zip(*(features(s) for s in w))))

def words(lengths):
    for length in lengths:
        yield from product(range(16), repeat=length)

def algebra():
    ws=list(words((1,2)))
    out={}
    for eps in product((1,-1),repeat=2):
        rows=[]
        for w in ws:
            y=r.word(r.forward(r.named(w),eps))
            rows.append([y.count(i)-w.count(i) for i in range(16)])
        mat=sp.Matrix(rows)
        vectors=sp.Matrix([features(s) for s in range(16)])
        assert mat*vectors==sp.zeros(272,6) and vectors.rank()==6
        selected=[(3,),(0,3),(0,6),(0,7),(0,9),(0,11),(0,13),(0,14),(0,15),(4,8)]
        minor=mat.extract([ws.index(w) for w in selected],[0,1,2,3,4,5,6,8,9,12]).det()
        w=(5,10,0,0)
        orbit=[]
        for i in range(4):
            g=r.named(w)
            assert r.equal(r.interact(g,eps),g)
            orbit.append(r.cyclic(w))
            w=r.word(r.forward(g,eps))
        assert r.cyclic(w)==orbit[0]
        O=[int(15 in x)-Fraction(1,4) for x in orbit]
        corr=sum(O[(i-1)%4]*O[(i+1)%4] for i in range(4))/4
        out[str(eps)]=dict(rank=int(mat.rank()),specified_minor=int(minor),cycle=orbit,correlation=str(corr))
    witness={}
    for w in [(1,2,12),(0,3,12),(5,10,0)]:
        x=r.named(w)
        witness[str(w)]=dict(charges=charges(w),interaction=r.word(r.interact(x,BASE)),next_word=r.word(r.forward(x,BASE)))
    return out,witness

def run():
    assert hashlib.sha256((HERE/'r130.py').read_bytes()).hexdigest()==json.loads((HERE/'upstream_checks.json').read_text())['script_sha256']
    labels=[(e1,p1,e2,p2) for e1,p1,e2,p2 in product((1,-1),repeat=4)]
    forms={a:n.make_I2(*a) for a in labels}
    counts={a:Counter() for a in labels}
    comparison=Counter()
    gate_calls=Counter()
    for name in ['R_c2','T_sym','f_sym','f_sym_inverse']:
        operation=getattr(frozen,name)
        def trace(*args,fn=operation,key=name):
            gate_calls[key]+=1
            return fn(*args)
        setattr(frozen,name,trace)
    smoke=frozen.minimal_run()
    gate_calls=dict(gate_calls)
    for w in words((1,2,3)):
        x=r.named(w)
        g=n.ring([n.bits(s) for s in w])
        old=frozen.ring_graph([n.bits(s) for s in w])
        frozen_I=canon_graph(frozen.I2(old))
        frozen_tau=canon_graph(frozen.tau_port_reference(old))
        new_Q=n.Qfig(g)
        comparison['Q_square_vs_full_port_tau']+=canon_graph(n.Qfig(new_Q))!=frozen_tau
        comparison['Q_vs_R130']+=canon_graph(new_Q)!=r.canonical(r.transport(x,2))
        comparison['literal_Q_square_vs_full_port_tau']+=canon_graph(frozen.sqrt_tau(frozen.sqrt_tau(old)))!=frozen_tau
        rg=n.R_bits(g)
        for choices,I in forms.items():
            e1,p1,e2,p2=choices
            ig=I(g)
            sig=canon_graph(ig)
            row=counts[choices]
            row['RI_IR']+=not n.geq(n.R_bits(ig),I(rg))
            row['I_squared']+=not n.geq(I(ig),g)
            if e1==e2==1:
                row['I_vs_R130']+=sig!=r.canonical(r.interact(x,(p1,p2)))
            if choices==(1,1,-1,1):
                comparison['neighbor_I_vs_original_frozen_I']+=sig!=frozen_I
    algebra_results,witness=algebra()
    return dict(corpus=sum(1 for w in words((1,2,3))),count_meaning='failure counts',
                order='e1,p1,e2,p2',parameters={str(k):v for k,v in counts.items()},
                comparison=comparison,smoke=smoke['status'],smoke_subtests={k:v['status'] for k,v in smoke['tests'].items()},
                smoke_calls={k:gate_calls.get(k,0) for k in ['R_c2','T_sym','f_sym','f_sym_inverse']},
                algebra=algebra_results,witness=witness)

if __name__=='__main__':
    result=run()
    (HERE/'review_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))
