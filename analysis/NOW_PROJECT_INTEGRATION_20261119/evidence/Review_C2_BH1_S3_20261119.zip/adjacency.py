"""A stronger witness: even the complete histogram of vertex states misses the growth."""
from collections import Counter
from itertools import product
import json
from pathlib import Path
import r130 as r

def step(w):
    return r.cyclic(r.word(r.forward(r.named(w),(1,-1))))

def forecast_length(w):
    pairs=Counter(zip(w,w[1:]+w[:1]))
    return len(w)+w.count(3)+w.count(12)-pairs[1,2]-pairs[8,4]

def growing(m):
    return (2,0,12,0,1)+(0,)*m
def verify():
    bounded=(1,2,12)
    seed=(1,12,2)
    assert Counter(bounded)==Counter(seed)
    assert step(bounded)==r.cyclic(bounded)
    assert step(seed)==r.cyclic((0,3,0,12))
    assert step(step(seed))==r.cyclic(growing(1))
    assert all(step(growing(m))==r.cyclic(growing(m+1)) for m in range(1,65))
    assert all(forecast_length(w)==len(step(w)) for length in (1,2,3) for w in product(range(16),repeat=length))
    histories=[]
    for w in (bounded,seed):
        seq=[list(w)]
        for _ in range(6):
            w=step(w)
            seq.append(list(w))
        histories.append(seq)
    return dict(histories=histories,recurrence_checked_m=[1,64],next_length_rule_checked_states=4368)
if __name__=='__main__':
    out=verify()
    Path(__file__).with_name('adjacency_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print([[len(w) for w in seq] for seq in out['histories']])
