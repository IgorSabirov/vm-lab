import itertools, time
from dataclasses import dataclass
t0=time.perf_counter()
@dataclass(frozen=True)
class Name:
    tag: str; x: object=None; y: object=None
def bn(i): return Name("base",i)
def PL(n): return n.x if n.tag=="merge" else Name("left",n)
def PR(n): return n.y if n.tag=="merge" else Name("right",n)
def MN(x,y):
    if x.tag=="left" and y.tag=="right" and x.x==y.x: return x.x
    return Name("merge",x,y)
@dataclass(frozen=True)
class Port:
    node: Name; port: str
def E(p,q): return (p,q) if p.port=="b" else (q,p)
@dataclass
class Graph:
    states: dict; edges: list
def vg(g):
    if len(g.edges)!=len(g.states): raise ValueError("|E|!=|V|")
    seen=[]
    for e in g.edges:
        if e[0].port!="b" or e[1].port!="a": raise ValueError("orient")
        for p in e:
            if p.node not in g.states: raise ValueError("absent")
            seen.append(p)
    exp={Port(n,p) for n in g.states for p in ("a","b")}
    if len(set(seen))!=len(seen) or set(seen)!=exp: raise ValueError("ports")
def ring(st):
    ns=[bn(i) for i in range(len(st))]
    g=Graph(dict(zip(ns,st)),[E(Port(ns[i],'b'),Port(ns[(i+1)%len(ns)],'a')) for i in range(len(ns))]); vg(g); return g
def den(e): return e[0].node,e[1].node
def geq(g,h): return g.states==h.states and {frozenset(e) for e in g.edges}=={frozenset(e) for e in h.edges}
def ordered(g):
    nxt={p.node:q.node for p,q in g.edges}; out=[next(iter(g.states))]
    while nxt[out[-1]]!=out[0]: out.append(nxt[out[-1]])
    return out
def word(g): return tuple(sum(v<<i for i,v in enumerate(g.states[n])) for n in ordered(g))
def canon(w): return min(w[i:]+w[:i] for i in range(len(w)))
def bits(s): return ((s>>0)&1,(s>>1)&1,(s>>2)&1,(s>>3)&1)
def Qfig(g):
    ns=ordered(g); n=len(ns)
    nm=[MN(PR(u),PL(v)) for u,v in zip(ns,ns[1:]+ns[:1])]
    st={}
    for i,x in enumerate(nm):
        s=g.states[ns[i]]; t=g.states[ns[(i+1)%n]]; st[x]=(t[0],s[1],t[2],s[3])
    o=Graph(st,[E(Port(nm[i],'b'),Port(nm[(i+1)%n],'a')) for i in range(n)]); vg(o); return o
def Qfig_inv(g):
    ws=ordered(g); n=len(ws); old=[]; st={}
    for i,w in enumerate(ws):
        pv=ws[(i-1)%n]; u=MN(PR(pv),PL(w)); old.append(u)
        a=g.states[pv]; b=g.states[w]; st[u]=(a[0],b[1],a[2],b[3])
    o=Graph(st,[E(Port(old[i],'b'),Port(old[(i+1)%n],'a')) for i in range(n)]); vg(o); return o
def R_bits(g):
    o=Graph({n:(s[3],s[2],s[1],s[0]) for n,s in g.states.items()},list(g.edges)); vg(o); return o

# I2 with TWO independent binary choices per channel:
#   e_c = +1 : internal (nl.b, nr.a), ext a->nl.a, b->nr.b
#   e_c = -1 : internal (nr.b, nl.a), ext a->nr.a, b->nl.b
#   p_c = +1 (matched): a-bit on child whose a-port is EXTERNAL
#   p_c = -1 (crossed): a-bit on the other child
def make_I2(e1,p1,e2,p2):
    cfg={1:(e1,p1),2:(e2,p2)}
    def I2(g):
        vg(g); splits={}; merges=[]
        for n,s in g.states.items():
            if s==(1,1,0,0): splits[n]=1
            elif s==(0,0,1,1): splits[n]=2
        # merge pattern per channel derived from the split
        pat={}
        for c,(e,p) in cfg.items():
            ia,ib=2*(c-1),2*(c-1)+1
            A=[0]*4; A[ia]=1; B=[0]*4; B[ib]=1
            # traversal on internal edge: e=+ -> nl first ; e=- -> nr first
            # matched: first child holds a-bit ; crossed: first holds b-bit
            first_a = (p==1)
            pat[c]=(tuple(A),tuple(B)) if first_a else (tuple(B),tuple(A))
        for e in g.edges:
            u,v=den(e); su,sv=g.states[u],g.states[v]
            for c in (1,2):
                if su==pat[c][0] and sv==pat[c][1]: merges.append((u,v,c))
        used=set(splits); par={}; ints=[]; bm={}; drop=set()
        for u,v,c in merges:
            if u in used or v in used: raise ValueError("overlap")
            used|={u,v}
            par[(u,v,c)]=MN(u,v) if cfg[c][0]==1 else MN(v,u)
        ns={n:s for n,s in g.states.items() if n not in used}
        for n,c in splits.items():
            e,p=cfg[c]; nl,nr=PL(n),PR(n)
            ia,ib=2*(c-1),2*(c-1)+1
            A=[0]*4; A[ia]=1; B=[0]*4; B[ib]=1
            if e==1:
                ca,cnb = (nl,nr) if p==1 else (nr,nl)   # ca holds a-bit
                bm[Port(n,'a')]=Port(nl,'a'); bm[Port(n,'b')]=Port(nr,'b')
                ints.append(E(Port(nl,'b'),Port(nr,'a')))
            else:
                ca,cnb = (nr,nl) if p==1 else (nl,nr)
                bm[Port(n,'a')]=Port(nr,'a'); bm[Port(n,'b')]=Port(nl,'b')
                ints.append(E(Port(nr,'b'),Port(nl,'a')))
            ns[ca]=tuple(A); ns[cnb]=tuple(B)
        for (u,v,c),pp in par.items():
            ns[pp]=(1,1,0,0) if c==1 else (0,0,1,1)
            bm[Port(u,'a')]=Port(pp,'a'); bm[Port(v,'b')]=Port(pp,'b')
            drop.add(frozenset((Port(u,'b'),Port(v,'a'))))
        for n in g.states:
            if n not in used: bm[Port(n,'a')]=Port(n,'a'); bm[Port(n,'b')]=Port(n,'b')
        ne=[E(bm[x[0]],bm[x[1]]) for x in g.edges if frozenset(x) not in drop]+ints
        o=Graph(ns,ne); vg(o); return o
    return I2

