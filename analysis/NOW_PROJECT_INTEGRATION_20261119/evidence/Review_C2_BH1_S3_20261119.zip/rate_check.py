"""Compare pinned PRIMAT node values with the q=0 linear interpolation of pinned LINX tables."""
import argparse
import bisect
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen
from fractions import Fraction as F
HERE=Path(__file__).parent

def data_table(src, cache):
    if cache:
        data=(cache/(src['code']+'_'+src['id']+'.txt')).read_bytes()
    else:
        url='https://raw.githubusercontent.com/{repo}/{ref}/{path}'.format(**src)
        request=Request(url,headers={'User-Agent':'table-comparison'})
        with urlopen(request,timeout=40) as reply:
            data=reply.read()
        blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        if blob!=src['sha']:
            raise ValueError('The Git blob hash differs: '+url)
    rows={}
    for line in data.decode().splitlines():
        fields=line.strip().split()
        if not fields or fields[0].startswith('#'):
            continue
        t,rate,sigma=map(F,fields)
        rows[t]=(rate,sigma)
    return rows

def interpolate(rows,grid,t):
    if t in rows:
        return rows[t][0]
    index=bisect.bisect_left(grid,t)
    lo,hi=grid[index-1:index+1]
    return rows[lo][0]+(t-lo)/(hi-lo)*(rows[hi][0]-rows[lo][0])

def check(cache):
    sources=json.loads((HERE/'rate_sources.json').read_text())
    tables={(s['code'],s['id']):data_table(s,cache) for s in sources['sources']}
    output={}
    for item in sources['mapping']:
        name=item['primat_id']
        P,L=tables['primat',name],tables['linx',name]
        grid=sorted(L)
        common=sorted(P.keys() & L.keys())
        assert (len(P),len(L),common)==(1000,60,[F('0.001'),F(10)])
        assert all(P[t]==L[t] for t in common)
        def relative(t):
            return 100*(interpolate(L,grid,t)/P[t][0]-1)
        t0=F('0.7496782')
        points=[t for t in P if F('0.1')<=t<=1 and P[t][0]>0]
        peak=max(points,key=lambda t:abs(relative(t)))
        output[name]=dict(primat=float(P[t0][0]),linx=float(interpolate(L,grid,t0)),
                          relative_percent=float(relative(t0)),sampled_points=len(points),
                          max_abs_at=float(peak),signed_difference_there_percent=float(relative(peak)))
    return output
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--cache',type=Path)
    args=parser.parse_args()
    data=check(args.cache)
    (HERE/'rates_exact.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(data['He3_a__Be7_g']))
