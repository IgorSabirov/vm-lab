# Проверка усреднения R141
Для повтора нужны Python 3, NumPy, SciPy, mpmath и Git. Скопируйте команды получения primat и vm-lab-history из инструкции R141 (раздел «От резонанса до выходов BBN»). Внешние измерения, чужие документы и историю BBN здесь не дублируем.

```sh
git clone --filter=blob:none --no-checkout https://github.com/CyrilPitrou/primat.git primat
git -C primat checkout --detach 6f7e5680614fb119d65a6c9c65a292240b27c61e
git init vm-lab-history
git -C vm-lab-history fetch --depth=1 https://github.com/IgorSabirov/vm-lab.git d503ee0f1f89c99c8560803dc46277d544ef15ba
sha256sum -c MANIFEST.sha256
OPENBLAS_NUM_THREADS=1 python signal_check.py --vm_lab vm-lab-history --primat primat --check
```

Архивная траектория и якобиан читаются из указанных исходных ревизий. Для проверки только этой работы LINX, GSL и pdftotext не нужны.
