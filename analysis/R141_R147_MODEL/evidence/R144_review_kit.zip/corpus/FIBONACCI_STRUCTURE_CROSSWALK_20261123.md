# Фибоначчи в корпусе vm-lab. Какие конструкции действительно его порождают

23 ноября 2026 года · расширение межпроектного указателя R141–R144 по новому отзыву. Предыдущий разбор с источниками сохранён ниже. Обозначения: F₀=0, F₁=1, L₀=2, L₁=1, φ=(1+√5)/2. Индекс n всюду относится к явно указанному объекту.

**Главная новая связь.** Для каждого смешанного двоичного кольца R141 его определитель равен числу возможных причинных прошлых следующего рождения в канонически построенном порядке R086. Для полностью активного кольца доказана точная граничная поправка −2.

В исполняемом R130 обнаружены два точных объекта. Первый — множество всех возможных расположений слияний. Второй — множество состояний фиксированной длины, на которых локальное взаимодействие действует тождественно. У второго объекта матрица переноса сводится в целых координатах к **той же M²**, что и рекурсия определителей R141. Ещё один адрес находится в ядре роста причинных множеств R086–R089: на семействе чередующихся порядков число возможных прошлых следующего рождения равно Fₙ₊₂. Ниже приведены выводы и контроли для смены носителя, границы и числа каналов.

## Карта результатов

| Адрес | Носитель, операция и наблюдаемая | Происхождение и граница |
|---|---|---|
| **R141 → R086** | Граф активных вершин и рёбер кольца задаёт причинный порядок. На смешанном кольце det(I+K) равен числу его нижних идеалов. | **T0.** Есть явное отображение, доказательство через миноры и независимый перебор. |
| **R130, слияния** | Проекция одноканального слова на позиции, где исходный код сливает пару (1,2). На размеченном кольце возможны Lₙ масок. На пути из n вершин — Fₙ₊₁ масок рёбер. | **T0.** Точное описание образа проекции. На конкретном входе код применяет один определённый набор слияний. |
| **R130, неподвижность I** | Полные слова из четырёх символов, у которых один локальный шаг I ничего не меняет. На размеченном кольце их L₂ₙ; на разомкнутой цепи с тем же локальным запретом — F₂ₙ₊₂. | **T0.** Канал один, атомарные различные имена. Пространственный алгоритм подсчёта имеет фактор M². Полный временной шаг F=QI способен вывести состояние из этого множества. |
| **R086–R089, причинное прошлое** | Для чередующегося порядка на n событиях у следующего рождения Fₙ₊₂ возможных множеств предшественников до факторизации по изоморфизмам. | **T0 при заданном родителе.** В ядре транзитивной перколяции при 0<p<1 все эти прошлые имеют положительный вес. Частота появления таких родителей в ансамбле остаётся отдельной величиной. |
| **R134, циклическая перестановка пяти каналов** | На пяти порядках кинематических переменных симметризованный сдвиг имеет спектр 2, φ⁻¹, φ⁻¹, −φ, −φ. Проверенная амплитуда 7/36 лежит целиком в секторе 2. | **T0 для явно построенного оператора.** Контроль ложного переноса на наблюдаемую. |
| **R134, четырёхточечный вычет** | На специально выбранной диагональной сумме вычетов Венециано получается Fₙ₊₁. | Тождество для построенной суммы. Выбор диагонали добавлен в этой работе; отдельной физической роли этой суммы в R134 не установлено. |
| **R133 ↔ Hall.1** | Проверяемая граница между обычным сложением моментов SU(2) и усечённым правилом слияния при уровне 3. | Уровень и тип возбуждения должны следовать из физической постановки. Это адрес кандидата на расширение. |

## Прямой переход R141 → R086. Определитель кольца считает возможные причинные прошлые

Здесь можно обойтись без выбора подходящей длины зигзага. По любому двоичному кольцу w длины n≥3 строим граф G(w): оставляем только вершины с единицей и рёбра кольца, у которых обе вершины активны. Строим его **порядок инцидентности** C(w). Элементами служат активные вершины и активные рёбра; вершина меньше каждого инцидентного ей ребра. Других строгих сравнений нет. Это конечный причинный порядок, на котором определено уже имеющееся ядро транзитивной перколяции. Пусть J(C) — множество нижних идеалов. Тогда

$$
\boxed{\det(I+K(w))=|J(C(w))|-2\,\mathbf 1_{\{w=1^n\}}.}
$$

Переход задан исходным графом, без числовой подгонки. При 0<p<1 каждый идеал имеет положительный вес как прошлое следующего рождения. В равенство входит **число различных помеченных прошлых**. Сумма их вероятностей равна единице.

**Почему формула работает.** По разложению Коши–Бине det(I+BB*) равен сумме квадратов модулей всех миноров B=P(S−I)P, включая пустой минор. Представим B двудольным графом строк и столбцов. Каждая диагональная запись −1 соответствует активной вершине исходного кольца, а каждая запись сдвига +1 — активному ребру. Две такие записи конфликтуют по строке или столбцу точно при инцидентности вершины и ребра. Поэтому выбор попарно совместимых записей — одновременно паросочетание в графе B и антицепь в C(w). Взятие нижнего замыкания биективно переводит антицепи в идеалы.

При наличии нуля двудольный граф распадается на пути и изолированные вершины. Минор имеет не более одного совершенного паросочетания: два разных дали бы чередующийся цикл. Следовательно, каждый непустой набор совместимых записей даёт единичный вклад своего минора, пустой даёт 1. Для серии ℓ активных вершин порядок инцидентности есть зигзаг из 2ℓ−1 элементов. Его F₂ℓ₊₁ идеалов воспроизводят именно множитель R141. У разных компонент выбор прошлых независим как комбинаторная операция.

Для сплошного кольца граф B замыкается в цикл длины 2n. Только у полного минора появляются два совершенных паросочетания — все диагональные записи или все записи сдвига. Их вклады в det(S−I) взаимно уничтожаются. В счёте антицепей оба присутствуют, поэтому поправка равна двум. Соответствующие идеалы — «все вершины, без рёбер» и «все вершины и все рёбра».

| Кольцо | Активный граф | det(I+K) | Возможные прошлые C(w) |
|---|---|---:|---:|
| 010111 | Пути с 1 и 3 вершинами | 26 | 2×13=26 |
| 011011 | Два пути с 2 вершинами | 25 | 5×5=25 |
| 111111 | Цикл из 6 вершин | 320 | L₁₂=322 |
| 000000 | Пустой граф | 1 | 1 |

**Независимая проверка.** Для каждого из всех 4088 размеченных двоичных колец длин 3–11 вычислен плотный целочисленный определитель исходным алгоритмом Барейса R141. Отдельный код считает идеалы непосредственно: перебирает подмножество выбранных вершин U и прибавляет 2 в степени числа рёбер с обоими концами в U. Проверены смешанные, полностью пустые и полностью активные кольца. Перенос в конструкции R142 относится к **тождеству T0**. Вопрос о том, как часто динамика CSG готовит именно C(w) и может ли воспроизвести закон для самих колец, остаётся открытым. [Оператор кольца](https://github.com/IgorSabirov/vm-lab/blob/da82cff22e5a791ea06e04393917bfa062e0af6e/analysis/R141_RIEMANN_CORPUS/spectral/fibonacci.py) · [Вероятности идеалов](https://github.com/IgorSabirov/vm-lab/blob/fd94fd351f1cef2b269529ad07d3116b3040385d/analysis/CSG_MARKED_FUTURE_REVIEW_20261106/MATH.md)

## 1. R130. Все возможные расположения слияний

В одноканальной версии исходник задаёт сплит 3→(1,2) и обратное слияние. Обозначим через bᵢ индикатор пары (wᵢ,wᵢ₊₁)=(1,2). Если bᵢ=1, на следующей позиции стоит 2 и слияние там начаться не может. Обратно, любую маску без соседних единиц реализует исходное слово: на каждом отмеченном ребре поставить (1,2), остальные вершины заполнить нулями. На стыке двух соседствующих димеров возникнет пара (2,1), так что лишнее слияние исключено. Циклическая граница учтена тем же построением.

Отсюда множество возможных масок совпадает со всеми паросочетаниями размеченного кольца. Для n≥3 их число равно tr(Mⁿ)=Lₙ, где M=[[1,1],[1,0]]. На открытом пути из n вершин есть n−1 возможных стартовых рёбер. Разбор «последняя вершина свободна / занята последним димером» даёт Fₙ₊₁. Это объясняет, почему здесь индекс отличается от Fₙ₊₂ в задаче о n свободных битах. При n=2 в самом движке два **ориентированных** старта и три маски; трактовать их как два разных ребра обычного простого неориентированного графа некорректно. Вращения списка при сравнении сохраняют имена вершин; счёт проведён по именованным позициям. [Правило R130](https://github.com/IgorSabirov/vm-lab/blob/fd94fd351f1cef2b269529ad07d3116b3040385d/analysis/ADD_NEIGHBOR_SYNTHESIS_20261117/verify.py#L71) · [Независимый комбинаторный эталон](https://www.sciencedirect.com/science/article/pii/S0166218X23004274)

**Насколько равновероятны маски?** При равномерном выборе из исходных 4ⁿ слов разные маски имеют разное число прообразов. Например, при n=6 всего 18 возможных масок. Из 4096 входов у 2702 нет слияний, у 1254 — одно, у 138 — два, у 2 — три. Для полного распределения запишем uᴺ=∏ᵢ[1+(u−1)bᵢ]. При раскрытии произведения ненулевые члены соответствуют непересекающимся парам. Если фиксированы k пар, свободны n−2k символов. Получаем

$$
\sum_w u^{N(w)}=\sum_{k=0}^{\lfloor n/2\rfloor}
\frac{n}{n-k}\binom{n-k}{k}4^{n-2k}(u-1)^k.
$$

В переборе маски восстановлены по новым именам родителей, возвращённым функцией interact. Проверяющая программа сравнивает их с независимой конструкцией масок и со всеми коэффициентами этого полинома.

## 2. R130. Пространство состояний, неподвижных при локальном взаимодействии

Для фиксированных атомарных имён I оставляет вход на месте тогда и только тогда, когда в слове нет символа 3 и нигде нет пары (1,2). Любой сплит оставляет дочерние имена, любое слияние — новое составное имя, так что одновременные сплит и слияние не скрываются при сохранении длины.

В порядке символов (0,1,2) матрица разрешённых соседств и вложение двух координат имеют вид

$$
A=\begin{pmatrix}1&1&1\\1&1&0\\1&1&1\end{pmatrix},\quad
B=\begin{pmatrix}1&0\\0&1\\1&0\end{pmatrix},\quad
AB=B\begin{pmatrix}2&1\\1&1\end{pmatrix}=BM^2.
$$

Образ A совпадает с плоскостью векторов (a,b,a). Остальное собственное значение равно нулю. На кольце получаем tr(Aⁿ)=tr(M²ⁿ)=L₂ₙ. Для открытого слова q₀=1, q₁=3, qₙ=3qₙ₋₁−qₙ₋₂, откуда qₙ=F₂ₙ₊₂. При равномерном исходном слове вероятность отсутствия локального взаимодействия равна L₂ₙ/4ⁿ. Выбор такой меры указан явно.

| Длина кольца | Все входы | Различные маски слияния | Входы, на которых I тождественно |
|---:|---:|---:|---:|
| 3 | 64 | 4 | 18 |
| 4 | 256 | 7 | 47 |
| 5 | 1 024 | 11 | 123 |
| 6 | 4 096 | 18 | 322 |
| 7 | 16 384 | 29 | 843 |
| 8 | 65 536 | 47 | 2 207 |
| 9 | 262 144 | 76 | 5 778 |

**Связь с R141.** Перенос определителей серий в R141 задан T=[[3,−1],[1,0]]. При C=[[0,1],[−1,2]] имеем T=CM²C⁻¹. В R130 построено явное целочисленное вложение B для той же M². Теперь у общего оператора есть две независимо заданные задачи: добавление позиции к разрешённому слову R130 и удлинение трёхдиагонального блока R141. Значение определителя конкретного кольца и число допустимых слов имеют разные начальные и граничные условия. [Вывод R141](https://github.com/IgorSabirov/vm-lab/blob/da82cff22e5a791ea06e04393917bfa062e0af6e/analysis/R141_RIEMANN_CORPUS/spectral/FIBONACCI.md)

**Две попытки опровергнуть перенос.** Вход (0,2,1) неподвижен при I; после полного шага F=QI получается (0,3,0), и следующий I расщепит вершину. В действующем двухканальном варианте с ε=(+1,−1) запрещены два родителя, 3 и 12, и две пары (1,2), (8,4). При открытых границах q₀=1, q₁=14 и qₙ=14qₙ₋₁−2qₙ₋₂: к любому слову можно приписать 14 символов, затем вычитаются два несовместимых окончания. На кольце счёт равен (7+√47)ⁿ+(7−√47)ⁿ. При n=4 получены 36 856 неподвижных из 65 536 входов. Нераскрашенные маски слияния по-прежнему дают Lₙ, с цветом канала — 2ⁿ+(−1)ⁿ: у каждого выбранного димера два возможных цвета. Для уже заданного графа R140 проверено исходное (1,2,12): два независимых участка действительно имеют четыре варианта выбора, 2². Здесь три разных эксперимента подсчёта. [Код R140](https://github.com/IgorSabirov/vm-lab/blob/7a797cbe6f834d0e723b0af00a66227b4a0191c4/analysis/R140_HAAR_SORKIN/verify.py#L103)

## 3. R086–R089. Сколько причинных прошлых возможно у следующего рождения

В исходном ядре транзитивной перколяции прошлое следующего события — нижний идеал S фиксированного порядка C. При n=|C| его вероятность равна p^|Max S| (1−p)^(n−|S|). Поэтому при 0<p<1 каждое такое прошлое может реализоваться. Вход для нового контрольного опыта — зигзагообразный порядок Zₙ: 0<1>2<3>4⋯, где индексы задают положение вдоль зигзага. Хронологические метки последовательного роста можно задать любым топологическим упорядочением. Такой конечный порядок допустим в исходном процессе: в этом порядке рождения выбираем ровно требуемые прямые связи, а каждый конечный набор этих выборов имеет положительную вероятность.

У каждого идеала есть единственное множество максимальных элементов, образующее антицепь; по нему идеал полностью восстанавливается вниз. В Zₙ сравнимы только соседние вершины. Таким образом максимальные элементы образуют произвольное независимое множество пути. Это даёт **Fₙ₊₂ различных возможных прошлых**. Для n=6 получены 21 прошлое, для цепи — 7, для антицепи — 64. При p=1/3 в зигзаге веса отдельных прошлых лежат от 8/729 до 8/81 и суммируются в единицу. Для n=1…14 проверены все прямые выборы и веса каждого идеала.

В R087 для внутреннего будущего отмеченного события нужен наименьший элемент. Добавим под Zₙ общий корень ⊥. У нового порядка 1+Fₙ₊₂ идеалов, включая пустой. Любой непустой содержит корень, поэтому у условного внутреннего рождения ровно Fₙ₊₂ допустимых прошлых. Проверено для n=1…10. При объединении изоморфных выходов веса складываются. Закон роста числа потомков в R086 и вероятность появления самого зигзага под своим условием сохраняют отдельный смысл. [Ядро R086–R089](https://github.com/IgorSabirov/vm-lab/blob/fd94fd351f1cef2b269529ad07d3116b3040385d/analysis/CSG_MARKED_FUTURE_REVIEW_20261106/MATH.md) · [Rideout–Sorkin](https://doi.org/10.1103/PhysRevD.61.024002) · [Комбинаторный эталон для зигзага](https://sporadic.stanford.edu/reference/combinat/sage/combinat/posets/poset_examples.html)

## 4. R134. Два способа получить φ и Fₙ и проверить их физический смысл

**Пять каналов.** В исходном опыте пять раз циклически переставляют (-1,−2,−1,−2,−4) и получают одну амплитуду 7/36. Для пространства пяти упорядочений определим P как циклическую перестановку и S=P+P⁻¹. Точный характеристический полином S равен (x−2)(x²+x−1)². Повторное выполнение функции амплитуды с 55 десятичными знаками воспроизвело 7/36 во всех пяти порядках с отклонением меньше 10⁻⁴⁵. Вектор ответов постоянен и имеет собственное значение 2. Для наблюдения золотого сектора потребовалась бы новая наблюдаемая, меняющаяся при перестановках.

**Четыре точки.** У одного вычета при полюсе S=k коэффициент при 1/(k−S) равен Rₖ(T)=(1+T)ₖ/k!. На целочисленной диагонали T=m−2k получаем сумму Σₖ Rₖ(m−2k)=Σₖ C(m−k,k)=Fₘ₊₁, где 0≤k≤⌊m/2⌋. Прямой тест выполнен до m=25. При выборе T=0 те же вычеты равны 1, а сумма по тем же k даёт ⌊m/2⌋+1. Происхождение первой формулы — выбор способа агрегации. До появления независимо мотивированного протокола измерения ей соответствует только вычислительный контроль. [Четыре и пять точек в коде R134](https://github.com/IgorSabirov/vm-lab/blob/fd94fd351f1cef2b269529ad07d3116b3040385d/analysis/R134_STRINGS_CONNES_ADD_20261120/verify.py)

## 5. Что осталось от предложений соседей

| Предложение | Решение и критерий |
|---|---|
| E002c/E002d, три узла | Подтверждено. По функциям исходного кода и двум сохранённым таблицам базовые маски 3 и 5 дают сингулярные значения (φ,1,φ⁻¹) матрицы наблюдаемости и нулевую размерность её ядра. У маски 3 расстройка 0,5 меняет старшее значение на 1,704660918; у маски 5 та же расстройка его сохраняет. Перестановки строк и столбцов матрицы наблюдаемости могут различаться. Результат относится к выбранному выходу и весам. |
| R141, дополнение вероятности | Если Hₙ — вероятность для *слова* попасть в класс, в котором встречаются разные определители, то (Lₙ−1+nFₙ₋₂+n(n−3))/(2ⁿ−2) равно **1−Hₙ**. Для n=6 неоднозначны 9 из 62 слов. Порядок усреднения даёт det(I+среднее K)=39200/729 для обоих примеров; средние определителей равны 26 и 25. Проверены исходный код усреднения и все смешанные слова длин 4–11 для события неоднозначности. |
| R142, φ-цепочка и поляритоны | Подстановка, разрешённая метка интегральной плотности состояний, ширина конкретной щели и измеренный поляритонный спектр — четыре различных утверждения. Наличие в R144 поля исходного T0 не присваивает каждому из них одинаковый вид доказательства. Смена контраста и размер аппроксиманта проверяют физическую модель. [Tanese и соавт.](https://doi.org/10.1103/PhysRevLett.112.146404) |
| Hall.1, R133 и фибоначчиевы анионы | В теории SU(2) уровня 3 целочисленный сектор даёт правило 1×1=0+1, эквивалентное τ×τ=1+τ. В обычной SU(2) из R133 у 1⊗1 есть также канал спина 2. Для переноса нужны независимое основание уровня и измерение зарядов/слияния. Само измерение холловской проводимости этих данных не задаёт. [R133](https://github.com/IgorSabirov/vm-lab/blob/fd94fd351f1cef2b269529ad07d3116b3040385d/analysis/R133_LOOP_CONNES_20261120/REPORT.md) · [Golden chain](https://doi.org/10.1103/PhysRevLett.98.160409) · [Эксперимент на процессоре](https://doi.org/10.1038/s41567-024-02529-6) |
| Блокада Ридберга и ADD | Идеальная ближайшая блокада даёт физический эталон языка без соседних возбуждений. В R130 тот же язык теперь выведен для масок слияния. Здесь различаются локальное возбуждение и положение операции, правила подготовки и измеряемые величины. [Кинетическое ограничение в цепочках](https://doi.org/10.1103/PhysRevB.98.155134) |
| Другие подстановки, натриевые кластеры, точки, массы и фазы | Другую подстановку следует проверить по фактическому правилу замены и его матрице. У dot.2 и dot.5 уже есть свой вывод из подсчёта состояний осциллятора. Одиночный размер 55 в кластере, близкое отношение масс и фазовый параметр phi_over_pi не задают рекурсии. COST действительно задаёт золотое сечение в алгоритме минимизации. |
| Пенроуз, ветвление каскадов, отрицательное состояние | Для CCC понадобилось бы найти именно правило подстановки плиток. Периоды каскада удваиваются, а параметр первой суперустойчивой точки логистической карты допускает запись 2φ. Это разные операции. Упомянутое в отзыве отрицательное собственное значение (1−√5)/4 само по себе исключает предложенную матрицу в качестве состояния. Точный адрес этой формулы в просмотренных материалах NOW_FUTURE_STRUCTURE надёжно не установлен. |

## 6. Границы обследования реестра

Проверены три разных масштаба учёта: 137 карточек в RESULTS_REGISTER.json выбранного среза, 608 узлов и 1444 типизированные связи в INDEX.json и 1759 адресных строк по 31 области в матрице R143. В указанном реестре идут R001–R135, затем R142 и R143; R140 и R141 прочитаны по собственным закреплённым веткам. Отдельно прочитаны отзыв, предыдущая карта и текущий R144. В столбце phi матрицы R143 ровно 1742 точки, 7 адресов одной записи E32 и 10 поисковых пометок. Слово «точка» здесь означает пустую ячейку данного поиска. Это обследование реестров с адресной проверкой выбранных исходников; бинарные архивы и каждая трасса корпуса по отдельности в него не входили.

| Пометки «?» матрицы | Что дало чтение |
|---|---|
| HILBERT_POLYA.md, REPORT.md R141 и spectral/ARITHMETIC.md | Отчёты и ссылки на спектральный блок. Арифметические расчёты сами по себе не задают новый механизм Фибоначчи. |
| spectral/fibonacci.json, fibonacci.py, fibonacci_review.py, run_partition_readout.py | Четыре части вычислительного свидетельства R141: сохранённый результат, операторный код, проверка рецензии, счёт классов/серий. |
| #207 | История постановки и продолжения R141. Это адрес для происхождения работы. |
| NOW_RESULTS_SYNTHESIS_20261106, REGISTRY_LINKS | Сводный реестр результатов и навигационный индекс. Они позволяют перейти к родительскому доказательству. |

Семь ссылок E32 — C028, L07, R141, U010, два представления пути FIBONACCI.md и адрес каталога R141. Это одна документированная граница переноса. Выведенные здесь R130 и CSG — новые утверждения этого отчёта. В исходные карточки E32 они не записывались. [Матрица R143](https://github.com/IgorSabirov/vm-lab/blob/3e0b3ef62f0f0b4d9500b9147c561aaf96173afb/analysis/R143_PHYSICAL_GENEALOGY/matrix.tsv) · [Реестр результатов](https://github.com/IgorSabirov/vm-lab/blob/3e0b3ef62f0f0b4d9500b9147c561aaf96173afb/analysis/NOW_RESULTS_SYNTHESIS_20261106/RESULTS_REGISTER.json) · [Узлы и рёбра](https://github.com/IgorSabirov/vm-lab/blob/3e0b3ef62f0f0b4d9500b9147c561aaf96173afb/analysis/REGISTRY_LINKS/INDEX.json)

**Что ещё имеет смысл измерить в корпусе.** Теперь у R130 есть заранее вычисленный контроль для архивных запусков: частота входа в множество I(x)=x по времени для заданного ансамбля начальных колец. Формулу L₂ₙ/4ⁿ можно использовать только при равномерном выборе входного слова при данной n. Для R086–R089 следующий отдельный вопрос — сколько зигзагов возникает в порождённом ансамбле при заранее выбранных p и n; числу возможных прошлых этот вопрос не эквивалентен. У обеих постановок уже есть контроли, которые меняют закон счёта.

## Как повторить

Проверочный ZIP содержит исходные версии файлов по SHA Git, скрипт verify_corpus.py, его полный вывод results.json и настоящий отчёт. При установленных NumPy, SymPy и mpmath выполнить из корня архива:

```sh
python verify_corpus.py > replay.json
python -c "import json; assert json.load(open('replay.json')) == json.load(open('results.json'))"
```

Скрипт проверяет SHA исходников и запускает одноканальный interact на 349 520 входах длин 2–9, двухканальный на 69 888 входах длин 2–4. Для E002, R134 и контрольного фрагмента R140 используются исходные определения функций. Полные транспортные эксперименты и квантовые истории здесь не перезапускались. Формулы для всех n следуют из приведённых рекурсий и биекций. Показанные конечные переборы служат воспроизводимыми проверками.

---

## Предыдущий срез межпроектного указателя

Ниже сохранён первый разбор с одной поправкой к обозначению усреднённого оператора. Открытая в прежней редакции постановка ADD для масок слияния и неподвижности I решена выше.

# Fibonacci: structural crosswalk across vm-lab registries

Date: 2026-11-23. Mode: read-only research, no GitHub changes.

## Scope and repository state

- `main`: `fd94fd351f1cef2b269529ad07d3116b3040385d` (2026-11-22).
- R141: PR #208, branch `research/r141-riemann-corpus`, head `da82cff22e5a791ea06e04393917bfa062e0af6e`.
- R142: PR #213, branch `research/r142-magic-numbers`, head `15052f12371f1366e8e51f5d251033b1376739c0`.
- R143: PR #214, branch `research/r143-physical-genealogy`, head `3e0b3ef62f0f0b4d9500b9147c561aaf96173afb`.
- R140: PR #205, branch `research/r140-haar-sorkin`, head `7a797cbe6f834d0e723b0af00a66227b4a0191c4`.
- R144 was described in the supplied peer analyses; it was not present in the inspected GitHub main branch or PR inventory, so statements about its claim counts remain attributed to the supplied reviews.

### R143 coverage: what the registry really shows

Directly inspected `analysis/R143_PHYSICAL_GENEALOGY/catalog.json`, `evidence.json`, `matrix.tsv`, and `GAPS.md`.

- 31 searched domains; R142 source `CHECKS.json` has 76 claims.
- Matrix: 1,759 address rows x 31 domains. The `phi` column has 1,742 '.' cells, 7 `E32` cells (all pointing to one and the same evidence entry), and 10 '?' search leads. These are **not 17 independent Fibonacci results**.
- E32 has status `A` (transfer boundary) and connects R141 with C028, L07, U010; it does not prove a polariton Hamiltonian is realized in R141.
- `Hall.1` is a separate one-claim domain with status T1/conditional and no R143 address witness in the reviewed evidence. This is a promising *different* Fibonacci entry point, not currently established in vm-lab.

## Confirmed exact constructs

### A. R142: substitution, and a physical gap-labeling donor

Substitution `A -> AB`, `B -> A` has matrix

```
M = [[1, 1],
     [1, 0]]
```

Its Perron eigenvalue is phi = (1+sqrt(5))/2. Frequencies tend to 1/phi and 1/phi^2 (T0 relative to the substitution). The independent tight-binding Fibonacci Hamiltonian for onsite contrast `VB-VA=1` supports the finite approximant gap label 1/phi^2. R142's actual approximants have lengths 34,55,89,144 and gap widths approximately 0.48656, 0.48578, 0.48570, 0.48559 (in hopping units). At VB=VA this gap closes to numerical zero. These are finite model results, not proof of infinite-size gap width.

External physics: Tanese et al., PRL 112, 146404 (2014), observe polariton minigaps satisfying gap labeling in a physical Fibonacci quasiperiodic potential. R141's distinct operator must not be equated with the measured polariton operator without a map.

### B. R141: exact continuant and Lucas boundary

For mixed binary cyclic `w`, let `P=diag(w)`, `B=P(S-I)P`, `K=BB*`. Each run of 1s with length l contributes `D_l = F_(2l+1)`:

```
D_0=1, D_1=2, D_l=3*D_(l-1)-D_(l-2)
det(I+K) = product_over_runs F_(2l+1)
```

For an all-ones cycle, the boundary changes and `det(I+K)=L_(2n)-2`. For `I+tK`, the recurrence changes; `t=1` is crucial. Noncommutativity of determinant and orbit averaging is explicit: `010111 -> 26`, `011011 -> 25`, while their `det(I + average K)` matches `39200/729`. R141 also proves exact Fibonacci/Lucas counts for information-loss classes; these are not independent tests of a physical Fibonacci spectrum.

### C. E002c/E002d: exact observability block (new structural crosswalk)

Source `main/e002c_exp/model.py` uses `D = vstack(c, c@H, c@H@H)`, `c=(0,0,1)` and a 3-node sector Hamiltonian with edges (01,12,02). Baseline edge masks 3 and 5 each have, up to independent row and column permutations, `M direct_sum [1]`. Therefore `singular_values(D)={phi,1,1/phi}` and `rank(D)=3`; **there is no dark null vector** in these two cases. Confirmed directly against E002c and E002d saved metrics.

For mask 3, a detuning epsilon on the middle node gives

```
D3 = [[0,0,1],[0,1,0],[1,epsilon,1]]
charpoly(D3^T D3) = (x-1)*(x^2-(3+epsilon^2)*x+1)
```

At epsilon=0.5 the singular spectrum is ~ (1.7046609181, 1, 0.5866269294), not golden. At epsilon=2 it is (phi^2,1,phi^-2). For mask 5, the baseline detuning does not enter D:

```
D5 = [[0,0,1],[1,0,0],[0,1,1]]
charpoly(D5^T D5) = (x-1)*(x^2-3x+1)
```

Changing edge amplitudes also destroys the numerical golden values. Hence the crosswalk is exactly algebraic and conditioned by selected graph weights, output and model scales. Similarity of singular-value data is **not** a new dark-state observation nor a shared dynamical law.

### D. Exact common algebra at the next level (new identity)

Let `T=[[3,-1],[1,0]]` be the transfer matrix of the R141 continuant. Then the stronger result holds:

```
C = [[0, 1],[-1,2]], det(C)=1
T = C * M^2 * C^-1
```

So the R141 recurrence is integrally conjugate to the square of the R142 Fibonacci substitution. The nontrivial two-dimensional Gram block of the baseline E002c observability matrix also has characteristic polynomial `x^2-3x+1` (equivalently the eigenvalues of `M^2`). These are precise *shared algebraic representations*, not evidence that physical carrier states or measurements transfer.

## New physical Fibonacci candidate: non-Abelian anyon fusion

R142 `Hall.1` / R143 Hall addresses currently discuss quantized Hall conductivity and the Chern index. A separate physically meaningful algebra exists in Fibonacci non-Abelian anyons:

```
tau x tau = 1 + tau
N_tau = [[0,1],[1,1]] = P*M*P,
P = [[0,1],[1,0]].
```

Fusion-space multiplicities satisfy the Fibonacci recurrence, and quantum dimension is exactly phi as a model consequence. This is **different** from R142 quasiperiodic gaps and different from E002c. Main grounded donors:

- Mong et al., PRB 95, 115136 (2017) found numerical support for Read-Rezayi k=3 candidates near nu=12/5,13/5 and competition with other phases. This is theory, not direct braiding verification in GaAs.
- Xu et al., Nature Physics (2024), `s41567-024-02529-6`: simulated Fibonacci anyon braiding on a superconducting processor; reported quantum dimension 1.60 and M_tau,tau near -0.39 versus ideal -1/phi^2. Digital simulation is not an observation of natural GaAs excitations.

Suggested registration: a *new scope* `hall.fibonacci_fusion` linked to `Hall.1`, but not merged with `phi.1`. Classification T0 for fusion-rule consequences; experimental realization and transfer T1/open depending on a specified platform and measured braiding/fusion observables.

## ADD: careful candidate, not a proven Fibonacci automaton

In `main/analysis/ADD_NEIGHBOR_SYNTHESIS_20261117/verify.py`, the full named ADD step is `forward=transport(interact(...))` with an inverse `backward`. Its induced operator on a closed, bijectively permuted finite state set is a permutation matrix (unitary), with spectral radius 1. Therefore its true **time-evolution adjacency operator cannot have a Perron eigenvalue phi**. The peer proposal must be interpreted, if at all, as a matrix counting **admissible configurations**, not the reversible step itself.

R140 shows `m` **independent** flip tiles have `2^m` representations, and on a seed with 2 active domains this is 4, not 3 Fibonacci choices. On `(1,2,0)` at most 1 domain is active on the reached subspace; 92 length histories/40 endpoints after 8 steps stem from superposition, not a Fibonacci recurrence.

A hypothetical nearest-neighbor exclusion constraint yields

```
A = [[1,1],[1,0]], chi_A(x)=x^2-x-1
open-chain words length n: F_(n+2)
cyclic words length n: L_n = trace(A^n)
```

Direct brute force validates these identities up to n=12 (the local audit does **not** establish ADD imposes the rule). To test on actual R130/R140, extract a protocol-defined list of candidate active local rewrites, build a conflict relation, count graph-independent candidate sets under fixed boundaries for increasing lengths, and compare Fibonacci, Lucas and unrestricted 2^n with an actual counterexample-seeking control. Keep name, port, and boundary restrictions, and do not claim the counted operator is U_F.

## Another physical donor: Rydberg blockade

Strong nearest-neighbor Rydberg blockade on an open chain imposes adjacent-excitation exclusion, yielding F_(n+2) allowed bit strings (or L_n for a cycle under a periodic exclusion rule). This provides a clear physical route from constraints to Fibonacci counts with measurable state-space restrictions. Work on dephasing PXP systems also reports modified Fibonacci growth of fragmented sectors (Phys. Rev. Research 8, L032015, 28 July 2026). This does not imply ADD has the same grammar. The existing R143 dot shell counts for Tarucha and the E002c 216-state quantum transport model are different mechanisms.

## Explicit exclusions / negative controls

- `analysis/INVARIANT_ATTACHMENTS_20261105/sources/COST.txt`: `golden_section_minimize` uses golden ratio as a numerical optimization parameter; code method, not physical invariant.
- R142 `sodium` electronic shell counts are not Fibonacci just because some cluster size (e.g. 55) is itself F_10.
- R142 `dot` 2,6,12,20,30,42 and 3D oscillator shell counts are not Fibonacci sequences.
- The logistic map's first superstable bifurcation at r=1+sqrt(5)=2*phi is an algebraic root from a different equation; by itself this is not a Fibonacci substitution mechanism.
- `phi_over_pi` in E002c denotes a magnetic phase ratio, not the golden ratio.
- Penrose conformal cyclic cosmology (CCC) is not a Penrose tiling/quasicrystal construction.

## Proposal: one crosswalk, no duplicated result cards

A `FIBONACCI_STRUCTURE_CROSSWALK` should record one row per **construction** with fields:

`source_ref`, `source_commit`, `carrier/state_space`, `operation`, `operator_matrix`, `boundary_conditions`, `proof_type`, `control_negative`, `observable`, `experimental_donor`, `physical_transfer_gate`, `R142_origin_class`, `R143_address_status`, `R144_symmetry_type`, `status`.

Exact relation types: `EQUIVALENT_UP_TO_ROW_COL_PERMUTATIONS`, `SL2Z_CONJUGATE_TO_M_SQUARED`, `FUSION_MATRIX_BASIS_RELABELLING`, `SHARED_CHARACTERISTIC_POLYNOMIAL`, `TRANSFER_NOT_PROVEN`, `NUMERICAL_ONLY`.

Do not equate singular vectors of an observability matrix with eigenvectors of the Hamiltonian; do not promote an algebraic T0 to an experimental T1; do not route R143 unknown `?` entries as independent E32 witnesses.

## Sources / precise provenance

- R141 math and code: https://github.com/IgorSabirov/vm-lab/blob/da82cff22e5a791ea06e04393917bfa062e0af6e/analysis/R141_RIEMANN_CORPUS/spectral/FIBONACCI.md
- R142 checks and approximants: https://github.com/IgorSabirov/vm-lab/blob/15052f12371f1366e8e51f5d251033b1376739c0/analysis/R142_MAGIC_NUMBERS/CHECKS.json
- R142 execution: https://github.com/IgorSabirov/vm-lab/blob/15052f12371f1366e8e51f5d251033b1376739c0/analysis/R142_MAGIC_NUMBERS/EXECUTED.md
- R143 matrix: https://github.com/IgorSabirov/vm-lab/blob/3e0b3ef62f0f0b4d9500b9147c561aaf96173afb/analysis/R143_PHYSICAL_GENEALOGY/matrix.tsv
- R143 E32: https://github.com/IgorSabirov/vm-lab/blob/3e0b3ef62f0f0b4d9500b9147c561aaf96173afb/analysis/R143_PHYSICAL_GENEALOGY/EVIDENCE.md#e32
- E002c code: https://github.com/IgorSabirov/vm-lab/blob/fd94fd351f1cef2b269529ad07d3116b3040385d/e002c_exp/model.py
- E002c metrics: https://github.com/IgorSabirov/vm-lab/blob/fd94fd351f1cef2b269529ad07d3116b3040385d/results/E002c_CAL_v002_r001/files/metrics.json
- E002d metrics: https://github.com/IgorSabirov/vm-lab/blob/fd94fd351f1cef2b269529ad07d3116b3040385d/results/E002d_CAL_v001_r001/files/metrics.json
- R130 engine: https://github.com/IgorSabirov/vm-lab/blob/fd94fd351f1cef2b269529ad07d3116b3040385d/analysis/ADD_NEIGHBOR_SYNTHESIS_20261117/verify.py
- R140 coins: https://github.com/IgorSabirov/vm-lab/blob/7a797cbe6f834d0e723b0af00a66227b4a0191c4/analysis/R140_HAAR_SORKIN/REPORT.md
- R143 Hall.1: https://github.com/IgorSabirov/vm-lab/blob/3e0b3ef62f0f0b4d9500b9147c561aaf96173afb/analysis/R143_PHYSICAL_GENEALOGY/CATALOG.md
- Tanese polaritons: https://doi.org/10.1103/PhysRevLett.112.146404
- Mong et al. RR3: https://doi.org/10.1103/PhysRevB.95.115136
- Xu et al. Fibonacci braiding: https://www.nature.com/articles/s41567-024-02529-6
- Rydberg fragmentation: https://doi.org/10.1103/691w-6cx8

## Reproducibility

Run `python fibonacci_crosswalk_audit.py` in the same directory as the accompanying JSON output. The script uses NumPy and SymPy and runs offline; it is an independent *local reproduction of the formulas read from GitHub*, not a byte-for-byte run of the E002c production pipeline. The output `fibonacci_crosswalk_audit.json` includes matrices, conjugators, controls and counts.
