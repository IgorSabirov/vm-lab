"""Offline audit. Run in the extracted directory: python verify_corpus.py"""
import ast
import csv
import hashlib
import itertools
import json
import math
import runpy
from collections import Counter
from fractions import Fraction
from pathlib import Path

import mpmath as mp
import numpy as np
import sympy as sp

HERE = Path(__file__).resolve().parent
SRC = HERE / "src"
R130 = runpy.run_path(str(SRC / "add"))
X = sp.Symbol("x")


def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def lucas(n):
    return fib(n-1) + fib(n+1)


def read_json(name):
    return json.loads((SRC / name).read_text())


def selected_functions(name, names, namespace):
    """Execute the unchanged definitions selected from a pinned module."""
    tree = ast.parse((SRC / name).read_text())
    definitions = [v for v in tree.body if isinstance(v, ast.FunctionDef) and v.name in names]
    assert len(definitions) == len(names)
    module = ast.Module(body=definitions, type_ignores=[])
    exec(compile(module, name, "exec"), namespace)
    return namespace


def cycle_counts(n, alphabet, eps):
    pairs = {(1, 2): 1}
    if len(eps) == 2:
        pairs[(8, 4)] = 2
    parents = {3} if len(eps) == 1 else {3, 12}
    quiet = 0
    footprints, colored = set(), set()
    distribution = Counter()
    after_transport = None
    for word in itertools.product(range(alphabet), repeat=n):
        graph = R130["named"](word)
        output = R130["interact"](graph, eps)
        # Infer actual merges directly from a new parent name made of two old atoms.
        merged = {u[1][1]: s for u, s in output if u[0] == "v"}
        expected = {i: (3 if q == 1 else 12) for i in range(n)
                    if (q := pairs.get((word[i], word[(i + 1) % n])))}
        assert merged == expected
        bitmask = sum(1 << i for i in merged)
        footprints.add(bitmask)
        colored.add(tuple(sorted(merged.items())))
        distribution[len(merged)] += 1
        fixed = R130["equal"](graph, output)
        assert fixed == (not merged and all(t not in parents for t in word))
        quiet += fixed
        if fixed and after_transport is None:
            nxt = R130["forward"](graph, eps)
            if not R130["equal"](nxt, R130["interact"](nxt, eps)):
                after_transport = [list(word), list(R130["word"](nxt))]
    expected_masks = {mask for mask in range(1 << n)
                      if not (mask & (((mask << 1) & ((1 << n)-1)) | (mask >> (n-1))))}
    assert expected_masks == footprints and len(footprints) == lucas(n)
    # Inclusion–exclusion in the full alphabet; no uniformity of masks assumed.
    pred = sp.Poly(sum((n * math.comb(n-k, k) // (n-k)) * len(pairs)**k
                       * alphabet**(n-2*k) * (X-1)**k for k in range(n//2+1)), X)
    assert all(distribution[j] == pred.nth(j) for j in range(n//2+1))
    if len(eps) == 1:
        assert quiet == lucas(2*n)
    else:
        assert quiet == int(sp.trace(sp.Matrix([[14, -2], [1, 0]])**n))
        assert len(colored) == 2**n + (-1)**n
    return dict(n=n, words=alphabet**n, masks=len(footprints), colored_masks=len(colored),
                unchanged_I=quiet, distribution=dict(sorted(distribution.items())), activation=after_transport)


def open_controls():
    rows = []
    for n in range(1, 11):
        allowed = sum(all(w[i:i+2] != (1, 2) for i in range(n-1))
                      for w in itertools.product(range(3), repeat=n))
        assert allowed == fib(2*n+2)
        rows.append([n, allowed])
    return rows


def csg_check(n):
    # Alternating valleys are the even sites, including site 0.
    edges = [(j, i) for i in range(1, n, 2) for j in (i-1, i+1) if j < n]
    full = (1 << n) - 1
    def close(a):
        return a | sum(1 << i for i in range(0,n,2)
                       if any(a & (1 << j) for j in (i-1,i+1) if 0 <= j < n))
    probabilities = Counter()
    for a in range(full+1):
        k = a.bit_count()
        # p=1/3; numerators with the common denominator 3**n.
        probabilities[close(a)] += 2**(n-k)
    for ideal, weight in probabilities.items():
        assert all(not (ideal >> v & 1) or ideal >> u & 1 for u, v in edges)
        maxima = {v for v in range(n) if ideal >> v & 1}
        maxima -= {u for u, v in edges if ideal >> v & 1}
        m, s = len(maxima), ideal.bit_count()
        assert weight == 2**(n-s) * 3**(s-m)
    assert sum(probabilities.values()) == 3**n and len(probabilities) == fib(n+2)
    return dict(n=n, ideals=len(probabilities), chain=n+1, antichain=2**n,
                weight_sum=1, min_weight=str(Fraction(min(probabilities.values()),3**n)),
                max_weight=str(Fraction(max(probabilities.values()),3**n)))


def operator_checks():
    M = sp.Matrix([[1,1],[1,0]])
    C = sp.Matrix([[0,1],[-1,2]])
    T = sp.Matrix([[3,-1],[1,0]])
    assert C*M**2*C.inv() == T and C.det() == 1
    quiet = sp.ones(3); quiet[1,2] = 0
    # Also verify the integral two-state quotient on the invariant range:
    # vectors (a,b,a) map to (2a+b,a+b).
    B = sp.Matrix([[1,0],[0,1],[1,0]])
    assert quiet*B == B*M**2
    engine = selected_functions('e002', {'sector_hamiltonian','dark_projectors','null_projector'},
          {'np':np, 'PAIRS':((0,1),(1,2),(0,2))})
    golden = (1+math.sqrt(5))/2
    e_cases = []
    for mask in (3,5):
        for detuning in (0,.5):
            H = engine['sector_hamiltonian'](mask,epsilon=detuning)
            spec = engine['dark_projectors'](H)[-1]['D']
            assert spec['dimension'] == 0
            if mask == 5 or detuning == 0:
                np.testing.assert_allclose(spec['singular_values'],[golden,1,1/golden],atol=1e-13)
            else:
                assert abs(spec['singular_values'][0]-golden) > .05
            if not detuning:
                for name in ['m2c','m2d']:
                    saved = read_json(name)['cases'][0]['dark_geometry'][mask]['D']
                    np.testing.assert_allclose(saved['singular_values'],spec['singular_values'],atol=1e-13)
            e_cases.append([mask,detuning,spec['singular_values']])
    # A regular cyclic relabelling on the five channels. The symmetric operation is derived.
    P = sp.eye(5)[:,[1,2,3,4,0]]
    S = P+P.T
    assert sp.factor(S.charpoly(X).as_expr()) == (X-2)*(X**2+X-1)**2
    v = sp.ones(5,1)*sp.Rational(7,36)
    assert S*v == 2*v
    mp.mp.dps = 55
    five = selected_functions('r134v',{'five'},{'mp':mp})['five']
    seq=(-1,-2,-1,-2,-4)
    for j in range(5):
        u,a,b,v0,c=seq[j:]+seq[:j]
        assert abs(five(u,v0,a,b,c)-mp.mpf(7)/36) < mp.mpf('1e-45')
    # R140 uses R130 for I and uniquely named local tiles.
    box=selected_functions('r140code', {'rooted','tiling','flip_named','labelled_blocks'},
                           {'E':R130,'EPS':(1,-1)})
    graph=R130['named']((1,2,12))
    keys=[u for u,_,fine in box['tiling'](graph) if fine is not None]
    corners={box['flip_named'](graph,mask) for j in range(len(keys)+1) for mask in itertools.combinations(keys,j)}
    assert len(corners)==4
    return dict(quiet_charpoly=str(sp.factor(quiet.charpoly(X).as_expr())),quotient=M.__pow__(2).tolist(),
                r140_corners=len(corners),R134_charpoly=str(sp.factor(S.charpoly(X).as_expr())),
                R134_amplitude='7/36 (five cyclic orders)',E002=e_cases)


def other_controls():
    ring = runpy.run_path(str(SRC / 'lead4'))
    averages = ring['orders']()
    assert [r['det_average'] for r in averages.values()] == ['39200/729']*2
    # Compare event "the (weight, number of runs) class allows two determinants".
    rows = []
    for n in range(4, 12):
        groups = {}
        for w in itertools.product((0,1), repeat=n):
            if sum(w) in (0,n): continue
            runs=sum(w[i] and not w[i-1] for i in range(n))
            word=''.join(map(str,w))
            det=ring['bareiss'](ring['original_matrix'](word))
            groups.setdefault((sum(w),runs),[]).append(det)
        ambiguous=sum(len(g) for g in groups.values() if len(set(g))>1)
        exceptional=lucas(n)-1+n*fib(n-2)+n*(n-3)
        assert ambiguous+exceptional == (1<<n)-2
        rows.append([n,ambiguous,exceptional])
    # CSG with one marked bottom under the entire fence. Verify by ideals, including the empty one.
    rooted=[]
    for n in range(1,11):
        edges=[(j,i) for i in range(1,n,2) for j in (i-1,i+1) if j<n]
        edges += [(n,i) for i in range(n)]
        ideals=sum(all(not (a>>v&1) or a>>u&1 for u,v in edges) for a in range(1<<(n+1)))
        assert ideals-1==fib(n+2)
        rooted.append([n,ideals-1])
    diagonal=[]
    for n in range(26):
        observable=sum(sp.rf(1+n-2*k,k)/sp.factorial(k) for k in range(n//2+1))
        assert observable==fib(n+1)
        diagonal.append(int(observable))
    return dict(R141_ambiguous_exceptional=rows, R141_orbit_average=averages,
                CSG_nonempty_with_marked_bottom=rooted, R134_chosen_diagonal=diagonal)


def incidence_bridge():
    ring = runpy.run_path(str(SRC / 'lead4'))
    rows, samples = [], {}
    for n in range(3,12):
        checked = 0
        for w in itertools.product((0,1), repeat=n):
            active = [i for i,b in enumerate(w) if b]
            edges = [(i,(i+1)%n) for i in active if w[(i+1)%n]]
            # A lower ideal contains a subset of vertices. Any edge whose two
            # endpoints occur can independently be included or omitted.
            ideals=0
            for choices in itertools.product((0,1),repeat=len(active)):
                vertices={i for i,b in zip(active,choices) if b}
                ideals += 1 << sum(u in vertices and v in vertices for u,v in edges)
            word=''.join(map(str,w))
            dense=ring['bareiss'](ring['original_matrix'](word))
            assert dense == ideals - 2*int(all(w))
            checked += 1
            if word in ('010111','011011','111111','000000'): samples[word]=[dense,ideals]
        rows.append([n,checked])
    return dict(counts=rows,total=sum(k for n,k in rows),det_and_ideals=samples)


def coverage():
    reg, idx = read_json('results'), read_json('regindex')
    rows=list(csv.DictReader((SRC/'matrix').open(),delimiter='\t'))
    return dict(result_cards=len(reg['results']),index_nodes=len(idx['nodes']),index_edges=len(idx['edges']),
                matrix_rows=len(rows),domains=len(rows[0])-1,
                phi=dict(Counter(r['phi'] for r in rows)),
                search_leads=[r['address'] for r in rows if r['phi']=='?'])


def main():
    source_manifest = read_json('manifest') if (SRC/'manifest').exists() else {}
    for k, expected in source_manifest.items():
        if 'sha' not in expected: continue
        content=(SRC/k).read_bytes()
        assert hashlib.sha1(f'blob {len(content)}\0'.encode()+content).hexdigest()==expected['sha'], k
    report = dict(coverage=coverage(), operators=operator_checks(), additional=other_controls(), incidence=incidence_bridge(),
                  one_channel=[cycle_counts(n,4,(1,)) for n in range(2,10)],
                  two_channels=[cycle_counts(n,16,(1,-1)) for n in range(2,5)],
                  open_quiet=open_controls(), csg_fence=[csg_check(n) for n in range(1,15)])
    print(json.dumps(report,ensure_ascii=False,indent=2,default=int))
if __name__=='__main__':
    main()
