"""Validate the extracted R144 v0.4 delivery. Use --full for both independent replays."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import jsonschema

ROOT = Path(__file__).resolve().parent

def read(path):
    return json.loads((ROOT/path).read_text())

def validate():
    data = read('R144_CANONICAL.json')
    old = read('history/v03/R144_CANONICAL.json')
    jsonschema.Draft202012Validator.check_schema(read('r144.schema.json'))
    jsonschema.validate(data, read('r144.schema.json'))
    for spec in read('migration_patch.json'):
        key = spec['path'][1:]
        if spec['op'] == 'test': assert old[key] == spec['value']
        elif spec['op'] in ('add','replace'): old[key]=spec['value']
        else: raise AssertionError(spec)
    assert old == data
    for name, sha in read('manifest.json').items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha, name
    def idx(key):
        rows=data[key]
        out={r['id']:r for r in rows}
        assert len(out)==len(rows)==len({k.casefold() for k in out})
        return out
    statements,relations,claims,actions,systems,structures,quantities=map(idx,['statements','relations','claims','actions','systems','structures','quantities'])
    archive=read('history/v03/R144_CANONICAL.json')
    assert data['claims']==archive['claims'] and data['evidence']==archive['evidence']
    for k in ('statements','relations','systems','structures','actions','quantities'):
        assert data[k][:len(archive[k])]==archive[k]
    new=data['corpus_context']; source_ids=set(data['sources'])
    assert set(new)=={s['id'] for s in statements.values() if s['claim_id'] is None}
    assert len(new)==18 and len(statements)==122 and len(relations)==28
    for k,s in statements.items():
        assert s['claim_id'] is None or s['claim_id'] in claims
        assert s['action_id'] in actions and set(s['source_refs'])<=source_ids
        assert s['quantity_id'] is None or s['quantity_id'] in quantities
        assert k in data['derivation_families'][s['derivation_id']]
    for a in actions.values():
        assert a['system_id'] in systems and a['structure_id'] in structures
    for r in relations.values():
        assert {r['source'],r['target']}<=statements.keys()
        assert set(r['evidence'])<=source_ids|set(claims)|{e['id'] for e in data['evidence']}
        assert r['type'] in data['relation_vocabulary']
    corpus=read('corpus/results.json')
    assert corpus==data['corpus_results']
    assert corpus['incidence']['total']==4088 and corpus['incidence']['det_and_ideals']=={'000000':[1,1],'010111':[26,26],'011011':[25,25],'111111':[320,322]}
    assert sum(t['words'] for t in corpus['one_channel'])==349520 and sum(t['words'] for t in corpus['two_channels'])==69888
    assert corpus['csg_fence'][5]['ideals']==21 and corpus['operators']['r140_corners']==4
    assert corpus['coverage']['phi']=={'.':1742,'E32':7,'?':10}
    assert not data['scientific_acceptance']
    print('PASS v0.4 schema, migration, source hashes, baseline preservation, links and numerical controls',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--full',action='store_true')
    args=parser.parse_args()
    validate()
    old_cmd=[sys.executable,'verify_r144.py']
    if args.full: old_cmd.append('--full')
    subprocess.run(old_cmd,cwd=ROOT/'history/v03',check=True)
    if args.full:
        actual=json.loads(subprocess.check_output([sys.executable,'verify_corpus.py'],cwd=ROOT/'corpus'))
        assert actual==read('corpus/results.json')
        print('PASS full independent corpus replay',flush=True)
