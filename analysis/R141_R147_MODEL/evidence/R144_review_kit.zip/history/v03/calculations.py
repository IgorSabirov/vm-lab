"""R144 numerical and exact controls. Standard Python, optional independent cascades in cascade.py."""
from math import pi, sqrt, exp, comb,prod
from fractions import Fraction
from itertools import product
from collections import Counter
from decimal import Decimal
import hashlib,json

def compute(raw):
    source={c['id']:c for c in raw['claims']}
    c=299792458.; mpc=3.0856775814913673e22
    a0=1.2e-10; target=1/(2*pi)
    mond=[dict(H0=h,ratio=a0/(c*(h*1000/mpc)),relative_to_target=a0/(c*(h*1000/mpc))/target-1) for h in [67.4,73.]]
    masses=source['Koide.1']['inputs'];me,mu,tau=[masses[k] for k in ['e','mu','tau']]
    q=lambda m:(me+mu+m)/(sqrt(me)+sqrt(mu)+sqrt(m))**2
    a=sqrt(me)+sqrt(mu);disc=6*a*a-3*(me+mu)
    roots=[(2*a+x*sqrt(disc))**2 for x in [-1,1]]
    inv_alpha=137.035999177
    ratio=(6.62607015e-34/(2*pi))*c/(inv_alpha*6.67430e-11*1.67262192595e-27*9.1093837139e-31)
    lam=3*.6847*(67.4*1000/mpc)**2*(1.616255e-35)**2/c**2
    rh=10973731.568157/(1+5.446170214889e-4)
    br=[dict(n=n,archive=source[f'Balmer{n}.1']['value'],archive_from_RH=1e9/(raw['rydberg_per_m']['hydrogen']*(.25-1/n**2)),codata2022=1e9/(rh*(.25-1/n**2))) for n in range(3,7)]
    fact=exp(pi/1.00624)
    return dict(mond=mond,mond_target=target,mond_H0_for_equality=2*pi*a0*mpc/(1000*c),koide=dict(Q=q(tau),excess=q(tau)-2/3,tolerance=source['Koide.1']['tolerance'],branches=roots,branch_residuals=[q(x)-2/3 for x in roots]),dirac=ratio,lambda_lP2=lam,rho_ratio=lam/(8*pi),balmer=br,efimov=dict(length=fact,energy_scale=fact**2,residual=(21-fact)/1.3),alpha_z={k:(source[k]['value']-inv_alpha)/2.1e-8 for k in ['alpha136.1','alpha137.1','alpha137.03608.1']})

def det_bareiss(a):
    a=[list(r) for r in a]; prev=1
    for i in range(len(a)-1):
        pivot=a[i][i]
        assert pivot
        for j in range(i+1,len(a)):
            for k in range(i+1,len(a)):
                num=a[j][k]*pivot-a[j][i]*a[i][k]
                assert num%prev==0
                a[j][k]=num//prev
        prev=pivot
    return a[-1][-1]

def ring(w):
    n=len(w)
    b=[[w[i]*w[j]*(int(j==(i+1)%n)-int(i==j)) for j in range(n)] for i in range(n)]
    h=[[int(i==j)+sum(b[i][k]*b[j][k] for k in range(n)) for j in range(n)] for i in range(n)]
    return det_bareiss(h)
def matrix_component(power):
    a,b=1,0
    for _ in range(power): a,b=a+b,a
    return a
def fibonacci_checks():
    counts=0
    for n in range(3,10):
        for w in product(range(2),repeat=n):
            if not 0<sum(w)<n:continue
            k=w.index(0); runs=''.join(map(str,w[k:]+w[:k])).split('0')
            assert ring(w)==prod(matrix_component(2*len(r)) for r in runs if r)
            counts+=1
    return dict(mixed_words=counts,n_min=3,n_max=9,examples=[ring(tuple(map(int,w))) for w in ['010111','011011']],all_zero=ring((0,)*6),all_one=ring((1,)*6))
