"""Independent finite-depth superstable-cycle replay; does not edit GitHub.

Families:
  logistic f_r(x)=r*x*(1-x) (critical point 1/2)
  sine     f_r(x)=r*sin(pi*x) (critical point 1/2)
  quartic  f_r(x)=1-r*x**4 (critical point 0)
For each n, r_n is the first *new* parameter above r_(n-1) with
f_r^(2^n)(c)=c. Ratio at period 2^n: (r_(n-1)-r_(n-2))/(r_n-r_(n-1)).
Requires scipy and mpmath. Double-precision bracketing is refined at 50 dps.
"""
import math
import mpmath as mp
import numpy as np
from scipy.optimize import brentq

mp.mp.dps=50

def f_iter(m,r,n,high=False):
    x = (mp.mpf('0') if m=='quartic' else mp.mpf('0.5')) if high else (0.0 if m=='quartic' else 0.5)
    for i in range(2**n):
        if m=='logistic': x = r*x*(1-x)
        elif m=='quartic': x=1-r*x**4
        else: x=r*(mp.sin(mp.pi*x) if high else math.sin(math.pi*x))
    return x-((mp.mpf('0') if m=='quartic' else mp.mpf('0.5')) if high else (0.0 if m=='quartic' else 0.5))

def bisect_mp(fun,a,b,n=120):
    a,b=mp.mpf(str(a)),mp.mpf(str(b))
    fa=fun(a)
    fb=fun(b)
    assert fa*fb<0,(a,b,fa,fb)
    for _ in range(n):
        mid=(a+b)/2; fm=fun(mid)
        if fm==0:return mid
        if fa*fm<0:b,fb=mid,fm
        else:a,fa=mid,fm
    return (a+b)/2

def sequence(m, limit=10):
    if m=='logistic':roots=[mp.mpf(2),1+mp.sqrt(5)]; maxr=4
    elif m=='quartic':roots=[mp.mpf(1)]; maxr=2
    else:roots=[mp.mpf('0.5')]; maxr=1
    for n in range(2 if m=='quartic' else len(roots), limit+1):
        last=float(roots[-1]); gap=float(roots[-1]-roots[-2]) if len(roots)>1 else 0.9
        end=min(last+gap, maxr)
        grid=np.linspace(last+1e-11, end,150)
        vals=[f_iter(m,r,n) for r in grid]
        candidates=[(a,b) for a,b,fa,fb in zip(grid,grid[1:],vals,vals[1:]) if fa*fb<0]
        if not candidates:raise ValueError(f'No crossing: {m} {n} {last} {end}')
        a,b=candidates[0]
        r0=brentq(lambda r:f_iter(m,r,n),a,b,xtol=1e-14)
        # Bound narrow enough to exclude earlier or later roots; wide enough to cover double error
        w=max(1e-13, min(1e-7, 0.005*(r0-last)))
        f=lambda r:f_iter(m,r,n,high=True)
        root=bisect_mp(f,r0-w,r0+w)
        roots.append(root)
        if len(roots)>=3:
            delta=(roots[-2]-roots[-3])/(roots[-1]-roots[-2])
            print(f'{m:8} n={n:2} period={2**n:4} delta={mp.nstr(delta,20)} r={mp.nstr(root,30)}')
    return roots

if __name__=='__main__':
    for m in ('logistic','sine','quartic'):
        print('\n==',m,'==')
        sequence(m,10)
