"""Run inside the extracted kit: python verify_r144.py [--full]. Uses jsonschema, scipy and (with --full) mpmath."""
import json, hashlib,sys, subprocess, math, re, copy
from pathlib import Path
from collections import Counter
from itertools import product, permutations
from fractions import Fraction as F
from decimal import Decimal as D
import jsonschema
from calculations import compute, fibonacci_checks
import checks_export
p=Path(__file__).resolve().parent
def load(name):return json.loads((p/name).read_text())
def verify(d,sch,raw):
 out=[]
 def check(name,condition):
    if not condition:raise AssertionError(name)
    out.append(name)
 def idx(key):
    rows=d[key]; m={x['id']:x for x in rows}
    check('ID уникальны с проверкой регистра: '+key,len(m)==len(rows)==len({i.casefold() for i in m}))
    return m
 jsonschema.Draft202012Validator.check_schema(sch)
 jsonschema.validate(d,sch);check('JSON Schema Draft 2020-12',True)
 cs=idx('claims');ss=idx('statements');qq=idx('quantities');aa=idx('actions');sy=idx('systems');sc=idx('structures');ev=idx('evidence');ad=idx('address_statements');rr=idx('relations');ds=idx('domains');ps=idx('positions')
 check('Срез 43/76/31/54; scope всех исходных claims', [len(x) for x in [ps,cs,ds,ev]]==[43,76,31,54] and {s['claim_id'] for s in ss.values()}==set(cs))
 check('Совпадение всех 76 исходных строк с CHECKS', {c['id']:c for c in raw['claims']}=={i:c['source'] for i,c in cs.items()})
 check('Разрешение действий, систем, алгебр и накрытий', all(a['system_id'] in sy and a['structure_id'] in sc for a in aa.values()) and all(x[k] in sc for x in sc.values() for k in ['lie_algebra_id','double_cover_of'] if k in x))
 check('Ссылки всех научных формулировок',all(s['action_id'] in aa and s['derivation_id'] in d['derivation_families'] and s['origin_tier']==cs[s['claim_id']]['source']['tier'] and (s['quantity_id'] in qq or s['quantity_id'] is None) and set(s['source_refs'])<=d['sources'].keys() for s in ss.values()))
 check('Все величины адресованы',set(qq)=={s['quantity_id'] for s in ss.values() if s['quantity_id']})
 check('Ссылки позиций и доменов',all((c['position_id'] in ps or c['position_id'] is None) and c['domain_id'] in ds for c in cs.values()))
 check('Типизированные научные отношения',all(r['source'] in ss and r['target'] in ss and r['type']!='NUMERIC_COLLISION_ONLY' and r['evidence'] for r in rr.values()))
 eligible_references=set(cs)|set(ev)|set(d['sources'])
 check('Источники всех рёбер разрешаются по идентификаторам',all(set(r['evidence'])<=eligible_references for r in rr.values()))
 check('Область и эквивалентность для трёх кристаллографических классификаций',all(ss[s]['quantity_id'] in qq and qq[ss[s]['quantity_id']]['value']==v['types'] for s,v in d['classification_conventions'].items()) and len(d['classification_conventions'])==3)
 check('Области и флаги свидетельств',all(x['evidence_id'] in ev and x['statement_id'] in (ss|ad) for x in d['evidence_links']) and {x['evidence_id'] for x in d['evidence_links']}==ev.keys())
 check('E01: технический результат и граница N=20',any(x['evidence_id']=='E01' and x['statement_id']=='dot.4/count' and x['supports_model_result'] for x in d['evidence_links']) and not any(x['supports_experimental_claim'] for x in d['evidence_links'] if x['statement_id']=='dot.4/Tarucha1996'))
 counts=Counter(e['legacy_code'] for e in ev.values())
 check('Роли R143 по исходным кодам',counts=={'A':15,'S':15,'D':14,'P':3,'T':7} and sum(counts[k] for k in 'SDPT')==39)
 check('Поисковые исходы и границы',len(d['search_trials'])==15 and all(t['evidence'] in ev and t['prospective']==False for t in d['search_trials']))
 aliases=d['case_sensitive_aliases']
 check('Все 61 историческое имя и 62 основных claim',len(aliases)==61 and len({ss[s]['claim_id'] for entries in aliases.values() for s in entries})==62)
 check('Точные псевдонимы квантовых точек',aliases['dot2d.K2']==['dot.4/count'] and aliases['dot2d.k2']==['dot.3/count'] and Counter(k.casefold() for k in aliases).most_common(1)==[('dot2d.k2',2)])
 check('Атомарные исключения из P-указателя',len(d['auxiliary_claims'])==14 and all(i in cs and cs[i]['position_id'] is None and set(x['parent_claims'])<=cs.keys() for i,x in d['auxiliary_claims'].items()))
 check('Перепись T-ярусов и смешанный вход',Counter(c['source']['tier'].split()[0] for c in cs.values())=={'T0':23,'T1':39,'T2':4,'T3':4,'T4':6} and cs['angle.1']['source']['tier']=='T2 device / T1 conditional prediction')
 vals=[F(str(x['reference_value'])) for x in ps.values()]
 check('Типы меток по математической целочисленности',len(set(vals))==43 and sum(v.denominator==1 for v in vals)==33)
 groups=d['collision_index']; pairs=sum(math.comb(len(rs),2) for rs in groups.values())
 check('37 пар, 9 повторных ключей, размерность индекса',pairs==37 and sum(len(rs)>1 for rs in groups.values())==9 and sum(map(len,groups.values()))==61)
 def equivalent(rows):
    return {tuple(sorted((x['id'],y['id']))) for j,x in enumerate(rows) for y in rows[j+1:] if x['domain']!=y['domain'] and x['family']==y['family']}
 selected=[dict(id=i,domain=c['domain_id'],family=c['derivation_id']) for i,c in cs.items()]
 inverse={str(n):x['id'] for n,x in enumerate(selected)}
 ren=[dict(x,id=str(n)) for n,x in enumerate(selected)]
 check('ANONYMIZED_LABEL_PRESERVATION_TEST: 42+1, семейства и домены доступны',len(equivalent(selected))==43 and {tuple(sorted(inverse[i] for i in pair)) for pair in equivalent(ren)}==equivalent(selected))
 assigned=[dict(id=i,domain=c['domain_id'],family=c['model_mechanism']['id']) for i,c in cs.items() if c['model_mechanism']['id']]
 back={str(n):c['id'] for n,c in enumerate(assigned)}
 shuffled=[dict(c,id=str(n)) for n,c in enumerate(assigned)]
 check('ANONYMIZED_MECHANISM_LABEL_PRESERVATION_TEST: перестановка имён при фиксированных назначениях',all(c['id'] in d['model_mechanism_families'][c['family']] for c in assigned) and {tuple(sorted(back[i] for i in pair)) for pair in equivalent(shuffled)}==equivalent(assigned))
 trial=d['blind_protocol'];check('Протокол независимой проверки не выдаёт готовую метку',trial['status']=='NOT_EXECUTED_INDEPENDENTLY' and all(set(x)=={'id','problem'} for x in trial['reviewer_packet']))
 def q(i):return qq[ss[i]['quantity_id']]['value']
 for dim,n,kmax in [(2,'dot',5),(3,'osc3',6)]:
    y=[2*sum(sum(t)<=k for t in product(range(k+1),repeat=dim)) for k in range(kmax+1)]
    check('Прямое перечисление изотропных состояний '+str(dim),y==[2*math.comb(k+dim,dim) for k in range(kmax+1)]==[q(f'{n}.{i+1}/count') for i in range(kmax+1)])
 check('Атомная ёмкость всех шести слоёв',all(q(f'atomic.{n}/capacity')==2*sum(2*l+1 for l in range(n)) for n in range(1,7)))
 inp=cs['nuclear.1']['source']['inputs'];sm=0;shells=[]
 for level,num in inp['ordered_levels']:
    sm+=num
    if level in inp['assumed_boundaries']:shells.append(sm)
 check('Ядерный ряд при заданных границах',shells==[q(f'nuclear.{i}/source') for i in range(1,8)])
 ani=[2*sum(2*x+y<=w for x,y in product(range(w+1),repeat=2)) for w in range(8)]
 check('Соизмеримые частоты, перечисление и коммутатор',ani==q('dot.4/ratio2to1') and all(2*(x+1)+(y-2)==2*x+y for x in range(6) for y in range(2,9)))
 check('Точные алгебраические эталоны',32*31//2==2*248==496 and 2*(16*15//2)==240 and 248+1==249 and 230-11==219 and 26-26==0 and 3*10/2-26+11==0)
 check('Коиде: две точные S₃-орбиты',all({F(sum(t),sum(math.isqrt(k) for k in t)**2) for t in permutations(a)}=={b} for a,b in [((1,4,9),F(7,18)),((1,4,16),F(3,7))]))
 v=compute(raw)
 check('Пересчёт MOND, Λ, Дирака, Бальмера, Эфимова, α и Коиде',v==d['numerical_results'])
 check('Источник MOND + два отдельных результата',q('MOND.1/target')==v['mond_target'] and all(q('MOND.1/H'+str(t['H0']).replace('.','_'))==t['ratio']!=v['mond_target'] for t in v['mond']))
 check('Коиде, обе ветви и допуск исходной записи',all(abs(x)<2e-14 for x in v['koide']['branch_residuals']) and abs(v['koide']['excess'])<v['koide']['tolerance'])
 check('Архивное и метрологическое вычисления Бальмера',all(abs(x['archive_from_RH']/x['archive']-1)<2e-15 and abs(x['codata2022']/x['archive']-1)<9e-12 for x in v['balmer']))
 check('R141: прямые целочисленные определители против степеней матрицы',fibonacci_checks()==d['ring_check'] and d['ring_check']['examples']==[26,25])
 triples=[('logistic',lambda r,x:r*x*(1-x),2,1+math.sqrt(5),.5),('sine',lambda r,x:r*math.sin(math.pi*x),.5,checks_export.brentq(lambda r:r*math.sin(math.pi*r)-.5,.7,.9),.5),('quartic',lambda r,x:1-r*x**4,0,1,0)]
 for k,fun,r0,r1,xc in triples:
    r=d['computational_derivations'][k];repeat=checks_export.cascade(fun,r0,r1,xc)['ratios'][-1]
    check('Архивная процедура binary64 '+k,abs(repeat-r['archive_1024'])<2e-7) # libm/BLAS/runtime can differ; exact match reported for pinned run
    seq=r['samples']['roots'];at={t['period']:t for t in seq}
    for pp in (1024,2048,4096):
        df=(D(at[pp//2]['root'])-D(at[pp//4]['root']))/(D(at[pp]['root'])-D(at[pp//2]['root']))
        assert abs(df-D(at[pp]['delta']))<D('1e-21')
    check('Первичный период и конечная оценка '+k,all(D(t['half_residual'])>D('1e-10') and D(t['residual'])<D('1e-26') for t in seq))
 # Negative schema/semantic controls, separate from scientific falsification.
 for label,mut in [('неизвестный вердикт',lambda x:x['statements'][0].update(scientific_verdict='ACCEPT_ALL')),('неизвестный тип числа',lambda x:x['quantities'][0].update(value_kind='MAGIC'))]:
    bad=copy.deepcopy(d);mut(bad)
    check('Негативная мутация: '+label,not jsonschema.Draft202012Validator(sch).is_valid(bad))
 return out
def apply_patch(old,ops):
 new=old.copy()
 for op in ops:
    k=op['path'][1:]
    if op['op']=='remove':del new[k]
    else:new[k]=op['value']
 return new
if __name__=='__main__':
 data=load('R144_CANONICAL.json');sch=load('r144.schema.json');raw=load('CHECKS.json')
 for group in verify(data,sch,raw):print('PASS',group)
 old=load('v02_registry.json');ops=load('migration_patch.json')
 assert apply_patch(old,ops)==data
 assert (data if data.get('version')=='0.3' else apply_patch(data,ops))==data
 print('PASS migration from frozen v0.2')
 for f,sha in load('manifest.json').items():
    assert hashlib.sha256((p/f).read_bytes()).hexdigest()==sha,f
 print('PASS source and file digests')
 if '--full' in sys.argv:
    v=json.loads(subprocess.check_output([sys.executable,str(p/'cascade.py')]))
    for k in v:
        assert v[k]==data['computational_derivations'][k]['samples']
    print('PASS fresh 45/60-dps cascades to period 4096')
