"""Reproduce the primary superstable cascade. Python + mpmath. No network.
Seeds at small periods are analytic or bracketed. At each doubling scan the previous
parameter gap from left to right, refine the first resolved sign change by bisection.
A finite scan does not prove that no root was skipped. Verify the primitive period.
A second precision run repeats the calculation and checks the reported digits.
"""
import json, math
import mpmath as mp

def orbit(name,r,p,high):
    c=(mp.mpf('0') if name=='quartic' else mp.mpf('0.5')) if high else (0. if name=='quartic' else .5)
    x=c
    if name=='logistic':
        for _ in range(p): x=r*x*(1-x)
    elif name=='sine':
        if high:
            for _ in range(p): x=r*mp.sin(mp.pi*x)
        else:
            for _ in range(p): x=r*math.sin(math.pi*x)
    else:
        for _ in range(p): x=1-r*x*x*x*x
    return x-c

def run(name,dps):
    mp.mp.dps=dps
    roots={1:mp.mpf(1)} if name=='quartic' else {0:mp.mpf('0.5' if name=='sine' else '2')}
    if name=='logistic': roots[1]=1+mp.sqrt(5)
    rows=[]
    for n in range(max(roots)+1,13):
        last=roots[n-1]
        span=last-roots[n-2] if n-2 in roots else mp.mpf('.9')
        hi=float(min(last+span,{'quartic':2,'sine':1,'logistic':4}[name]))
        left=float(last)+min(1e-10,float(span)*1e-4)
        p=2**n
        a=left
        fa=orbit(name,a,p,False)
        for i in range(1,257):
            b=left+(hi-left)*i/256
            fb=orbit(name,b,p,False)
            if fa*fb<0: break
            a,fa=b,fb
        else:raise ArithmeticError((name,n,'bracket not found'))
        a,b=mp.mpf(str(a)),mp.mpf(str(b))
        fa,fb=orbit(name,a,p,True),orbit(name,b,p,True)
        assert fa*fb<0
        original=[str(a),str(b)]
        while b-a>mp.mpf(10)**(-dps+9):
            m=(a+b)/2
            fm=orbit(name,m,p,True)
            if fm==0:
                a=b=m
                break
            if fa*fm<0:b=m
            else:a,fa=m,fm
        root=roots[n]=(a+b)/2
        assert root>last and abs(orbit(name,root,p//2,True))>mp.mpf('1e-10') and abs(orbit(name,root,p,True))<mp.mpf('1e-26')
        rows.append({'period':p,'bracket':original,'half_residual':mp.nstr(abs(orbit(name,root,p//2,True)),12),'residual':mp.nstr(abs(orbit(name,root,p,True)),12)})
    for row in rows:
        n=row['period'].bit_length()-1
        row['root']=mp.nstr(roots[n],32)
        row['delta']=mp.nstr((roots[n-1]-roots[n-2])/(roots[n]-roots[n-1]),28) if n-2 in roots else None
    return {'seeds':{str(2**k):mp.nstr(v,32) for k,v in roots.items() if 2**k < rows[0]['period']},'roots':rows}
if __name__=='__main__':
    out={}
    for name in ['logistic','sine','quartic']:
        a,b=run(name,45),run(name,60)
        for x,y in zip(a['roots'],b['roots']):
            if x['delta'] is not None: assert abs(mp.mpf(x['delta'])-mp.mpf(y['delta'])) < mp.mpf('1e-22')
        out[name]=b
    print(json.dumps(out,indent=2))
