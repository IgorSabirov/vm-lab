#!/usr/bin/env python3
"""Independent convergence check for the finite-frame QBP isometry defect.
For B_x=x sigma_x x^dagger and P the constant-frame projector,
||I-(QBP)^dagger(QBP)|| = ||PBP||_2^2 = ||mean_x B_x||_2^2.
"""
import json
from pathlib import Path
import numpy as np

def su2(rng,n):
    q=rng.normal(size=(n,4))
    q/=np.linalg.norm(q,axis=1)[:,None]
    a,b,c,d=q.T
    X=np.empty((n,2,2),dtype=complex)
    X[:,0,0]=a+1j*b
    X[:,0,1]=c+1j*d
    X[:,1,0]=-c+1j*d
    X[:,1,1]=a-1j*b
    return X

sx=np.array([[0,1],[1,0]],dtype=complex)
out=[]
for n in (100,400,1600,6400):
    rng=np.random.default_rng(700000+n)
    defects=[]
    for _ in range(100):
        X=su2(rng,n)
        B=X@sx@X.conj().transpose(0,2,1)
        Bmean=B.mean(axis=0)
        # Spectral norm squared is exactly the Gram defect on the constant sector.
        defects.append(float(np.linalg.norm(Bmean,2)**2))
    mean=float(np.mean(defects))
    out.append({"n":n,"replicates":100,"seed":700000+n,
                "mean_gram_defect":mean,"n_times_mean":n*mean,
                "standard_error":float(np.std(defects,ddof=1)/np.sqrt(len(defects)))})
result={"observable":"||I-(QBP)^dagger(QBP)||_2 = ||PBP||_2^2",
        "exact_Haar_limit":0,"asymptotic_expectation":"E[defect]=1/n for isotropic unit vectors in R^3",
        "results":out}
Path('/mnt/data/qbp_convergence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
