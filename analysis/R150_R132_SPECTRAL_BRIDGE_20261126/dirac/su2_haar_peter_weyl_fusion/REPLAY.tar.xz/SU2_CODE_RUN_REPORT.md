# SU(2) Haar / Peter-Weyl / fusion code: execution audit

**Result:** corrected combined run completed; all structural assertions passed. The original attachment contains several successive code attempts, two of which contain dimensional/indexing errors. This report distinguishes exact representation-theoretic statements from finite Monte Carlo checks.

## 1. Haar sample and Schur twirl

40,000 normalized Gaussian quaternions were converted to SU(2) matrices. Maximum unitarity error: `5.56e-16`; maximum determinant error: `6.68e-16`.

For the fundamental irreducible representation,

`T(B) = integral_G x^dagger B x dx = (Tr B / 2) I`.

Monte Carlo Frobenius errors against this exact result:

| Input B | Frobenius error |
|---|---:|
| sigma_x | 0.00946750 |
| I | 2.22e-19 |
| sigma_x + I/2 | 0.00946750 |

The identity is exact sample-by-sample. Traceless parts converge to zero at Monte Carlo rate.

**Correction to the source test:** the exact Haar twirl is idempotent and its image is the commutant. The empirical finite-sample map is not exactly a projector. For the trace-free test operator, `||T1||=0.00742766`, `||T2||=4.66167e-5`, `||T2-T1||=0.00739987`; an independent finite twirl also differs from T1 by `0.00732267`. Thus a default `np.allclose(T1,T2)` is false. The mathematical projector claim is correct for the exact integral, not for the finite empirical average.

Adjoint average norm: `0.00600346`; fundamental-vector average norm: `0.00326178`, consistent with zero in the Haar limit.

## 2. Matter 1 -> 0 -> 1 algebraic control

`O(I,eta)=1`, `O(i sigma_x,eta)=0`, `O(i sigma_x,(i sigma_x)^dagger eta)=1`.

This is an algebraic reversible-state check. It is not, by itself, a dynamical matter-generation mechanism.

## 3. QBP isometry

For `B_x = x sigma_x x^dagger`, each sample is Hermitian and unitary with `B_x^2=I` (maximum numerical involution error `8.89e-16`). Let P project onto constant frame sections. In the exact Haar model, `PBP=0`; therefore

`(QBP)^dagger(QBP) = P B Q B P = P B^2 P - P B P B P = P`.

This proves that QBP is an isometry in the exact Haar model.

For the finite sample `n=400`: `||PBP||_2=0.0391852`, `||PBv||=0.0391852`, `||QBv||=0.999232`; isometry Gram defect `0.00153548`. This is a finite-sampling approximation, not exact zero. An independent 100-replicate convergence check gives mean squared defect `1.1258/n` (n=100), `1.0407/n` (400), `0.8652/n` (1600), `0.9187/n` (6400), consistent with the expected O(1/n) defect.

## 4. Covariant transport

With `Psi_chi(x)=x^dagger chi` and `B_x=x^dagger B0 x`,

`B_x Psi_chi(x) = x^dagger B0 chi`.

Measured maximum deviation: `1.49e-15`. The right-translation gauge invariance check has maximum deviation `9.39e-16`. This part is an exact algebraic identity, numerically verified to machine precision.

## 5. Peter-Weyl content

For `f(x)=x sigma_x x^dagger psi`, each component is a matrix coefficient of the adjoint (spin-1) representation. Therefore its Peter-Weyl support is exactly `j=1` in the continuum Haar model.

At sample size 1,500, the ordinary all-pairs V-statistic contains a diagonal bias `d_j^2/m`, where `d_j=2j+1`. Its raw weights were:

| j | raw V-statistic |
|---:|---:|
| 0 | 0.000405 |
| 1/2 | 0.003754 |
| 1 | 1.010156 |
| 3/2 | 0.008962 |
| 2 | 0.016223 |
| 5/2 | 0.019532 |

The sum `1.05903` is not a probability normalization; the excess is principally the diagonal bias. Removing diagonal pairs gives the unbiased U-statistic:

| j | off-diagonal U-statistic |
|---:|---:|
| 0 | -0.000262 |
| 1/2 | 0.001088 |
| 1 | 1.004826 |
| 3/2 | -0.001706 |
| 2 | -0.000444 |
| 5/2 | -0.004471 |

Sum: `0.999031`. The small negative side weights are Monte Carlo noise, not negative exact spectral probabilities. This is consistent with a single exact atom at j=1.

For Casimir convention `C2=j(j+1)` (generators `i sigma_a/2`), the eigenvalue is 2 on j=1 and 3/4 on j=1/2. If the Feshbach coupling range is exactly this j=1 channel and QBP is the isometry above, then the continuum self-energy is

`Sigma_av(E) = h^2/(E-2) P`.

This conclusion is conditional on the specified Casimir kinetic operator and the stated coupling; it is not a result for an arbitrary frame Hamiltonian.

## 6. Fusion and relative mode

The corrected model uses spinor fibers of dimension two: old space dimension 6 (`p,v1,v2`), fused space dimension 4 (`p,w`), with `w=c1 v1+c2 v2` and `|c1|^2+|c2|^2=1`. The embedding J is an isometry (maximum error `3.14e-16`). For h=1:

| (c1,c2) | `||Q B P||` | best `h'` | minimum intertwining residual | `PBQBP` on p |
|---|---:|---:|---:|---:|
| (1,0) | 0 | 1 | 0 | 0 |
| (0.8,0.6) | 0.6 | 0.8 | 0.6 | 0.36 |
| (1/sqrt(2),1/sqrt(2)) | 0.707107 | 0.707 | 0.707107 | 0.5 |
| (0.6,0.8) | 0.8 | 0.6 | 0.8 | 0.64 |

The exact formulas are `h'=h c1`, relative coupling `h c2`, and positive Feshbach numerator `h^2 |c2|^2 I_2`. For nonzero h, exact intertwining within the restricted fused ansatz (only p-w coupling, no retained relative channel) requires `c2=0`. This is not a universal no-go if the relative channel or an energy-dependent effective operator is retained. `PBQBP` is the numerator/weight; the full Feshbach self-energy also has the relative-channel resolvent denominator.

## 7. Z2 spin sign

`k=i sigma_x` satisfies `k^2=-I`. The adjoint action of the center `-I` is trivial, while the fundamental spinor changes sign. All three checks returned `True`.

## 8. Defects in earlier code attempts

1. The earlier 5x5/3x3 fusion versions mix a one-dimensional port with 2x2 spinor blocks. Assignment `B_old[0,1:3] = h*I2` raises `ValueError: could not broadcast input array from shape (2,2) into shape (2,)`. The final 6x6/4x4 spinor-fiber version fixes the dimensions.
2. The first Peter-Weyl Gram expression `einsum('ni,ki->ik',...)` has shape `(2,m)`, not `(m,m)`.
3. The first pair-angle expression `einsum('nij,nkj->ik',...)` has shape `(2,2)`, not `(m,m)`. The later `einsum('iba,kba->ik',...)` is the correct pairwise trace.
4. The raw Peter-Weyl all-pairs estimator includes diagonal bias; use off-diagonal pairs or explicitly subtract `d_j^2/m`.
5. Finite Monte Carlo Haar averaging does not satisfy exact idempotence or exact invariance. State this as a convergence test, not an exact numerical equality.

## Verdict

The corrected run supports the exact representation-theoretic statements: Schur twirl, QBP isometry in the Haar limit, covariant transport, pure j=1 Peter-Weyl support, the restricted fusion obstruction and the Z2 spin sign. The finite computations are consistent with these statements after correcting sampling bias. The original attachment is not one clean executable script: it contains failed intermediate versions and a final corrected fusion block. The combined corrected runner and its JSON output are attached separately.
