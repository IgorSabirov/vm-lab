import numpy as np
from time import perf_counter

rng=np.random.default_rng(11)
I2=np.eye(2,dtype=complex)
sx=np.array([[0,1],[1,0]],dtype=complex)
sy=np.array([[0,-1j],[1j,0]],dtype=complex)
sz=np.diag([1,-1]).astype(complex)
psi=np.array([1,0],dtype=complex)

def su2(n):
    q=rng.normal(size=(n,4))
    q/=np.linalg.norm(q,axis=1)[:,None]
    a,b,c,d=q.T
    X=np.empty((n,2,2),dtype=complex)
    X[:,0,0]=a+1j*b
    X[:,0,1]=c+1j*d
    X[:,1,0]=-c+1j*d
    X[:,1,1]=a-1j*b
    return X

def twirl_batch(X,B):
    return np.mean(X.conj().transpose(0,2,1) @ B @ X,axis=0)

def char_su2(n,x):
    # chi_j(theta) = U_(2j)(cos(theta)); stable also at theta=0,pi
    if n==0: return np.ones_like(x)
    u0=np.ones_like(x)
    u1=2*x
    if n==1: return u1
    for _ in range(1,n):
        u0,u1=u1,2*x*u1-u0
    return u1

out={}

# Haar sampling and group validity
X=su2(40000)
unit=np.max(np.abs(X.conj().transpose(0,2,1)@X-np.eye(2)))
det=np.max(np.abs(np.linalg.det(X)-1))
out['haar_sample']={'n':len(X),'max_unitarity_error':float(unit),'max_det_error':float(det)}

# Schur twirl: finite Monte Carlo approximates the exact projector
rows=[]
for B,name in [(sx,'sigma_x'),(I2,'identity'),(sx+0.5*I2,'sigma_x_plus_half_I')]:
    T=twirl_batch(X,B)
    predicted=np.trace(B)/2*I2
    rows.append({'name':name,'twirl':T.tolist(),'predicted':predicted.tolist(),'fro_error':float(np.linalg.norm(T-predicted))})
out['haar_twirl']=rows
B0=sx+0.3*sz+0.2j*sy
T1=twirl_batch(X,B0)
T2=twirl_batch(X,T1)
Tind=twirl_batch(X[:2000],T1)
out['finite_projector_diagnostic']={
    'trace_free_input':True,
    'norm_T1':float(np.linalg.norm(T1)),
    'norm_T2':float(np.linalg.norm(T2)),
    'norm_T2_minus_T1':float(np.linalg.norm(T2-T1)),
    'norm_independent_twirl_T1_minus_T1':float(np.linalg.norm(Tind-T1)),
    'interpretation':'The exact Haar map is a projector; a finite empirical average is not exactly idempotent or exactly invariant.'}
Badj=np.mean(X@sx@X.conj().transpose(0,2,1),axis=0)
fund=np.mean(X@psi,axis=0)
out['no_invariant_vectors']={'adjoint_average_norm':float(np.linalg.norm(Badj)),'fundamental_average_norm':float(np.linalg.norm(fund))}

# Matter 1 -> 0 -> 1 test
eta=psi.copy(); Xx=1j*sx
O=lambda A,p: abs(eta.conj()@A@p)**2
out['matter_test']={'O_I_eta':float(O(I2,eta)),'O_i_sx_eta':float(O(Xx,eta)),'O_i_sx_inverse_eta':float(O(Xx,Xx.conj().T@eta))}

# QBP on a finite Haar frame
n=400
Xs=su2(n)
Bx=Xs@sx@Xs.conj().transpose(0,2,1)
Bmean=Bx.mean(axis=0)
Bv=np.einsum('nij,nj->ni',Bx,np.tile(psi,(n,1))/np.sqrt(n))
P=lambda v: np.broadcast_to(v.mean(axis=0),v.shape)
v0=np.tile(psi,(n,1))/np.sqrt(n)
Bv=np.einsum('nij,nj->ni',Bx,v0)
PBv=P(Bv); QBv=Bv-PBv
# On the constant subspace, (QBP)^dagger(QBP)=I-(PBP)^dagger(PBP).
out['QBP_isometry']={
    'n':n,'norm_v':float(np.linalg.norm(v0)),'norm_Bv':float(np.linalg.norm(Bv)),
    'norm_PBP_on_constant_sector':float(np.linalg.norm(Bmean,2)),
    'norm_PBv':float(np.linalg.norm(PBv)),'norm_QBv':float(np.linalg.norm(QBv)),
    'isometry_gram_error':float(np.linalg.norm(np.eye(2)- (np.eye(2)-Bmean.conj().T@Bmean),2)),
    'max_Bx_unitarity_error':float(np.max(np.abs(Bx.conj().transpose(0,2,1)@Bx-np.eye(2)))),
    'max_Bx_involution_error':float(np.max(np.abs(Bx@Bx-np.eye(2))))}

# Covariant transport of physical sections
chi=rng.normal(size=2)+1j*rng.normal(size=2)
Psi=np.array([x.conj().T@chi for x in Xs])
B0=sx+0.4*sz
BPsi=np.array([(x.conj().T@B0@x)@(x.conj().T@chi) for x in Xs])
expected=np.array([x.conj().T@(B0@chi) for x in Xs])
resid=BPsi-expected
k=Xs[7]
UkPsi=np.array([k@((x@k).conj().T@chi) for x in Xs])
out['covariant_transport']={'max_B_mapping_deviation':float(np.max(np.abs(resid))),'max_Uk_invariance_deviation':float(np.max(np.abs(UkPsi-Psi)))}

# Peter-Weyl spectral measure for f(x)=Ad_x(sigma_x) psi
m=1500
Xm=su2(m)
f=np.array([x@sx@x.conj().T@psi for x in Xm])
normf=float(np.mean(np.sum(np.abs(f)**2,axis=1)))
gram=np.real(f.conj()@f.T)
dots=np.real(np.einsum('iba,kba->ik',Xm.conj(),Xm))/2
dots=np.clip(dots,-1,1)
th=np.arccos(dots)
weights=[]
weights_u=[]
for twice_j in range(6):
    chi_j=char_su2(twice_j,dots)
    j=twice_j/2
    d=2*j+1
    mat=chi_j*gram
    w=d*np.mean(mat)/normf
    wu=d*(np.sum(mat)-np.trace(mat))/(m*(m-1)*normf)
    weights.append({'j':j,'fraction_v_statistic':float(w),'diagonal_bias':float(d*d/m),'fraction_u_statistic':float(wu)})
out['peter_weyl']={'sample_size':m,'normf':normf,'weights':weights,'sum_v_statistic':float(sum(x['fraction_v_statistic'] for x in weights)),
                  'sum_u_statistic':float(sum(x['fraction_u_statistic'] for x in weights)),
                  'expected_support':'j=1 only; f is a matrix-coefficient vector in the adjoint representation'}

# Fusion: spinor fibers dim 2, old dim 6, fused dim 4
h=1.0
def fusion(c1,c2):
    c1,c2=complex(c1),complex(c2)
    nrm=np.hypot(abs(c1),abs(c2)); c1/=nrm; c2/=nrm
    B_old=np.zeros((6,6),dtype=complex)
    B_old[0:2,2:4]=h*I2
    B_old[2:4,0:2]=h*I2
    J=np.zeros((6,4),dtype=complex)
    J[0:2,0:2]=I2
    J[2:4,2:4]=c1*I2
    J[4:6,2:4]=c2*I2
    Jw=J[2:6,2:4]
    Pf=np.zeros((6,6),dtype=complex)
    Pf[0:2,0:2]=I2
    Pf[2:6,2:6]=Jw@Jw.conj().T
    Qf=np.eye(6)-Pf
    rel=np.linalg.norm(Qf@B_old@Pf,2)
    def Bnew(hp):
        Bn=np.zeros((4,4),dtype=complex)
        Bn[0:2,2:4]=hp*I2
        Bn[2:4,0:2]=hp*I2
        return Bn
    hs=np.linspace(0,1.2*h,4801)
    errs=np.array([np.linalg.norm(B_old@J-J@Bnew(hp),2) for hp in hs])
    kb=int(np.argmin(errs))
    Wt=Pf@B_old@Qf@B_old@Pf
    weight=float(np.trace(Wt[0:2,0:2]).real/2)
    return {'c1':float(abs(c1)),'c2':float(abs(c2)),'isometry_error':float(np.linalg.norm(J.conj().T@J-np.eye(4))),
            'relative_coupling':float(rel),'expected_relative_coupling':float(h*abs(c2)),
            'grid_best_hprime':float(hs[kb]),'analytic_hprime':float(h*abs(c1)),
            'grid_intertwining_error':float(errs[kb]),'analytic_intertwining_error':float(h*abs(c2)),
            'feshbach_weight':weight,'expected_feshbach_weight':float(h*h*abs(c2)**2)}

out['fusion']=[fusion(1,0),fusion(.8,.6),fusion(1/np.sqrt(2),1/np.sqrt(2)),fusion(.6,.8)]

# Z2 spin sign
k=1j*sx
out['Z2_spin_sign']={'square_minus_identity':bool(np.allclose(k@k,-I2)),
                      'adjoint_action_trivial':bool(np.allclose((k@k)@sx@(k@k).conj().T,sx)),
                      'fundamental_spinor_changes_sign':bool(np.allclose(k@k@psi,-psi))}

# Diagnostics for malformed earlier code variants
out['source_code_issues']=[
    'Earlier 5x5/3x3 fusion code mixes a 1-dimensional port with 2x2 spinor blocks: assigning h*I2 to B_old[0,1:3] is a shape error. Corrected 6x6/4x4 spinor-fiber version is run above.',
    'The first Peter-Weyl dots einsum has output shape 2x2, not m x m; the later pairwise trace einsum is the correct one.',
    'Finite Monte Carlo twirl is not an exact projector; idempotence and intertwining hold for the exact Haar integral, not the finite sample.'
]

# Assertions on exact structural identities and finite numerical tolerances
assert unit < 1e-12 and det < 1e-12
assert max(x['fro_error'] for x in rows) < 0.02
assert out['QBP_isometry']['max_Bx_involution_error'] < 1e-12
assert out['covariant_transport']['max_B_mapping_deviation'] < 1e-12
assert out['covariant_transport']['max_Uk_invariance_deviation'] < 1e-12
assert max(abs(x['fraction_u_statistic']-(1.0 if x['j']==1 else 0.0)) for x in weights) < 0.08
assert abs(sum(x['fraction_u_statistic'] for x in weights)-1) < 0.08
for r in out['fusion']:
    assert abs(r['relative_coupling']-r['expected_relative_coupling']) < 1e-12
    assert abs(r['feshbach_weight']-r['expected_feshbach_weight']) < 1e-12
    assert abs(r['grid_intertwining_error']-r['analytic_intertwining_error']) < 0.001
assert all(out['Z2_spin_sign'].values())

import json
from pathlib import Path
Path('/mnt/data/su2_audit_results.json').write_text(json.dumps(out,indent=2,allow_nan=False,default=lambda z: {'real':float(z.real),'imag':float(z.imag)} if isinstance(z,complex) else str(z))+'\n')
for k,v in out.items():
    print('\n###',k)
    print(json.dumps(v,indent=2,allow_nan=False,default=lambda z: {'real':float(z.real),'imag':float(z.imag)} if isinstance(z,complex) else str(z)))
print('\nALL ASSERTIONS PASSED')
