# X26 ADD–R040 loading patch v0.2.0

Overlay this patch on the complete `X26_R040_ANALYTIC_BATH_v0_1.tar.xz` package from PR #2, preserving relative paths. The patch replaces the listed package files and adds the integrated ADD/Phi/Psi interfaces.

```bash
tar -xJf X26_R040_ANALYTIC_BATH_v0_1.tar.xz
 tar -xJf X26_ADD_R040_PATCH_v0_2.tar.xz -C X26_R040_ANALYTIC_BATH
```

The package root after overlay contains the updated `pyproject.toml`, `README.md`, `X26_MAPPING_POSTULATES.md`, `RELEASE_v0_2.md`, and new `x26r040` modules/configuration.

The new full CLI is `python -m x26r040.full_cli`. The untouched template intentionally blocks: explicit accepted model assumptions and complete input data are required. This source patch is not ADD-derived physical validation and is not a VM submission.
