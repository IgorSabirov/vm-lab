# Symmetric matrix signature

This library calculates the numerical signature `(positive, negative, zero)`
of a real symmetric matrix. It is separate from the Triangulator library and
does not modify its sources.

## Numerical method

The matrix is checked before any element is indexed. Non-square matrices,
non-symmetric matrices, non-finite entries and invalid tolerances are rejected
with a status value and an error log. Symmetry is checked on the original
entries, before scaling.

Valid input is divided by a nearby power of two. This avoids adding rounding
error to binary input values during normalization. The upper and lower matrix
triangles are averaged only when their difference is inside the configured
symmetry tolerance. The normalized matrix is factorized in place with bounded
Bunch-Kaufman rook pivoting,

```text
P * A * P^T = L * D * L^T,
```

where `D` contains `1 x 1` and `2 x 2` pivot blocks. The inertia is the triple
counting the positive, negative and zero eigenvalues. It follows from the signs
of these blocks by Sylvester's law. The implementation is self-contained and
does not call LAPACK, BLAS or another numerical library.

If normalization would turn a nonzero symmetric entry into zero, the function
returns `STATUS_NUMERICAL_RANGE_ERROR` instead of a signature.
The eigenvalue cutoff is

```text
zero_absolute_tolerance / normalization_scale
  + dimension * zero_relative_tolerance * normalized_frobenius_norm.
```

For a positive cutoff `c`, the positive count comes from the inertia of
`A - c*I`, and the negative count from the inertia of `A + c*I`. Thus the code
does not compare the sizes of the `D` pivots with an eigenvalue tolerance.
The Frobenius norm is invariant under orthogonal changes of basis and bounds
the spectral radius from above.

The default absolute tolerances are zero. The default symmetry-relative
coefficient is `64 * epsilon`, and the default zero-relative coefficient is
`8 * epsilon`. The effective cutoff is never smaller than the same roundoff floor,
`8 * epsilon * dimension * normalized_frobenius_norm`, even if both requested
tolerances are zero. This prevents roundoff residue in a singular matrix from
being reported as a reliable sign. The signature is also checked at `c/8` and
`8*c`; sensitivity inside that interval is reported through
`Result::numerically_ambiguous` and a warning log. No floating-point routine
can distinguish an exact zero from every sufficiently small nonzero
eigenvalue, so the effective cutoff is part of the public result.
`Result::zero_tolerance` contains it in the units of the input.

For scientific use, `Result::reliable()` is a minimum diagnostic gate, not a
certificate of accuracy. The caller must still justify the tolerances and any
symmetry averaging. An ambiguous result is diagnostic only: its signature can
depend on rounding when an eigenvalue is on the cutoff boundary, and it must
be checked with a justified different cutoff or higher precision before use.
`reliable()` is also false when the upper and lower matrix triangles had to be
averaged.

The factorization requires `O(n^3)` operations, one `O(n^2)` matrix buffer and
`O(n)` additional workspace. The caller's matrix is not changed. The pivoting
method follows Bunch and Kaufman's
[inertia algorithm](https://doi.org/10.1090/S0025-5718-1977-0428694-0) and the
bounded rook strategy documented for
[Netlib DSYTF2_ROOK](https://www.netlib.org/lapack/explore-html/d7/d6d/dsytf2__rook_8f_source.html).

## Build and test

CMake 3.15, a C++11 compiler, IEEE double precision, round-to-nearest and
gradual underflow are required. Unsafe floating-point options such as
`-ffast-math`, finite-only math and `-Ofast` must not be used. CMake forces
`-fno-fast-math` for GCC-style compilers, while Clang source pragmas also
disable reciprocal and reassociative transformations in manual builds. CMake
uses `/fp:strict` for MSVC and clang-cl; manual MSVC builds must use the same
option, and `/fp:fast` is rejected. There are no external numerical
dependencies.

```sh
cmake -S . -B build -DSYMMETRIC_MATRIX_SIGNATURE_WARNINGS_AS_ERRORS=ON
cmake --build build
ctest --test-dir build --output-on-failure
```

The inertia properties test uses strict diagonal dominance, principal
submatrices and rank-one updates as independent checks of the computed counts.

The public header is `include/symmetric_matrix_signature.hpp`. Passing a null
log stream disables logging. Setting `Options::log_success` adds a one-line
success message; errors and numerical warnings are logged by default.
For a one-line checked call, `calculate_matrix_signature_or_throw(matrix)`
returns a `Signature` and throws `std::runtime_error` instead of returning an
invalid, averaged or numerically ambiguous classification. The `Result` API
should be used when the cutoff and diagnostic flags are needed.
Concurrent calculations are independent. A nonstandard log stream shared by
several threads must be synchronized by the caller.
The legacy names `STATUS_SOLVER_FAILURE` and `solver_info` are retained for
source compatibility; they now report an internal LDLT failure and its
one-based pivot step.

The optional timing program is built with
`-DSYMMETRIC_MATRIX_SIGNATURE_BUILD_BENCHMARK=ON` and is named
`matrix_signature_benchmark`.
