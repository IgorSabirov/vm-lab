#ifndef SYMMETRIC_MATRIX_SIGNATURE_H_INCLUDED
#define SYMMETRIC_MATRIX_SIGNATURE_H_INCLUDED

#include <cstddef>
#include <iosfwd>
#include <vector>

namespace matrix_signature {

typedef std::vector<std::vector<double> > Matrix;

// No signature is returned when the status differs from STATUS_SUCCESS.
enum Status {
  STATUS_SUCCESS = 0,
  STATUS_NULL_MATRIX,
  STATUS_NON_SQUARE_MATRIX,
  STATUS_NON_SYMMETRIC_MATRIX,
  STATUS_NON_FINITE_ENTRY,
  STATUS_INVALID_OPTIONS,
  STATUS_MATRIX_TOO_LARGE,
  STATUS_NUMERICAL_RANGE_ERROR,
  STATUS_ALLOCATION_FAILURE,
  STATUS_SOLVER_FAILURE,
  STATUS_INTERNAL_ERROR,
  // Appended to preserve the numeric values of the earlier status entries.
  STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT
};

// Numbers of positive, negative and numerically zero eigenvalues.
struct Signature {
  std::size_t positive;
  std::size_t negative;
  std::size_t zero;

  Signature();
  Signature(std::size_t positive_count,
            std::size_t negative_count,
            std::size_t zero_count);
};

// A matrix is accepted as symmetric when
// |a_ij - a_ji| <= symmetry_absolute_tolerance
//                  + symmetry_relative_tolerance * max(|a_kl|).
// An eigenvalue is zero when its absolute value does not exceed
// zero_absolute_tolerance + n * zero_relative_tolerance * frobenius_norm.
// A roundoff floor of 8 * epsilon * n * frobenius_norm is also applied.
// The defaults are 0, 64 * epsilon, 0 and 8 * epsilon, respectively.
struct Options {
  double symmetry_absolute_tolerance;
  double symmetry_relative_tolerance;
  double zero_absolute_tolerance;
  double zero_relative_tolerance;
  // nullptr disables logs; successful calls are silent unless requested.
  std::ostream *log_stream;
  bool log_success;

  Options();
};

// zero_tolerance is the effective cutoff in the input matrix units.
// solver_info contains the one-based pivot step when factorization fails.
struct Result {
  Status status;
  Signature signature;
  double zero_tolerance;
  // Set when the upper and lower matrix triangles were averaged within tolerance.
  bool symmetry_adjusted;
  // Set when the classification is sensitive near the effective cutoff.
  bool numerically_ambiguous;
  int solver_info;

  Result();
  // ok() checks the status; reliable() also rejects ambiguous or averaged input.
  bool ok() const;
  bool reliable() const;
};

// The reference overload is the normal entry point.
Result calculate_matrix_signature(const Matrix &matrix,
                                  const Options &options = Options());

// The pointer overload also reports a null input without dereferencing it.
Result calculate_matrix_signature(const Matrix *matrix,
                                  const Options &options = Options());

// Convenience entry point for callers that need only a reliable signature.
// It throws std::runtime_error when the input or classification is not reliable.
Signature calculate_matrix_signature_or_throw(
    const Matrix &matrix, const Options &options = Options());

Signature calculate_matrix_signature_or_throw(
    const Matrix *matrix, const Options &options = Options());

const char *status_to_string(Status status);

} // namespace matrix_signature

#endif
