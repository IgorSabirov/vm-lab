#include "test_support.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <numeric>
#include <string>
#include <vector>

using matrix_signature::Matrix;
using matrix_signature::Options;
using matrix_signature::Result;

namespace {

Matrix reverse_identity(std::size_t dimension) {
  Matrix matrix(dimension, std::vector<double>(dimension, 0.0));

  for(std::size_t i = 0; i < dimension; ++i)
    matrix[i][dimension - i - 1] = 1.0;

  return matrix;
}

Matrix rank_one_matrix(std::size_t dimension) {
  Matrix matrix(dimension, std::vector<double>(dimension, 0.0));
  std::vector<double> vector(dimension, 0.0);

  for(std::size_t i = 0; i < dimension; ++i)
    vector[i] = static_cast<double>(i % 5) - 2.0;

  for(std::size_t i = 0; i < dimension; ++i) {
    for(std::size_t j = 0; j < dimension; ++j)
      matrix[i][j] = vector[i] * vector[j];
  }

  return matrix;
}

Matrix increasing_weight_path(std::size_t dimension) {
  Matrix matrix(dimension, std::vector<double>(dimension, 0.0));

  for(std::size_t i = 0; i + 1 < dimension; ++i) {
    const double weight =
        1.0 + static_cast<double>(i + 1) / 256.0;
    matrix[i][i + 1] = weight;
    matrix[i + 1][i] = weight;
  }

  return matrix;
}

Matrix permute_matrix(const Matrix &matrix,
                      const std::vector<std::size_t> &permutation) {
  Matrix permuted(matrix.size(), std::vector<double>(matrix.size(), 0.0));

  for(std::size_t i = 0; i < matrix.size(); ++i) {
    for(std::size_t j = 0; j < matrix.size(); ++j)
      permuted[i][j] = matrix[permutation[i]][permutation[j]];
  }

  return permuted;
}

} // namespace

int main() {
  TestSuite test("pivoting_test");
  Options options = silent_options();
  options.zero_relative_tolerance = 0.0;

  const std::vector<double> scales = {
    1.0e-300, 1.0e-100, 1.0, 1.0e100, 1.0e300
  };

  for(std::size_t i = 0; i < scales.size(); ++i) {
    const Matrix exchange = {
      {0.0, scales[i]},
      {scales[i], 0.0}
    };
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(exchange, options),
        1, 1, 0, "two-by-two pivot scale " + std::to_string(i));

    const Matrix diagonal_interchange = {
      {0.0, scales[i]},
      {scales[i], 10.0 * scales[i]}
    };
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            diagonal_interchange, options),
        1, 1, 0, "one-by-one pivot interchange " + std::to_string(i));
  }

  // The reverse identity is its own inverse. Its eigenvalues are therefore
  // +1 and -1, with one additional +1 when the dimension is odd.
  for(std::size_t dimension = 2; dimension <= 64; ++dimension) {
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            reverse_identity(dimension), options),
        (dimension + 1) / 2, dimension / 2, 0,
        "separated two-by-two pivots " + std::to_string(dimension));
  }

  const std::size_t chain_dimensions[] = {
    8, 16, 31, 32, 63, 64, 96, 127, 128
  };
  for(std::size_t test_case = 0; test_case < 9; ++test_case) {
    const std::size_t dimension = chain_dimensions[test_case];
    const Matrix chain = increasing_weight_path(dimension);
    const std::size_t pairs = dimension / 2;
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(chain, options),
        pairs, pairs, dimension % 2,
        "deep rook chain " + std::to_string(dimension));

    std::vector<std::size_t> reversed(dimension, 0);
    std::iota(reversed.begin(), reversed.end(), 0);
    std::reverse(reversed.begin(), reversed.end());
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            permute_matrix(chain, reversed), options),
        pairs, pairs, dimension % 2,
        "reversed deep rook chain " + std::to_string(dimension));
  }

  const double pivot_boundary =
      (1.0 + std::sqrt(17.0)) / 8.0;
  const double pivot_diagonals[] = {
    std::nextafter(pivot_boundary, 0.0),
    pivot_boundary,
    std::nextafter(
        pivot_boundary, std::numeric_limits<double>::infinity())
  };
  for(std::size_t i = 0; i < 3; ++i) {
    const Matrix boundary_pivot = {
      {pivot_diagonals[i], 1.0},
      {1.0, 0.0}
    };
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            boundary_pivot, options),
        1, 1, 0,
        "rook pivot boundary " + std::to_string(i));
  }

  const Matrix rook_chain = {
    {0.0, 1.0, 0.0},
    {1.0, 0.0, 2.0},
    {0.0, 2.0, 0.0}
  };
  std::vector<std::size_t> permutation(3, 0);
  std::iota(permutation.begin(), permutation.end(), 0);
  std::size_t permutation_count = 0;

  do {
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            permute_matrix(rook_chain, permutation), options),
        1, 1, 1,
        "rook search permutation " + std::to_string(permutation_count));
    ++permutation_count;
  } while(std::next_permutation(permutation.begin(), permutation.end()));

  test.check(permutation_count == 6,
             "all rook search permutations are tested");

  const Matrix exact_singular = {
    {5.0, 2.0, 1.0},
    {2.0, 1.0, 0.0},
    {1.0, 0.0, 1.0}
  };
  std::iota(permutation.begin(), permutation.end(), 0);
  permutation_count = 0;
  const Options protected_options = silent_options();
  do {
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            permute_matrix(exact_singular, permutation), protected_options),
        2, 0, 1,
        "exact singular normalization " +
            std::to_string(permutation_count));
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            scaled_matrix(
                permute_matrix(exact_singular, permutation), -1.0),
            protected_options),
        0, 2, 1,
        "negative exact singular normalization " +
            std::to_string(permutation_count));
    const Result protected_zero_option_result =
        matrix_signature::calculate_matrix_signature(
            permute_matrix(exact_singular, permutation), options);
    test.check_reliable_signature(
        protected_zero_option_result, 2, 0, 1,
        "zero-option singular normalization " +
            std::to_string(permutation_count));
    test.check(!protected_zero_option_result.numerically_ambiguous,
               "zero-option singular classification is stable " +
                   std::to_string(permutation_count));
    ++permutation_count;
  } while(std::next_permutation(permutation.begin(), permutation.end()));

  for(std::size_t dimension = 2; dimension <= 48; ++dimension) {
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            rank_one_matrix(dimension), options),
        1, 0, dimension - 1,
        "exact singular Schur complement " + std::to_string(dimension));
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            scaled_matrix(rank_one_matrix(dimension), -1.0), options),
        0, 1, dimension - 1,
        "negative singular Schur complement " +
            std::to_string(dimension));
  }

  const double small_coupling = 1.0e-200;
  const Matrix underflowing_schur_update = {
    {0.0, 1.0, small_coupling, small_coupling},
    {1.0, 0.0, small_coupling, small_coupling},
    {small_coupling, small_coupling, 2.0, 0.0},
    {small_coupling, small_coupling, 0.0, 3.0}
  };
  permutation.resize(4);
  std::iota(permutation.begin(), permutation.end(), 0);
  permutation_count = 0;
  do {
    const Result underflowing_update_result =
        matrix_signature::calculate_matrix_signature(
            permute_matrix(underflowing_schur_update, permutation), options);
    test.check_reliable_signature(
        underflowing_update_result, 3, 1, 0,
        "underflowing Schur-complement permutation " +
            std::to_string(permutation_count));
    ++permutation_count;
  } while(std::next_permutation(permutation.begin(), permutation.end()));
  test.check(permutation_count == 24,
             "all underflowing Schur-complement permutations are tested");

  const Result success = matrix_signature::calculate_matrix_signature(
      rook_chain, options);
  test.check(success.solver_info == 0,
             "successful factorization has zero solver info");
  test.check(std::string(matrix_signature::status_to_string(
                 matrix_signature::STATUS_SOLVER_FAILURE)) ==
                 "factorization failure",
             "solver status names an internal factorization failure");

  return test.finish();
}
