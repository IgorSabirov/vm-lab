#include "test_support.hpp"

#include <cstdlib>
#include <new>
#include <vector>

namespace {

bool allocation_tracking_enabled = false;
bool persistent_failure = false;
std::size_t allocation_count = 0;
std::size_t failing_allocation = 0;

void *allocate(std::size_t size) {
  if(allocation_tracking_enabled) {
    ++allocation_count;
    if(allocation_count == failing_allocation ||
       (persistent_failure && allocation_count >= failing_allocation))
      throw std::bad_alloc();
  }

  if(size == 0)
    size = 1;

  void *memory = std::malloc(size);
  if(memory == nullptr)
    throw std::bad_alloc();

  return memory;
}

} // namespace

void *operator new(std::size_t size) {
  return allocate(size);
}

void *operator new[](std::size_t size) {
  return allocate(size);
}

void operator delete(void *memory) noexcept {
  std::free(memory);
}

void operator delete[](void *memory) noexcept {
  std::free(memory);
}

void operator delete(void *memory, std::size_t) noexcept {
  std::free(memory);
}

void operator delete[](void *memory, std::size_t) noexcept {
  std::free(memory);
}

int main() {
  TestSuite test("allocation_failure_test");
  const matrix_signature::Matrix matrix = {
    {2.0, 1.0},
    {1.0, 2.0}
  };
  const matrix_signature::Options options = silent_options();

  allocation_count = 0;
  failing_allocation = 0;
  allocation_tracking_enabled = true;
  const matrix_signature::Result measured_result =
      matrix_signature::calculate_matrix_signature(matrix, options);
  allocation_tracking_enabled = false;
  const std::size_t successful_allocation_count = allocation_count;
  test.check_reliable_signature(measured_result, 2, 0, 0,
                                "allocation-count reference call");
  test.check(successful_allocation_count >= 2,
             "all internal allocations are observed");

  for(std::size_t failure = 1;
      failure <= successful_allocation_count; ++failure) {
    matrix_signature::Result result;
    bool exception_thrown = false;
    allocation_count = 0;
    failing_allocation = failure;
    persistent_failure = false;
    allocation_tracking_enabled = true;
    try {
      result = matrix_signature::calculate_matrix_signature(matrix, options);
    }
    catch(...) {
      exception_thrown = true;
    }
    allocation_tracking_enabled = false;

    test.check(!exception_thrown,
               "allocation failure does not escape " +
                   std::to_string(failure));
    test.check(result.status ==
                   matrix_signature::STATUS_ALLOCATION_FAILURE,
               "allocation failure returns its status " +
                   std::to_string(failure));
    test.check(result.signature.positive == 0 &&
               result.signature.negative == 0 &&
               result.signature.zero == 0,
               "allocation failure returns no signature " +
                   std::to_string(failure));
  }

  allocation_count = 0;
  failing_allocation = successful_allocation_count + 1;
  allocation_tracking_enabled = true;
  const matrix_signature::Result after_last_allocation =
      matrix_signature::calculate_matrix_signature(matrix, options);
  allocation_tracking_enabled = false;
  test.check_reliable_signature(after_last_allocation, 2, 0, 0,
                                "failure point after all allocations");

  matrix_signature::Options logging_options;
  allocation_count = 0;
  failing_allocation = 1;
  persistent_failure = true;
  allocation_tracking_enabled = true;
  const matrix_signature::Result persistent_result =
      matrix_signature::calculate_matrix_signature(matrix, logging_options);
  allocation_tracking_enabled = false;
  persistent_failure = false;
  test.check(persistent_result.status ==
                 matrix_signature::STATUS_ALLOCATION_FAILURE,
             "persistent allocation failure survives logging");

  return test.finish();
}
