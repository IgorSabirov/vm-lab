#include "test_support.hpp"

#include <chrono>
#include <cstddef>
#include <iomanip>
#include <iostream>
#include <random>
#include <vector>

namespace {

matrix_signature::Matrix random_symmetric_matrix(
    std::size_t dimension, std::mt19937 &generator) {
  std::uniform_real_distribution<double> distribution(-1.0, 1.0);
  matrix_signature::Matrix matrix(
      dimension, std::vector<double>(dimension, 0.0));
  for(std::size_t i = 0; i < dimension; ++i) {
    for(std::size_t j = i; j < dimension; ++j) {
      const double value = distribution(generator);
      matrix[i][j] = value;
      matrix[j][i] = value;
    }
  }

  return matrix;
}

struct BenchmarkCase {
  std::size_t dimension;
  std::size_t repetitions;
};

} // namespace

int main() {
  const BenchmarkCase cases[] = {
    {6, 100000}, {16, 10000}, {64, 200}, {128, 80},
    {256, 20}, {512, 3}, {1024, 1}
  };
  const std::size_t case_count = sizeof(cases) / sizeof(cases[0]);
  std::mt19937 generator(0xB31C4u);
  const matrix_signature::Options options = silent_options();
  std::cout << std::fixed << std::setprecision(3);

  for(std::size_t test_case = 0; test_case < case_count; ++test_case) {
    const std::size_t dimension = cases[test_case].dimension;
    const std::size_t repetitions = cases[test_case].repetitions;
    const matrix_signature::Matrix matrix =
        random_symmetric_matrix(dimension, generator);
    matrix_signature::Result result;
    const std::chrono::steady_clock::time_point start =
        std::chrono::steady_clock::now();

    for(std::size_t repetition = 0; repetition < repetitions; ++repetition)
      result = matrix_signature::calculate_matrix_signature(matrix, options);

    const std::chrono::steady_clock::time_point finish =
        std::chrono::steady_clock::now();
    const std::chrono::duration<double, std::milli> elapsed = finish - start;

    if(!result.ok()) {
      std::cerr << "benchmark: "
                << matrix_signature::status_to_string(result.status) << '\n';
      return 1;
    }

    std::cout << "benchmark: " << dimension << " x " << dimension
              << ", " << repetitions << " repetitions, "
              << elapsed.count() / static_cast<double>(repetitions)
              << " ms per signature\n";
  }

  return 0;
}
