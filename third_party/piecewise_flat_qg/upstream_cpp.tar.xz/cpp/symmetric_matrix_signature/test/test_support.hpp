#ifndef MATRIX_SIGNATURE_TEST_SUPPORT_HPP_INCLUDED
#define MATRIX_SIGNATURE_TEST_SUPPORT_HPP_INCLUDED

#include "symmetric_matrix_signature.hpp"

#include <cmath>
#include <cstddef>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

class TestSuite{
public:
  explicit TestSuite(const std::string &test_name)
      : name(test_name), checks(0), failures(0) {}

  void check(bool condition, const std::string &description) {
    ++checks;
    if(condition)
      return;

    ++failures;
    std::cerr << name << ": FAIL: " << description << '\n';
  }

  void check_signature(const matrix_signature::Result &result,
                       std::size_t positive, std::size_t negative,
                       std::size_t zero, const std::string &description) {
    std::ostringstream details;
    details << description << " (status="
            << matrix_signature::status_to_string(result.status)
            << ", signature=" << result.signature.positive << ','
            << result.signature.negative << ',' << result.signature.zero
            << ", cutoff=" << result.zero_tolerance
            << ", ambiguous=" << result.numerically_ambiguous << ')';

    check(result.ok() &&
          result.signature.positive == positive &&
          result.signature.negative == negative &&
          result.signature.zero == zero &&
          result.signature.positive + result.signature.negative +
              result.signature.zero == positive + negative + zero &&
          result.solver_info == 0 &&
          result.zero_tolerance >= 0.0 &&
          !std::isnan(result.zero_tolerance),
          details.str());
  }

  void check_reliable_signature(
      const matrix_signature::Result &result,
      std::size_t positive, std::size_t negative,
      std::size_t zero, const std::string &description) {
    check_signature(result, positive, negative, zero, description);
    check(result.reliable(), description + " is marked reliable");
  }

  int finish() const {
    if(failures == 0) {
      std::cout << name << ": PASS (" << checks << " checks)\n";
      return 0;
    }

    std::cerr << name << ": " << failures << " of " << checks
              << " checks failed\n";
    return 1;
  }

private:
  std::string name;
  std::size_t checks;
  std::size_t failures;
};

inline matrix_signature::Options silent_options() {
  matrix_signature::Options options;
  options.log_stream = nullptr;
  return options;
}

inline matrix_signature::Matrix diagonal_matrix(
    const std::vector<double> &diagonal) {
  matrix_signature::Matrix matrix(
      diagonal.size(), std::vector<double>(diagonal.size(), 0.0));

  for(std::size_t i = 0; i < diagonal.size(); ++i)
    matrix[i][i] = diagonal[i];

  return matrix;
}

inline matrix_signature::Matrix scaled_matrix(
    const matrix_signature::Matrix &matrix, double factor) {
  matrix_signature::Matrix scaled = matrix;

  for(std::size_t i = 0; i < scaled.size(); ++i) {
    for(std::size_t j = 0; j < scaled[i].size(); ++j)
      scaled[i][j] *= factor;
  }

  return scaled;
}

#endif
