#include "test_support.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <numeric>
#include <random>
#include <string>
#include <vector>

using matrix_signature::Matrix;
using matrix_signature::Options;
using matrix_signature::Result;

namespace {

struct CongruenceCase {
  Matrix matrix;
  std::size_t positive;
  std::size_t negative;
  std::size_t zero;
};

Matrix permute_matrix(const Matrix &matrix,
                      const std::vector<std::size_t> &permutation) {
  Matrix permuted(matrix.size(), std::vector<double>(matrix.size(), 0.0));

  for(std::size_t i = 0; i < matrix.size(); ++i) {
    for(std::size_t j = 0; j < matrix.size(); ++j)
      permuted[i][j] = matrix[permutation[i]][permutation[j]];
  }

  return permuted;
}

CongruenceCase make_congruence_case(std::mt19937 &generator,
                                    std::size_t dimension) {
  std::uniform_int_distribution<int> sign_distribution(0, 2);
  std::uniform_int_distribution<int> magnitude_distribution(1, 5);
  std::uniform_int_distribution<int> index_distribution(
      0, static_cast<int>(dimension - 1));
  std::uniform_int_distribution<int> multiplier_distribution(0, 3);

  std::vector<int> diagonal(dimension, 0);
  CongruenceCase test_case;
  test_case.positive = 0;
  test_case.negative = 0;
  test_case.zero = 0;

  for(std::size_t i = 0; i < dimension; ++i) {
    const int sign = sign_distribution(generator);
    if(sign == 0) {
      ++test_case.zero;
    }
    else if(sign == 1) {
      diagonal[i] = magnitude_distribution(generator);
      ++test_case.positive;
    }
    else {
      diagonal[i] = -magnitude_distribution(generator);
      ++test_case.negative;
    }
  }

  std::vector<std::vector<std::int64_t> > transformation(
      dimension, std::vector<std::int64_t>(dimension, 0));
  for(std::size_t i = 0; i < dimension; ++i)
    transformation[i][i] = 1;

  // Integer column additions keep the transformation unimodular. Therefore
  // S^T D S has exactly the same inertia as D.
  const std::size_t operation_count = 2 * dimension + 3;
  for(std::size_t operation = 0; operation < operation_count; ++operation) {
    std::size_t source = static_cast<std::size_t>(index_distribution(generator));
    std::size_t target = static_cast<std::size_t>(index_distribution(generator));
    while(target == source)
      target = static_cast<std::size_t>(index_distribution(generator));

    const int multiplier_index = multiplier_distribution(generator);
    const int multiplier = multiplier_index < 2 ? multiplier_index - 2
                                                 : multiplier_index - 1;
    for(std::size_t row = 0; row < dimension; ++row) {
      transformation[row][target] +=
          multiplier * transformation[row][source];
    }
  }

  test_case.matrix.assign(dimension,
                          std::vector<double>(dimension, 0.0));
  for(std::size_t i = 0; i < dimension; ++i) {
    for(std::size_t j = i; j < dimension; ++j) {
      std::int64_t value = 0;
      for(std::size_t k = 0; k < dimension; ++k) {
        value += diagonal[k] * transformation[k][i] *
                 transformation[k][j];
      }

      test_case.matrix[i][j] = static_cast<double>(value);
      test_case.matrix[j][i] = static_cast<double>(value);
    }
  }

  return test_case;
}

void test_all_diagonals(TestSuite &test, const Options &options,
                        std::size_t dimension, std::size_t &case_number) {
  std::size_t combination_count = 1;
  for(std::size_t i = 0; i < dimension; ++i)
    combination_count *= 3;

  for(std::size_t combination = 0;
      combination < combination_count; ++combination) {
    std::size_t code = combination;
    std::vector<double> diagonal(dimension, 0.0);
    std::size_t positive = 0;
    std::size_t negative = 0;
    std::size_t zero = 0;

    for(std::size_t i = 0; i < dimension; ++i) {
      const std::size_t digit = code % 3;
      code /= 3;

      if(digit == 0) {
        diagonal[i] = -2.0;
        ++negative;
      }
      else if(digit == 1) {
        ++zero;
      }
      else {
        diagonal[i] = 3.0;
        ++positive;
      }
    }

    const Result result = matrix_signature::calculate_matrix_signature(
        diagonal_matrix(diagonal), options);
    test.check_reliable_signature(result, positive, negative, zero,
                                  "exhaustive diagonal case " +
                                      std::to_string(case_number));
    ++case_number;
  }
}

} // namespace

int main() {
  TestSuite test("randomized_test");
  const Options options = silent_options();

  std::size_t diagonal_case_count = 0;
  for(std::size_t dimension = 1; dimension <= 8; ++dimension)
    test_all_diagonals(test, options, dimension, diagonal_case_count);

  test.check(diagonal_case_count == 9840,
             "all diagonal sign combinations through dimension eight are tested");

  std::mt19937 generator(0x51A7C0DEu);
  std::uniform_int_distribution<int> dimension_distribution(2, 9);

  const std::size_t congruence_case_count = 5000;
  for(std::size_t case_number = 0;
      case_number < congruence_case_count; ++case_number) {
    const std::size_t dimension =
        static_cast<std::size_t>(dimension_distribution(generator));
    const CongruenceCase test_case =
        make_congruence_case(generator, dimension);
    const Result result = matrix_signature::calculate_matrix_signature(
        test_case.matrix, options);

    test.check_reliable_signature(
        result, test_case.positive, test_case.negative, test_case.zero,
        "integer congruence case " + std::to_string(case_number));
  }

  const int binary_exponents[] = {
    -900, -600, -300, 0, 300, 600, 900
  };
  const std::size_t metamorphic_case_count = 500;
  for(std::size_t case_number = 0;
      case_number < metamorphic_case_count; ++case_number) {
    const std::size_t dimension =
        static_cast<std::size_t>(dimension_distribution(generator));
    const CongruenceCase test_case =
        make_congruence_case(generator, dimension);

    std::vector<std::size_t> permutation(dimension, 0);
    std::iota(permutation.begin(), permutation.end(), 0);
    std::shuffle(permutation.begin(), permutation.end(), generator);
    const Result permuted_result =
        matrix_signature::calculate_matrix_signature(
            permute_matrix(test_case.matrix, permutation), options);
    test.check_reliable_signature(
        permuted_result, test_case.positive, test_case.negative,
        test_case.zero,
        "metamorphic permutation " + std::to_string(case_number));

    const double binary_scale = std::ldexp(
        1.0, binary_exponents[case_number % 7]);
    const Result scaled_result =
        matrix_signature::calculate_matrix_signature(
            scaled_matrix(test_case.matrix, binary_scale), options);
    test.check_reliable_signature(
        scaled_result, test_case.positive, test_case.negative,
        test_case.zero,
        "metamorphic binary scaling " + std::to_string(case_number));

    const Result negated_result =
        matrix_signature::calculate_matrix_signature(
            scaled_matrix(test_case.matrix, -1.0), options);
    test.check_reliable_signature(
        negated_result, test_case.negative, test_case.positive,
        test_case.zero,
        "metamorphic negation " + std::to_string(case_number));
  }

  std::uniform_int_distribution<int> exponent_distribution(-300, 300);
  for(std::size_t case_number = 0; case_number < 500; ++case_number) {
    const CongruenceCase test_case = make_congruence_case(generator, 6);
    const int exponent = exponent_distribution(generator);
    const double scale = std::pow(10.0, static_cast<double>(exponent));
    const Result result = matrix_signature::calculate_matrix_signature(
        scaled_matrix(test_case.matrix, scale), options);

    test.check_reliable_signature(
        result, test_case.positive, test_case.negative, test_case.zero,
        "scaled congruence case " + std::to_string(case_number));
  }

  return test.finish();
}
