#include "test_support.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using matrix_signature::Matrix;
using matrix_signature::Options;
using matrix_signature::Result;

namespace {

Matrix permute_matrix(const Matrix &matrix,
                      const std::vector<std::size_t> &permutation) {
  Matrix permuted(matrix.size(), std::vector<double>(matrix.size(), 0.0));

  for(std::size_t i = 0; i < matrix.size(); ++i) {
    for(std::size_t j = 0; j < matrix.size(); ++j)
      permuted[i][j] = matrix[permutation[i]][permutation[j]];
  }

  return permuted;
}

Matrix hilbert_matrix(std::size_t dimension) {
  Matrix matrix(dimension, std::vector<double>(dimension, 0.0));

  for(std::size_t i = 0; i < dimension; ++i) {
    for(std::size_t j = 0; j < dimension; ++j)
      matrix[i][j] = 1.0 / static_cast<double>(i + j + 1);
  }

  return matrix;
}

Matrix orthogonal_similarity(const std::vector<double> &diagonal) {
  const std::size_t dimension = diagonal.size();
  Matrix orthogonal(dimension, std::vector<double>(dimension, 0.0));

  for(std::size_t i = 0; i < dimension; ++i)
    orthogonal[i][i] = 1.0;

  for(std::size_t step = 0; step + 1 < dimension; ++step) {
    const double angle = 0.19 * static_cast<double>(step + 1);
    const double cosine = std::cos(angle);
    const double sine = std::sin(angle);

    for(std::size_t row = 0; row < dimension; ++row) {
      const double first = orthogonal[row][step];
      const double second = orthogonal[row][step + 1];
      orthogonal[row][step] = cosine * first + sine * second;
      orthogonal[row][step + 1] = -sine * first + cosine * second;
    }
  }

  Matrix result(dimension, std::vector<double>(dimension, 0.0));
  for(std::size_t i = 0; i < dimension; ++i) {
    for(std::size_t j = 0; j < dimension; ++j) {
      for(std::size_t k = 0; k < dimension; ++k)
        result[i][j] += orthogonal[k][i] * diagonal[k] * orthogonal[k][j];
    }
  }

  // Make the two triangles exactly equal before testing the factorization.
  for(std::size_t i = 0; i < dimension; ++i) {
    for(std::size_t j = i + 1; j < dimension; ++j) {
      const double mean = 0.5 * result[i][j] + 0.5 * result[j][i];
      result[i][j] = mean;
      result[j][i] = mean;
    }
  }

  return result;
}

Matrix paired_spectrum_matrix(
    const std::vector<double> &first_eigenvalues,
    const std::vector<double> &second_eigenvalues) {
  const std::size_t dimension = 2 * first_eigenvalues.size();
  Matrix matrix(dimension, std::vector<double>(dimension, 0.0));

  for(std::size_t i = 0; i < first_eigenvalues.size(); ++i) {
    const double diagonal =
        0.5 * (first_eigenvalues[i] + second_eigenvalues[i]);
    const double off_diagonal =
        0.5 * (first_eigenvalues[i] - second_eigenvalues[i]);
    const std::size_t row = 2 * i;

    matrix[row][row] = diagonal;
    matrix[row + 1][row + 1] = diagonal;
    matrix[row][row + 1] = off_diagonal;
    matrix[row + 1][row] = off_diagonal;
  }

  return matrix;
}

} // namespace

int main() {
  TestSuite test("numerical_test");
  const Options options = silent_options();

  const Matrix base = {
    { 2.0,  0.5, 0.0,  0.0, 0.0},
    { 0.5,  1.0, 0.0,  0.0, 0.0},
    { 0.0,  0.0, 0.0,  2.0, 0.0},
    { 0.0,  0.0, 2.0,  0.0, 0.0},
    { 0.0,  0.0, 0.0,  0.0, 0.0}
  };

  const std::vector<double> positive_scales = {
    1.0e-320, 1.0e-300, 1.0e-200, 1.0e-100,
    1.0, 1.0e100, 1.0e200, 1.0e300
  };

  for(std::size_t i = 0; i < positive_scales.size(); ++i) {
    const Result result = matrix_signature::calculate_matrix_signature(
        scaled_matrix(base, positive_scales[i]), options);
    test.check_reliable_signature(
        result, 3, 1, 1, "positive scale " + std::to_string(i));

    const Result negative_result = matrix_signature::calculate_matrix_signature(
        scaled_matrix(base, -positive_scales[i]), options);
    test.check_reliable_signature(
        negative_result, 1, 3, 1,
        "negative scale " + std::to_string(i));
  }

  const double denormal = std::numeric_limits<double>::denorm_min();
  Options exact_subnormal_options = silent_options();
  exact_subnormal_options.symmetry_relative_tolerance = 0.0;
  exact_subnormal_options.zero_relative_tolerance = 0.0;
  const Matrix exact_subnormal = {
    {0.0, denormal},
    {denormal, 0.0}
  };
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(
          exact_subnormal, exact_subnormal_options),
      1, 1, 0, "exact symmetric subnormal entries");

  Options averaged_subnormal_options = exact_subnormal_options;
  averaged_subnormal_options.symmetry_absolute_tolerance = denormal;
  averaged_subnormal_options.zero_absolute_tolerance = denormal;
  const Matrix averaged_subnormal = {
    {0.0, denormal},
    {2.0 * denormal, 0.0}
  };
  const Result averaged_subnormal_result =
      matrix_signature::calculate_matrix_signature(
          averaged_subnormal, averaged_subnormal_options);
  test.check_signature(averaged_subnormal_result, 1, 1, 0,
                       "averaged subnormal entries remain above the cutoff");
  test.check(averaged_subnormal_result.symmetry_adjusted,
             "averaged subnormal entries are recorded");
  test.check(!averaged_subnormal_result.reliable(),
             "averaged subnormal entries are not marked reliable");
  test.check(averaged_subnormal_result.zero_tolerance == denormal,
             "subnormal cutoff is reported in the input units");

  const Matrix permutation_source = orthogonal_similarity(
      std::vector<double>{7.0, 2.0, -1.0, -5.0, 0.0});
  std::vector<std::size_t> permutation(5, 0);
  std::iota(permutation.begin(), permutation.end(), 0);
  std::size_t permutation_count = 0;

  do {
    const Result result = matrix_signature::calculate_matrix_signature(
        permute_matrix(permutation_source, permutation), options);
    test.check_reliable_signature(
        result, 2, 2, 1,
        "simultaneous permutation " + std::to_string(permutation_count));
    ++permutation_count;
  } while(std::next_permutation(permutation.begin(), permutation.end()));

  test.check(permutation_count == 120,
             "all permutations of a five-dimensional matrix are tested");

  const Matrix rotated = orthogonal_similarity(
      std::vector<double>{9.0, 3.0, 1.0, -2.0, -8.0, 0.0});
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(rotated, options),
      3, 2, 1, "orthogonal similarity");

  const Result hilbert_result = matrix_signature::calculate_matrix_signature(
      hilbert_matrix(10), options);
  test.check_signature(hilbert_result, 10, 0, 0,
                       "ten-dimensional Hilbert matrix");
  test.check(hilbert_result.numerically_ambiguous &&
                 !hilbert_result.reliable(),
             "ill-conditioned Hilbert matrix is diagnostic");

  Options tolerance_options = silent_options();
  tolerance_options.zero_relative_tolerance = 1.0e-8;

  const Result below_cutoff = matrix_signature::calculate_matrix_signature(
      diagonal_matrix(std::vector<double>{1.0, -1.0, 1.5e-8}),
      tolerance_options);
  test.check_signature(below_cutoff, 1, 1, 1,
                       "eigenvalue below the zero cutoff");
  test.check(below_cutoff.numerically_ambiguous,
             "eigenvalue below but near the cutoff is marked ambiguous");

  try {
    matrix_signature::calculate_matrix_signature_or_throw(
        diagonal_matrix(std::vector<double>{1.0, -1.0, 1.5e-8}),
        tolerance_options);
    test.check(false, "one-line call rejects an ambiguous classification");
  }
  catch(const std::runtime_error &exception) {
    test.check(std::string(exception.what()).find("numerically ambiguous") !=
                   std::string::npos,
               "one-line call rejects an ambiguous classification");
  }
  catch(...) {
    test.check(false, "one-line call rejects an ambiguous classification");
  }

  const Result at_cutoff = matrix_signature::calculate_matrix_signature(
      diagonal_matrix(std::vector<double>{1.0, -1.0, 3.0e-8}),
      tolerance_options);
  test.check_signature(at_cutoff, 1, 1, 1,
                       "eigenvalue at the zero cutoff");
  test.check(at_cutoff.numerically_ambiguous,
             "eigenvalue at the cutoff is marked ambiguous");

  std::ostringstream ambiguity_log;
  Options logged_tolerance_options = tolerance_options;
  logged_tolerance_options.log_stream = &ambiguity_log;
  matrix_signature::calculate_matrix_signature(
      diagonal_matrix(std::vector<double>{1.0, -1.0, 3.0e-8}),
      logged_tolerance_options);
  test.check(ambiguity_log.str().find("zero-cutoff interval") !=
                 std::string::npos &&
             ambiguity_log.str().find("tolerance-dependent") !=
                 std::string::npos,
             "ambiguity log reports the cutoff interval");

  const Result rotated_cutoff = matrix_signature::calculate_matrix_signature(
      orthogonal_similarity(std::vector<double>{1.0, -1.0, 1.5e-8}),
      tolerance_options);
  test.check_signature(rotated_cutoff, 1, 1, 1,
                       "non-diagonal eigenvalue near the zero cutoff");
  test.check(rotated_cutoff.numerically_ambiguous,
             "non-diagonal cutoff case is marked ambiguous");

  const Result above_cutoff = matrix_signature::calculate_matrix_signature(
      diagonal_matrix(std::vector<double>{1.0, -1.0, 6.0e-8}),
      tolerance_options);
  test.check_signature(above_cutoff, 2, 1, 0,
                       "eigenvalue above the zero cutoff");
  test.check(above_cutoff.numerically_ambiguous,
             "eigenvalue immediately above the cutoff is marked ambiguous");

  // Each two-by-two block has the two supplied eigenvalues exactly.
  const Matrix monotone_cutoff_matrix = paired_spectrum_matrix(
      std::vector<double>{
          std::ldexp(1.0, 30), std::ldexp(1.0, 10),
          std::ldexp(1.0, -10)},
      std::vector<double>{
          -std::ldexp(1.0, 29), -std::ldexp(1.0, 9),
          -std::ldexp(1.0, -11)});
  const double monotone_cutoffs[4] = {
    std::ldexp(1.0, -15), 1.0,
    std::ldexp(1.0, 20), std::ldexp(1.0, 40)
  };
  const std::size_t monotone_signatures[4][3] = {
    {3, 3, 0}, {2, 2, 2}, {1, 1, 4}, {0, 0, 6}
  };
  Result previous_cutoff_result;

  for(std::size_t i = 0; i < 4; ++i) {
    Options monotone_options = silent_options();
    monotone_options.zero_absolute_tolerance = monotone_cutoffs[i];
    monotone_options.zero_relative_tolerance = 0.0;
    const Result result = matrix_signature::calculate_matrix_signature(
        monotone_cutoff_matrix, monotone_options);

    test.check_reliable_signature(
        result, monotone_signatures[i][0], monotone_signatures[i][1],
        monotone_signatures[i][2],
        "non-diagonal monotone cutoff " + std::to_string(i));
    if(i != 0) {
      test.check(previous_cutoff_result.signature.positive >=
                     result.signature.positive &&
                 previous_cutoff_result.signature.negative >=
                     result.signature.negative &&
                 previous_cutoff_result.signature.zero <=
                     result.signature.zero,
                 "increasing a cutoff changes counts monotonically " +
                     std::to_string(i));
    }

    previous_cutoff_result = result;
  }

  const int boundary_exponents[3] = {-1000, 0, 1000};
  for(std::size_t exponent_index = 0;
      exponent_index < 3; ++exponent_index) {
    const double cutoff = std::ldexp(
        1.0, boundary_exponents[exponent_index]);
    const double boundary_values[3] = {
      std::nextafter(cutoff, 0.0),
      cutoff,
      std::nextafter(cutoff, std::numeric_limits<double>::infinity())
    };

    Options boundary_options = silent_options();
    boundary_options.zero_absolute_tolerance = cutoff;
    boundary_options.zero_relative_tolerance = 0.0;

    for(std::size_t position = 0; position < 3; ++position) {
      const Matrix exchange = {
        {0.0, boundary_values[position]},
        {boundary_values[position], 0.0}
      };
      const Result result = matrix_signature::calculate_matrix_signature(
          exchange, boundary_options);
      const std::size_t nonzero_count = position == 2 ? 1 : 0;

      test.check_signature(
          result, nonzero_count, nonzero_count,
          position == 2 ? 0 : 2,
          "non-diagonal nextafter cutoff " +
              std::to_string(exponent_index) + ":" +
              std::to_string(position));
      test.check(result.zero_tolerance == cutoff,
                 "non-diagonal nextafter cutoff is reported exactly " +
                     std::to_string(exponent_index) + ":" +
                     std::to_string(position));
      test.check(result.numerically_ambiguous && !result.reliable(),
                 "non-diagonal nextafter cutoff is diagnostic " +
                     std::to_string(exponent_index) + ":" +
                     std::to_string(position));
    }
  }

  Options exact_sign_options = silent_options();
  exact_sign_options.zero_relative_tolerance = 0.0;
  std::ostringstream roundoff_log;
  exact_sign_options.log_stream = &roundoff_log;
  const Result exact_sign_result = matrix_signature::calculate_matrix_signature(
      diagonal_matrix(std::vector<double>{1.0, -1.0, 1.0e-18}),
      exact_sign_options);
  test.check_reliable_signature(
      exact_sign_result, 1, 1, 1,
      "roundoff floor remains active at zero cutoff");
  test.check(!exact_sign_result.numerically_ambiguous,
             "roundoff-zero classification is stable across its band");
  test.check(exact_sign_result.zero_tolerance > 0.0,
             "roundoff floor is reported as the effective cutoff");
  test.check(roundoff_log.str().find("below the roundoff floor") !=
                 std::string::npos,
             "roundoff floor adjustment is logged");

  Options exact_boundary_options = silent_options();
  exact_boundary_options.zero_absolute_tolerance = 3.0;
  exact_boundary_options.zero_relative_tolerance = 0.0;
  const Matrix exact_cutoff_boundary = {
    {-2.0, -2.0, -2.0},
    {-2.0, -1.0,  0.0},
    {-2.0,  0.0,  2.0}
  };
  const Result exact_boundary_result =
      matrix_signature::calculate_matrix_signature(
          exact_cutoff_boundary, exact_boundary_options);
  test.check(exact_boundary_result.ok(),
             "exact shifted-cutoff boundary returns a diagnostic result");
  test.check(exact_boundary_result.numerically_ambiguous &&
                 !exact_boundary_result.reliable(),
             "exact shifted-cutoff boundary is not marked reliable");

  Options absolute_options = silent_options();
  absolute_options.zero_relative_tolerance = 0.0;
  absolute_options.zero_absolute_tolerance = 1.0e-205;
  const Result absolute_result = matrix_signature::calculate_matrix_signature(
      diagonal_matrix(std::vector<double>{1.0e-200, -1.0e-200, 1.0e-206}),
      absolute_options);
  test.check_reliable_signature(
      absolute_result, 1, 1, 1,
      "absolute zero tolerance at a small scale");
  test.check(absolute_result.zero_tolerance ==
                 absolute_options.zero_absolute_tolerance,
             "reported cutoff is in the input units");

  Options underflow_options = silent_options();
  underflow_options.symmetry_absolute_tolerance = 2.0;
  underflow_options.symmetry_relative_tolerance = 0.0;
  underflow_options.zero_relative_tolerance = std::ldexp(1.0, -500);
  const Matrix underflow_matrix = {
    {std::ldexp(1.0, -575), 1.0, 0.0},
    {-1.0, denormal, 0.0},
    {0.0, 0.0, 0.0}
  };
  const Result underflow_result =
      matrix_signature::calculate_matrix_signature(underflow_matrix,
                                                   underflow_options);
  test.check_signature(underflow_result, 1, 0, 2,
                       "zero cutoff survives intermediate underflow");
  test.check(underflow_result.symmetry_adjusted &&
                 !underflow_result.reliable(),
             "underflow case records the averaged input");
  const double expected_underflow_cutoff =
      24.0 * std::numeric_limits<double>::epsilon() *
      std::ldexp(1.0, -575);
  test.check(underflow_result.zero_tolerance == expected_underflow_cutoff,
             "underflow case reports the effective cutoff");

  Options overflow_options = silent_options();
  overflow_options.zero_relative_tolerance = 1.0e-308;
  const double maximum = std::numeric_limits<double>::max();
  const Matrix overflow_matrix(2, std::vector<double>(2, maximum));
  const Result overflow_result =
      matrix_signature::calculate_matrix_signature(overflow_matrix,
                                                   overflow_options);
  const double expected_overflow_cutoff =
      32.0 * std::numeric_limits<double>::epsilon() * maximum;
  test.check_reliable_signature(
      overflow_result, 1, 0, 1,
      "zero cutoff survives intermediate overflow");
  test.check(std::isfinite(overflow_result.zero_tolerance) &&
             std::fabs(overflow_result.zero_tolerance -
                       expected_overflow_cutoff) <=
                 4.0 * std::numeric_limits<double>::epsilon() *
                     expected_overflow_cutoff,
             "overflow case reports a finite effective cutoff");

  Options extreme_tolerance_options = silent_options();
  extreme_tolerance_options.symmetry_absolute_tolerance = 2.0;
  extreme_tolerance_options.symmetry_relative_tolerance = 0.0;
  extreme_tolerance_options.zero_relative_tolerance =
      std::numeric_limits<double>::max();
  const Matrix cancelling_triangles = {
    {0.0, 1.0},
    {-1.0, 0.0}
  };
  const Result extreme_tolerance_result =
      matrix_signature::calculate_matrix_signature(
          cancelling_triangles, extreme_tolerance_options);
  test.check_signature(extreme_tolerance_result, 0, 0, 2,
                       "finite extreme tolerance on an averaged zero matrix");
  test.check(extreme_tolerance_result.symmetry_adjusted &&
                 !extreme_tolerance_result.reliable(),
             "extreme tolerance case records the averaged input");
  test.check(extreme_tolerance_result.zero_tolerance == 0.0 &&
             std::isfinite(extreme_tolerance_result.zero_tolerance),
             "extreme relative tolerance does not produce a NaN cutoff");

  Options direct_cutoff_options = silent_options();
  direct_cutoff_options.zero_absolute_tolerance = 1.0;
  direct_cutoff_options.zero_relative_tolerance = 0.0;
  const Result minimum_scale_result =
      matrix_signature::calculate_matrix_signature(
          Matrix{{std::numeric_limits<double>::denorm_min()}},
          direct_cutoff_options);
  test.check_reliable_signature(
      minimum_scale_result, 0, 0, 1,
      "absolute cutoff at the minimum finite scale");
  test.check(minimum_scale_result.zero_tolerance == 1.0,
             "absolute cutoff is reported without a normalization round trip");

  const Result empty_cutoff_result =
      matrix_signature::calculate_matrix_signature(Matrix(),
                                                   direct_cutoff_options);
  test.check_reliable_signature(
      empty_cutoff_result, 0, 0, 0,
      "empty matrix with an absolute cutoff");
  test.check(empty_cutoff_result.zero_tolerance == 1.0,
             "empty matrix reports the configured absolute cutoff");

  Options exact_range_options = silent_options();
  exact_range_options.symmetry_relative_tolerance = 0.0;
  exact_range_options.zero_relative_tolerance = 0.0;
  const Result negative_range_result =
      matrix_signature::calculate_matrix_signature(
          diagonal_matrix(std::vector<double>{
              std::numeric_limits<double>::max(),
              -std::numeric_limits<double>::denorm_min()}),
          exact_range_options);
  test.check(negative_range_result.status ==
                 matrix_signature::STATUS_NUMERICAL_RANGE_ERROR,
             "normalization does not turn a tiny negative eigenvalue into zero");

  const double large_value = std::numeric_limits<double>::max() / 4.0;
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(
          diagonal_matrix(std::vector<double>{large_value, -large_value, 0.0}),
          options),
      1, 1, 1, "values close to the floating-point maximum");

  return test.finish();
}
