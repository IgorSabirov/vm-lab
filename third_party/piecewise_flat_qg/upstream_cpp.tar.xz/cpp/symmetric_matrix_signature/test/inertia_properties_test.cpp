#include "test_support.hpp"

#include <cmath>
#include <cstddef>
#include <random>
#include <string>
#include <vector>

using matrix_signature::Matrix;
using matrix_signature::Options;
using matrix_signature::Result;

namespace {

Matrix principal_submatrix(const Matrix &matrix, std::size_t omitted) {
  Matrix result(matrix.size() - 1,
                std::vector<double>(matrix.size() - 1, 0.0));

  for(std::size_t i = 0, row = 0; i < matrix.size(); ++i) {
    if(i == omitted)
      continue;

    for(std::size_t j = 0, column = 0; j < matrix.size(); ++j) {
      if(j == omitted)
        continue;

      result[row][column] = matrix[i][j];
      ++column;
    }
    ++row;
  }

  return result;
}

Matrix rank_one_update(const Matrix &matrix,
                       const std::vector<double> &vector,
                       double scale) {
  Matrix result = matrix;

  for(std::size_t i = 0; i < matrix.size(); ++i) {
    for(std::size_t j = 0; j < matrix.size(); ++j)
      result[i][j] += scale * vector[i] * vector[j];
  }

  return result;
}

} // namespace

int main() {
  TestSuite test("inertia_properties_test");
  const Options options = silent_options();

  const Matrix signed_zero = {
    {-0.0,  0.0},
    {-0.0, -0.0}
  };
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(signed_zero, options),
      0, 0, 2, "signed zero matrix");

  std::mt19937 generator(0x4D455441u);
  std::uniform_int_distribution<int> off_diagonal(-4, 4);
  std::uniform_int_distribution<int> vector_entry(-3, 3);

  for(std::size_t test_case = 0; test_case < 128; ++test_case) {
    const std::size_t dimension = 2 + test_case % 31;
    Matrix matrix(dimension, std::vector<double>(dimension, 0.0));
    std::vector<double> row_sums(dimension, 0.0);
    std::vector<bool> positive_diagonal(dimension, false);
    std::size_t positive = 0;

    for(std::size_t i = 0; i < dimension; ++i) {
      for(std::size_t j = i + 1; j < dimension; ++j) {
        const double entry = static_cast<double>(off_diagonal(generator));
        matrix[i][j] = entry;
        matrix[j][i] = entry;
        row_sums[i] += std::fabs(entry);
        row_sums[j] += std::fabs(entry);
      }
    }

    for(std::size_t i = 0; i < dimension; ++i) {
      positive_diagonal[i] =
          i == 0 || (i > 1 && (i + test_case) % 3 != 0);
      if(positive_diagonal[i])
        ++positive;

      const double magnitude =
          row_sums[i] + 1.0 + static_cast<double>((i + test_case) % 4);
      matrix[i][i] = positive_diagonal[i] ? magnitude : -magnitude;
    }

    // Strict diagonal dominance keeps every Gershgorin interval away from
    // zero, so the signs of the diagonal give the inertia.
    const Result result = matrix_signature::calculate_matrix_signature(
        matrix, options);
    test.check_reliable_signature(
        result, positive, dimension - positive, 0,
        "mixed diagonal dominance " + std::to_string(test_case));

    for(std::size_t omitted = 0; omitted < dimension; ++omitted) {
      const std::size_t submatrix_positive =
          positive - (positive_diagonal[omitted] ? 1 : 0);
      test.check_reliable_signature(
          matrix_signature::calculate_matrix_signature(
              principal_submatrix(matrix, omitted), options),
          submatrix_positive,
          dimension - 1 - submatrix_positive,
          0,
          "principal submatrix " + std::to_string(test_case) + ":" +
              std::to_string(omitted));
    }

    std::vector<double> vector(dimension, 0.0);
    bool nonzero_vector = false;
    for(std::size_t i = 0; i < dimension; ++i) {
      vector[i] = static_cast<double>(vector_entry(generator));
      nonzero_vector = nonzero_vector || vector[i] != 0.0;
    }
    if(!nonzero_vector)
      vector[0] = 1.0;

    const double update_scale =
        32.0 * static_cast<double>(dimension + 1);
    const Result positive_update =
        matrix_signature::calculate_matrix_signature(
            rank_one_update(matrix, vector, update_scale), options);
    const Result negative_update =
        matrix_signature::calculate_matrix_signature(
            rank_one_update(matrix, vector, -update_scale), options);

    // A positive rank-one update can move at most one eigenvalue upward;
    // a negative update obeys the reversed bounds.
    test.check(positive_update.reliable(),
               "positive rank-one update is reliable " +
                   std::to_string(test_case));
    test.check(positive_update.signature.positive >= positive &&
                   positive_update.signature.positive <= positive + 1 &&
                   positive_update.signature.negative <=
                       dimension - positive &&
                   positive_update.signature.negative + 1 >=
                       dimension - positive,
               "positive rank-one inertia bound " +
                   std::to_string(test_case));
    test.check(negative_update.reliable(),
               "negative rank-one update is reliable " +
                   std::to_string(test_case));
    test.check(negative_update.signature.positive <= positive &&
                   negative_update.signature.positive + 1 >= positive &&
                   negative_update.signature.negative >=
                       dimension - positive &&
                   negative_update.signature.negative <=
                       dimension - positive + 1,
               "negative rank-one inertia bound " +
                   std::to_string(test_case));
  }

  return test.finish();
}
