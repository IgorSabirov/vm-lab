#include "test_support.hpp"

#include <vector>

using matrix_signature::Matrix;
using matrix_signature::Result;
using matrix_signature::Signature;

int main() {
  TestSuite test("basic_test");
  const matrix_signature::Options options = silent_options();

  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(Matrix(), options),
      0, 0, 0, "empty matrix");

  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(Matrix(1, std::vector<double>(1, 3.0)), options),
      1, 0, 0, "positive scalar");
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(
          Matrix(1, std::vector<double>(1, -3.0)), options),
      0, 1, 0, "negative scalar");
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(Matrix(1, std::vector<double>(1, 0.0)), options),
      0, 0, 1, "zero scalar");

  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(
          diagonal_matrix(std::vector<double>{4.0, -2.0, 0.0, 7.0, -1.0}), options),
      2, 2, 1, "mixed diagonal matrix");

  const Matrix exchange = {
    {0.0, 1.0},
    {1.0, 0.0}
  };
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(exchange, options),
      1, 1, 0, "zero leading pivot");

  const Signature simple_signature =
      matrix_signature::calculate_matrix_signature_or_throw(
          exchange, options);
  test.check(simple_signature.positive == 1 &&
             simple_signature.negative == 1 &&
             simple_signature.zero == 0,
             "one-line reference call returns the signature");

  const Signature pointer_signature =
      matrix_signature::calculate_matrix_signature_or_throw(
          &exchange, options);
  test.check(pointer_signature.positive == 1 &&
             pointer_signature.negative == 1 &&
             pointer_signature.zero == 0,
             "one-line pointer call returns the signature");

  const Matrix second_zero_pivot = {
    {1.0, 1.0, 0.0},
    {1.0, 1.0, 1.0},
    {0.0, 1.0, 1.0}
  };
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(second_zero_pivot, options),
      2, 1, 0, "zero pivot after the first step");

  const Matrix rank_one(4, std::vector<double>(4, 2.0));
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(rank_one, options),
      1, 0, 3, "rank-one positive semidefinite matrix");

  const Matrix path_laplacian = {
    { 1.0, -1.0,  0.0,  0.0,  0.0},
    {-1.0,  2.0, -1.0,  0.0,  0.0},
    { 0.0, -1.0,  2.0, -1.0,  0.0},
    { 0.0,  0.0, -1.0,  2.0, -1.0},
    { 0.0,  0.0,  0.0, -1.0,  1.0}
  };
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(path_laplacian, options),
      4, 0, 1, "connected graph Laplacian");
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(
          scaled_matrix(path_laplacian, -1.0), options),
      0, 4, 1, "negative graph Laplacian");

  const Matrix repeated_eigenvalues = {
    { 2.0,  0.0,  0.0, 0.0, 0.0, 0.0},
    { 0.0,  2.0,  0.0, 0.0, 0.0, 0.0},
    { 0.0,  0.0, -3.0, 0.0, 0.0, 0.0},
    { 0.0,  0.0,  0.0, -3.0, 0.0, 0.0},
    { 0.0,  0.0,  0.0, 0.0, 0.0, 0.0},
    { 0.0,  0.0,  0.0, 0.0, 0.0, 0.0}
  };
  test.check_reliable_signature(
      matrix_signature::calculate_matrix_signature(repeated_eigenvalues, options),
      2, 2, 2, "repeated eigenvalues");

  const Matrix original = second_zero_pivot;
  const Result unchanged_result =
      matrix_signature::calculate_matrix_signature(original, options);
  test.check(unchanged_result.ok(), "unchanged-input calculation succeeds");
  test.check(original == second_zero_pivot, "input matrix is not modified");

  return test.finish();
}
