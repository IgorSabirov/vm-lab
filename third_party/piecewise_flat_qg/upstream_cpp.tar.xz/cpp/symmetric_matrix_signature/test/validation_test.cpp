#include "test_support.hpp"

#include <cfenv>
#include <cmath>
#include <limits>
#include <ostream>
#include <sstream>
#include <stdexcept>
#include <streambuf>
#include <string>
#include <vector>

#if defined(__SSE2__) || defined(_M_X64) || \
    (defined(_M_IX86_FP) && _M_IX86_FP >= 2)
#define MATRIX_SIGNATURE_TEST_HAS_SSE2 1
#include <xmmintrin.h>
#endif

using matrix_signature::Matrix;
using matrix_signature::Options;
using matrix_signature::Result;
using matrix_signature::Status;

namespace {

class ThrowingBuffer : public std::streambuf {
protected:
  int overflow(int) {
    throw 1;
  }
};

class RoundingBuffer : public std::streambuf {
public:
  explicit RoundingBuffer(int rounding_mode)
      : rounding_mode_(rounding_mode), changed_(false) {}

  bool changed() const {
    return changed_;
  }

protected:
  std::streamsize xsputn(const char *, std::streamsize count) {
    change_rounding_mode();
    return count;
  }

  int overflow(int character) {
    change_rounding_mode();
    return character;
  }

private:
  void change_rounding_mode() {
    if(!changed_ && std::fesetround(rounding_mode_) == 0)
      changed_ = true;
  }

  int rounding_mode_;
  bool changed_;
};

#if defined(MATRIX_SIGNATURE_TEST_HAS_SSE2)
class FlushBuffer : public std::streambuf {
protected:
  std::streamsize xsputn(const char *, std::streamsize count) {
    enable_flush_modes();
    return count;
  }

  int overflow(int character) {
    enable_flush_modes();
    return character;
  }

private:
  static void enable_flush_modes() {
    _mm_setcsr(_mm_getcsr() | (1u << 15) | (1u << 6));
  }
};
#endif

void check_status(TestSuite &test, const Result &result, Status expected,
                  const std::string &description) {
  test.check(result.status == expected && !result.ok(), description);
  test.check(result.signature.positive == 0 &&
             result.signature.negative == 0 &&
             result.signature.zero == 0,
             description + " returns an empty signature");
}

void check_throwing_call(TestSuite &test, const Matrix &matrix,
                         const Options &options,
                         const std::string &expected_message,
                         const std::string &description) {
  try {
    matrix_signature::calculate_matrix_signature_or_throw(matrix, options);
    test.check(false, description);
  }
  catch(const std::runtime_error &exception) {
    test.check(std::string(exception.what()).find(expected_message) !=
                   std::string::npos,
               description);
  }
  catch(...) {
    test.check(false, description);
  }
}

} // namespace

int main() {
  TestSuite test("validation_test");

  std::ostringstream log;
  Options options;
  options.log_stream = &log;

  const Result null_result = matrix_signature::calculate_matrix_signature(
      static_cast<const Matrix *>(nullptr), options);
  check_status(test, null_result, matrix_signature::STATUS_NULL_MATRIX,
               "null matrix is rejected");
  test.check(log.str().find("ERROR: calculate_matrix_signature(): Matrix pointer is null.") !=
                 std::string::npos,
             "null matrix log identifies the error");

  const int original_rounding_mode = std::fegetround();
  const int non_nearest_modes[] = {
    FE_DOWNWARD, FE_UPWARD, FE_TOWARDZERO
  };
  for(std::size_t i = 0; i < 3; ++i) {
    if(std::fesetround(non_nearest_modes[i]) != 0)
      continue;

    log.str("");
    log.clear();
    const Result result = matrix_signature::calculate_matrix_signature(
        Matrix{{1.0}}, options);
    check_status(
        test, result,
        matrix_signature::STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT,
        "non-nearest rounding mode " + std::to_string(i));
    test.check(std::fegetround() == non_nearest_modes[i],
               "rounding mode is not changed " + std::to_string(i));
    test.check(log.str().find("round-to-nearest and gradual underflow") !=
                   std::string::npos,
               "unsupported rounding mode is logged " +
                   std::to_string(i));
  }
  test.check(std::fesetround(original_rounding_mode) == 0,
             "original rounding mode is restored");

  RoundingBuffer rounding_buffer(FE_UPWARD);
  std::ostream rounding_stream(&rounding_buffer);
  Options rounding_log_options;
  rounding_log_options.zero_relative_tolerance = 0.0;
  rounding_log_options.log_stream = &rounding_stream;
  const Result rounding_log_result =
      matrix_signature::calculate_matrix_signature(
          Matrix{{1.0}}, rounding_log_options);
  if(rounding_buffer.changed()) {
    check_status(
        test, rounding_log_result,
        matrix_signature::STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT,
        "logger rounding-mode change is detected before factorization");
    test.check(std::fegetround() == FE_UPWARD,
               "logger-selected rounding mode is preserved on return");
  }
  test.check(std::fesetround(original_rounding_mode) == 0,
             "rounding mode after logger test is restored");

  RoundingBuffer symmetry_rounding_buffer(FE_DOWNWARD);
  std::ostream symmetry_rounding_stream(&symmetry_rounding_buffer);
  Options symmetry_rounding_options;
  symmetry_rounding_options.log_stream = &symmetry_rounding_stream;
  const Matrix logger_nearly_symmetric = {
    {2.0, 1.0},
    {1.0 + 2.0e-15, -2.0}
  };
  const Result symmetry_rounding_result =
      matrix_signature::calculate_matrix_signature(
          logger_nearly_symmetric, symmetry_rounding_options);
  if(symmetry_rounding_buffer.changed()) {
    check_status(
        test, symmetry_rounding_result,
        matrix_signature::STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT,
        "symmetry-warning logger rounding change is detected before scaling");
    test.check(std::fegetround() == FE_DOWNWARD,
               "symmetry-warning logger rounding mode is preserved on return");
  }
  test.check(std::fesetround(original_rounding_mode) == 0,
             "rounding mode after symmetry-warning logger test is restored");

#if defined(MATRIX_SIGNATURE_TEST_HAS_SSE2)
  const unsigned int original_control_word = _mm_getcsr();
  const unsigned int flush_control_word =
      original_control_word | (1u << 15) | (1u << 6);
  _mm_setcsr(flush_control_word);
  volatile double denormal = std::numeric_limits<double>::denorm_min();
  volatile double one = 1.0;
  volatile double preserved_denormal = denormal * one;
  const Result flush_result = matrix_signature::calculate_matrix_signature(
      Matrix{{1.0}}, options);
  const unsigned int returned_control_word = _mm_getcsr();
  _mm_setcsr(original_control_word);
  if(preserved_denormal == 0.0) {
    check_status(
        test, flush_result,
        matrix_signature::STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT,
        "active arithmetic flushes subnormal values");
  }
  else {
    test.check_reliable_signature(
        flush_result, 1, 0, 0,
        "active arithmetic preserves subnormal values");
  }
  test.check((returned_control_word & ((1u << 15) | (1u << 6))) ==
                 ((1u << 15) | (1u << 6)),
             "subnormal control mode is not changed");

  FlushBuffer flush_buffer;
  std::ostream flush_stream(&flush_buffer);
  Options flush_log_options;
  flush_log_options.zero_relative_tolerance = 0.0;
  flush_log_options.log_stream = &flush_stream;
  const Result flush_log_result =
      matrix_signature::calculate_matrix_signature(
          Matrix{{1.0}}, flush_log_options);
  const unsigned int logger_control_word = _mm_getcsr();
  volatile double logger_denormal =
      std::numeric_limits<double>::denorm_min();
  volatile double logger_one = 1.0;
  volatile double logger_preserved_denormal =
      logger_denormal * logger_one;
  _mm_setcsr(original_control_word);
  if(logger_preserved_denormal == 0.0) {
    check_status(
        test, flush_log_result,
        matrix_signature::STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT,
        "active logger-enabled subnormal flush modes are detected before factorization");
  }
  else {
    test.check_reliable_signature(
        flush_log_result, 1, 0, 0,
        "inactive logger flush bits do not reject gradual underflow");
  }
  test.check((logger_control_word & ((1u << 15) | (1u << 6))) ==
                 ((1u << 15) | (1u << 6)),
             "logger-selected subnormal mode is preserved on return");
#endif

  const std::vector<Matrix> non_square_matrices = {
    Matrix(1, std::vector<double>()),
    Matrix(2, std::vector<double>(3, 0.0)),
    Matrix{{1.0, 0.0}, {0.0}},
    Matrix{{1.0}, {0.0, 1.0}}
  };

  for(std::size_t i = 0; i < non_square_matrices.size(); ++i) {
    log.str("");
    log.clear();
    const Result result = matrix_signature::calculate_matrix_signature(
        non_square_matrices[i], options);
    check_status(test, result, matrix_signature::STATUS_NON_SQUARE_MATRIX,
                 "non-square matrix " + std::to_string(i));
    test.check(log.str().find("Matrix is not square; row") != std::string::npos,
               "non-square log includes the failing row");
  }

  log.str("");
  log.clear();
  const Matrix non_symmetric = {
    {1.0, 2.0},
    {3.0, 4.0}
  };
  const Result non_symmetric_result =
      matrix_signature::calculate_matrix_signature(non_symmetric, options);
  check_status(test, non_symmetric_result,
               matrix_signature::STATUS_NON_SYMMETRIC_MATRIX,
               "non-symmetric matrix is rejected");
  test.check(log.str().find("entries (0, 1) and (1, 0)") != std::string::npos,
             "symmetry log identifies both entries");
  check_throwing_call(
      test, non_symmetric, silent_options(), "non-symmetric matrix",
      "one-line call rejects a non-symmetric matrix");

  log.str("");
  log.clear();
  const Matrix nearly_symmetric = {
    {2.0, 1.0},
    {1.0 + 2.0e-15, -2.0}
  };
  const Result adjusted_result =
      matrix_signature::calculate_matrix_signature(nearly_symmetric, options);
  test.check_signature(adjusted_result, 1, 1, 0,
                       "small asymmetry inside the default tolerance");
  test.check(adjusted_result.symmetry_adjusted,
             "accepted asymmetry is recorded in the result");
  test.check(!adjusted_result.reliable(),
             "averaged input is not marked reliable");
  check_throwing_call(
      test, nearly_symmetric, silent_options(), "input was averaged",
      "one-line call rejects an averaged matrix");
  test.check(log.str().find("WARNING:") != std::string::npos &&
             log.str().find("Corresponding entries were averaged") !=
                 std::string::npos,
             "accepted asymmetry produces a clear warning");

  const double averaged_entry =
      (nearly_symmetric[0][1] + nearly_symmetric[1][0]) / 2.0;
  const Matrix explicitly_averaged = {
    {2.0, averaged_entry},
    {averaged_entry, -2.0}
  };
  const Result explicitly_averaged_result =
      matrix_signature::calculate_matrix_signature(
          explicitly_averaged, silent_options());
  test.check_reliable_signature(explicitly_averaged_result, 1, 1, 0,
                                "explicitly averaged symmetric matrix");

  const Matrix transposed_nearly_symmetric = {
    {2.0, 1.0 + 2.0e-15},
    {1.0, -2.0}
  };
  const Result transposed_adjusted_result =
      matrix_signature::calculate_matrix_signature(
          transposed_nearly_symmetric, options);
  test.check_signature(transposed_adjusted_result, 1, 1, 0,
                       "transpose of accepted asymmetric input");
  test.check(transposed_adjusted_result.symmetry_adjusted &&
                 !transposed_adjusted_result.reliable(),
             "transposed adjusted input has the same reliability contract");

  Options strict_options = options;
  strict_options.symmetry_relative_tolerance = 0.0;
  const Result strict_result =
      matrix_signature::calculate_matrix_signature(nearly_symmetric,
                                                   strict_options);
  check_status(test, strict_result,
               matrix_signature::STATUS_NON_SYMMETRIC_MATRIX,
               "strict symmetry setting rejects any difference");

  const double maximum = std::numeric_limits<double>::max();
  const double minimum = std::numeric_limits<double>::denorm_min();
  const Matrix extreme_asymmetry = {
    {maximum, minimum},
    {0.0, maximum}
  };
  const Result extreme_asymmetry_result =
      matrix_signature::calculate_matrix_signature(extreme_asymmetry,
                                                   strict_options);
  check_status(test, extreme_asymmetry_result,
               matrix_signature::STATUS_NON_SYMMETRIC_MATRIX,
               "strict symmetry check handles extreme dynamic range");

  Options wide_symmetry_options = silent_options();
  wide_symmetry_options.symmetry_absolute_tolerance = maximum;
  wide_symmetry_options.symmetry_relative_tolerance = 0.75;
  const Matrix opposite_extremes = {
    {0.0, maximum},
    {-maximum, 0.0}
  };
  check_status(
      test,
      matrix_signature::calculate_matrix_signature(
          opposite_extremes, wide_symmetry_options),
      matrix_signature::STATUS_NON_SYMMETRIC_MATRIX,
      "overflow-safe symmetry comparison rejects excessive asymmetry");

  wide_symmetry_options.symmetry_relative_tolerance = 1.0;
  const Result wide_boundary_result =
      matrix_signature::calculate_matrix_signature(opposite_extremes,
                                                   wide_symmetry_options);
  test.check_signature(wide_boundary_result, 0, 0, 2,
                       "overflow-safe symmetry tolerance includes its boundary");
  test.check(wide_boundary_result.symmetry_adjusted,
             "overflow-safe boundary averaging is recorded");
  test.check(!wide_boundary_result.reliable(),
             "overflow-safe boundary averaging is not marked reliable");

  Options absolute_symmetry_options = silent_options();
  absolute_symmetry_options.symmetry_relative_tolerance = 0.0;
  absolute_symmetry_options.symmetry_absolute_tolerance = 1.0e10;
  const Matrix absolute_boundary = {
    {1.0e300, 1.0e10},
    {0.0, 1.0e300}
  };
  const Result absolute_boundary_result =
      matrix_signature::calculate_matrix_signature(
          absolute_boundary, absolute_symmetry_options);
  test.check(absolute_boundary_result.ok(),
             "absolute symmetry tolerance includes its boundary");
  test.check(absolute_boundary_result.symmetry_adjusted &&
                 !absolute_boundary_result.reliable(),
             "absolute symmetry boundary is not marked reliable");

  Matrix above_absolute_boundary = absolute_boundary;
  above_absolute_boundary[0][1] =
      std::nextafter(1.0e10, std::numeric_limits<double>::infinity());
  check_status(
      test,
      matrix_signature::calculate_matrix_signature(
          above_absolute_boundary, absolute_symmetry_options),
      matrix_signature::STATUS_NON_SYMMETRIC_MATRIX,
      "absolute symmetry tolerance rejects the next larger difference");

  log.str("");
  log.clear();
  Options range_options = options;
  range_options.symmetry_absolute_tolerance = 0.0;
  range_options.symmetry_relative_tolerance = 0.0;
  range_options.zero_absolute_tolerance = 0.0;
  range_options.zero_relative_tolerance = 0.0;
  const Result range_result = matrix_signature::calculate_matrix_signature(
      diagonal_matrix(std::vector<double>{maximum, minimum}),
      range_options);
  check_status(test, range_result,
               matrix_signature::STATUS_NUMERICAL_RANGE_ERROR,
               "normalization cannot erase a nonzero matrix entry");
  test.check(log.str().find("Scaling would lose a nonzero matrix entry") !=
                 std::string::npos,
             "numerical range failure is logged explicitly");

  const double nan = std::numeric_limits<double>::quiet_NaN();
  const double infinity = std::numeric_limits<double>::infinity();
  const std::vector<Matrix> non_finite_matrices = {
    Matrix{{nan, 0.0}, {0.0, 1.0}},
    Matrix{{1.0, infinity}, {infinity, 1.0}},
    Matrix{{1.0, -infinity}, {-infinity, 1.0}},
    Matrix{{1.0, nan}, {nan, 1.0}}
  };

  for(std::size_t i = 0; i < non_finite_matrices.size(); ++i) {
    log.str("");
    log.clear();
    const Result result = matrix_signature::calculate_matrix_signature(
        non_finite_matrices[i], options);
    check_status(test, result, matrix_signature::STATUS_NON_FINITE_ENTRY,
                 "non-finite matrix " + std::to_string(i));
    test.check(log.str().find("is not finite") != std::string::npos,
               "non-finite entry is named in the log");
  }

  std::vector<Options> invalid_options(8, silent_options());
  invalid_options[0].symmetry_absolute_tolerance = -1.0;
  invalid_options[1].symmetry_relative_tolerance = -1.0;
  invalid_options[2].zero_absolute_tolerance = -1.0;
  invalid_options[3].zero_relative_tolerance = -1.0;
  invalid_options[4].symmetry_absolute_tolerance = nan;
  invalid_options[5].symmetry_relative_tolerance = infinity;
  invalid_options[6].zero_absolute_tolerance = nan;
  invalid_options[7].zero_relative_tolerance = infinity;

  const Matrix identity = diagonal_matrix(std::vector<double>{1.0, 1.0});
  test.check_signature(
      matrix_signature::calculate_matrix_signature(&identity, options),
      2, 0, 0, "valid matrix pointer overload");
  for(std::size_t i = 0; i < invalid_options.size(); ++i) {
    const Result result = matrix_signature::calculate_matrix_signature(
        identity, invalid_options[i]);
    check_status(test, result, matrix_signature::STATUS_INVALID_OPTIONS,
                 "invalid tolerance " + std::to_string(i));
  }
  const Result invalid_pointer_options_result =
      matrix_signature::calculate_matrix_signature(
          &identity, invalid_options[0]);
  check_status(test, invalid_pointer_options_result,
               matrix_signature::STATUS_INVALID_OPTIONS,
               "pointer overload rejects invalid options");

  try {
    matrix_signature::calculate_matrix_signature_or_throw(
        static_cast<const Matrix *>(nullptr), silent_options());
    test.check(false, "one-line pointer call rejects null input");
  }
  catch(const std::runtime_error &exception) {
    test.check(std::string(exception.what()).find("null matrix") !=
                   std::string::npos,
               "one-line pointer call rejects null input");
  }
  catch(...) {
    test.check(false, "one-line pointer call rejects null input");
  }

  log.str("");
  log.clear();
  options.log_success = true;
  const Result logged_success =
      matrix_signature::calculate_matrix_signature(identity, options);
  test.check(logged_success.ok(), "success logging does not affect result");
  test.check(log.str().find("INFO: calculate_matrix_signature(): Signature is (2, 0, 0).") !=
                 std::string::npos,
             "success log contains the signature");

  Options no_log_options;
  no_log_options.log_stream = nullptr;
  test.check(matrix_signature::calculate_matrix_signature(
                 non_symmetric, no_log_options).status ==
                 matrix_signature::STATUS_NON_SYMMETRIC_MATRIX,
             "logging can be disabled");

  ThrowingBuffer throwing_buffer;
  std::ostream throwing_stream(&throwing_buffer);
  throwing_stream.exceptions(std::ios::badbit | std::ios::failbit);
  Options throwing_log_options;
  throwing_log_options.log_stream = &throwing_stream;
  const Result throwing_log_result =
      matrix_signature::calculate_matrix_signature(non_symmetric,
                                                   throwing_log_options);
  test.check(throwing_log_result.status ==
                 matrix_signature::STATUS_NON_SYMMETRIC_MATRIX,
             "logger exception does not change the calculation status");

  const std::vector<Status> statuses = {
    matrix_signature::STATUS_SUCCESS,
    matrix_signature::STATUS_NULL_MATRIX,
    matrix_signature::STATUS_NON_SQUARE_MATRIX,
    matrix_signature::STATUS_NON_SYMMETRIC_MATRIX,
    matrix_signature::STATUS_NON_FINITE_ENTRY,
    matrix_signature::STATUS_INVALID_OPTIONS,
    matrix_signature::STATUS_MATRIX_TOO_LARGE,
    matrix_signature::STATUS_NUMERICAL_RANGE_ERROR,
    matrix_signature::STATUS_ALLOCATION_FAILURE,
    matrix_signature::STATUS_SOLVER_FAILURE,
    matrix_signature::STATUS_INTERNAL_ERROR,
    matrix_signature::STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT
  };

  for(std::size_t i = 0; i < statuses.size(); ++i) {
    test.check(std::string(matrix_signature::status_to_string(statuses[i])) !=
                   "unknown status",
               "known status has text " + std::to_string(i));
  }
  const Status unknown_status = static_cast<Status>(
      static_cast<int>(
          matrix_signature::STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT) +
      1);
  test.check(std::string(matrix_signature::status_to_string(unknown_status)) ==
                 "unknown status",
             "unknown status has fallback text");

  return test.finish();
}
