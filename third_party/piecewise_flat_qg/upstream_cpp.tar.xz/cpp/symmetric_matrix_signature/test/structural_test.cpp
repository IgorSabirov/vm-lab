#include "test_support.hpp"

#include <cmath>
#include <cstddef>
#include <limits>
#include <random>
#include <string>
#include <vector>

using matrix_signature::Matrix;
using matrix_signature::Options;
using matrix_signature::Result;
using matrix_signature::Signature;

namespace {

Matrix zero_matrix(std::size_t dimension) {
  return Matrix(dimension, std::vector<double>(dimension, 0.0));
}

Matrix path_adjacency(std::size_t dimension) {
  Matrix matrix = zero_matrix(dimension);

  for(std::size_t i = 0; i + 1 < dimension; ++i) {
    matrix[i][i + 1] = 1.0;
    matrix[i + 1][i] = 1.0;
  }

  return matrix;
}

Matrix complete_adjacency(std::size_t dimension) {
  Matrix matrix = zero_matrix(dimension);

  for(std::size_t i = 0; i < dimension; ++i) {
    for(std::size_t j = i + 1; j < dimension; ++j) {
      matrix[i][j] = 1.0;
      matrix[j][i] = 1.0;
    }
  }

  return matrix;
}

Matrix star_adjacency(std::size_t dimension) {
  Matrix matrix = zero_matrix(dimension);

  for(std::size_t i = 1; i < dimension; ++i) {
    matrix[0][i] = 1.0;
    matrix[i][0] = 1.0;
  }

  return matrix;
}

Matrix cycle_adjacency(std::size_t dimension) {
  Matrix matrix = path_adjacency(dimension);
  matrix[0][dimension - 1] = 1.0;
  matrix[dimension - 1][0] = 1.0;
  return matrix;
}

Matrix complete_bipartite_adjacency(std::size_t first_part,
                                    std::size_t second_part) {
  Matrix matrix = zero_matrix(first_part + second_part);

  for(std::size_t i = 0; i < first_part; ++i) {
    for(std::size_t j = 0; j < second_part; ++j) {
      matrix[i][first_part + j] = 1.0;
      matrix[first_part + j][i] = 1.0;
    }
  }

  return matrix;
}

Matrix shifted_all_ones(std::size_t dimension, double diagonal_shift,
                        double common_entry) {
  Matrix matrix(dimension, std::vector<double>(dimension, common_entry));

  for(std::size_t i = 0; i < dimension; ++i)
    matrix[i][i] += diagonal_shift;

  return matrix;
}

Matrix path_laplacian(const std::vector<std::size_t> &block_sizes) {
  std::size_t dimension = 0;
  for(std::size_t i = 0; i < block_sizes.size(); ++i)
    dimension += block_sizes[i];

  Matrix matrix = zero_matrix(dimension);
  std::size_t offset = 0;

  for(std::size_t block = 0; block < block_sizes.size(); ++block) {
    for(std::size_t i = 0; i + 1 < block_sizes[block]; ++i) {
      const std::size_t first = offset + i;
      const std::size_t second = first + 1;
      matrix[first][first] += 1.0;
      matrix[second][second] += 1.0;
      matrix[first][second] = -1.0;
      matrix[second][first] = -1.0;
    }

    offset += block_sizes[block];
  }

  return matrix;
}

std::vector<std::vector<double> > full_row_rank_matrix(
    std::size_t rows, std::size_t columns) {
  std::vector<std::vector<double> > matrix(
      rows, std::vector<double>(columns, 0.0));

  for(std::size_t i = 0; i < rows; ++i) {
    matrix[i][i] = 1.0;

    for(std::size_t j = rows; j < columns; ++j) {
      const int value = static_cast<int>(((i + 2) * (j + 3)) % 7) - 3;
      matrix[i][j] = static_cast<double>(value);
    }
  }

  return matrix;
}

Matrix saddle_matrix(std::size_t rows, std::size_t columns) {
  const std::vector<std::vector<double> > block =
      full_row_rank_matrix(rows, columns);
  Matrix matrix = zero_matrix(rows + columns);

  for(std::size_t i = 0; i < rows; ++i) {
    for(std::size_t j = 0; j < columns; ++j) {
      matrix[i][rows + j] = block[i][j];
      matrix[rows + j][i] = block[i][j];
    }
  }

  return matrix;
}

Matrix kkt_matrix(std::size_t rows, std::size_t columns) {
  const std::vector<std::vector<double> > constraints =
      full_row_rank_matrix(rows, columns);
  Matrix matrix = zero_matrix(columns + rows);

  for(std::size_t i = 0; i < columns; ++i)
    matrix[i][i] = 1.0;

  for(std::size_t i = 0; i < rows; ++i) {
    for(std::size_t j = 0; j < columns; ++j) {
      matrix[j][columns + i] = constraints[i][j];
      matrix[columns + i][j] = constraints[i][j];
    }
  }

  return matrix;
}

Matrix gram_matrix(std::size_t rows, std::size_t columns) {
  const std::vector<std::vector<double> > factors =
      full_row_rank_matrix(rows, columns);
  Matrix matrix = zero_matrix(columns);

  for(std::size_t i = 0; i < columns; ++i) {
    for(std::size_t j = i; j < columns; ++j) {
      double entry = 0.0;
      for(std::size_t k = 0; k < rows; ++k)
        entry += factors[k][i] * factors[k][j];

      matrix[i][j] = entry;
      matrix[j][i] = entry;
    }
  }

  return matrix;
}

Matrix direct_sum(const Matrix &first, const Matrix &second) {
  Matrix matrix = zero_matrix(first.size() + second.size());

  for(std::size_t i = 0; i < first.size(); ++i) {
    for(std::size_t j = 0; j < first.size(); ++j)
      matrix[i][j] = first[i][j];
  }

  for(std::size_t i = 0; i < second.size(); ++i) {
    for(std::size_t j = 0; j < second.size(); ++j)
      matrix[first.size() + i][first.size() + j] = second[i][j];
  }

  return matrix;
}

Matrix kronecker_product(const Matrix &first, const Matrix &second) {
  Matrix matrix = zero_matrix(first.size() * second.size());

  for(std::size_t i = 0; i < first.size(); ++i) {
    for(std::size_t j = 0; j < first.size(); ++j) {
      for(std::size_t k = 0; k < second.size(); ++k) {
        for(std::size_t l = 0; l < second.size(); ++l) {
          matrix[i * second.size() + k][j * second.size() + l] =
              first[i][j] * second[k][l];
        }
      }
    }
  }

  return matrix;
}

struct KnownMatrix {
  Matrix matrix;
  Signature signature;
  std::string name;
};

KnownMatrix known_matrix(const Matrix &matrix, const Signature &signature,
                         const std::string &name) {
  KnownMatrix known = {matrix, signature, name};
  return known;
}

} // namespace

int main() {
  TestSuite test("structural_test");
  const Options options = silent_options();

  for(std::size_t dimension = 1; dimension <= 64; ++dimension) {
    const std::size_t pairs = dimension / 2;
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            path_adjacency(dimension), options),
        pairs, pairs, dimension % 2,
        "path graph " + std::to_string(dimension));
  }

  for(std::size_t dimension = 2; dimension <= 48; ++dimension) {
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            complete_adjacency(dimension), options),
        1, dimension - 1, 0,
        "complete graph " + std::to_string(dimension));
  }

  for(std::size_t dimension = 2; dimension <= 64; ++dimension) {
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            star_adjacency(dimension), options),
        1, 1, dimension - 2,
        "star graph " + std::to_string(dimension));
  }

  for(std::size_t dimension = 3; dimension <= 96; ++dimension) {
    std::size_t positive = 0;
    std::size_t negative = 0;
    std::size_t zero = 0;

    if(dimension % 4 == 0) {
      positive = dimension / 2 - 1;
      negative = positive;
      zero = 2;
    } else if(dimension % 4 == 1) {
      positive = (dimension + 1) / 2;
      negative = (dimension - 1) / 2;
    } else if(dimension % 4 == 2) {
      positive = dimension / 2;
      negative = dimension / 2;
    } else {
      positive = (dimension - 1) / 2;
      negative = (dimension + 1) / 2;
    }

    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            cycle_adjacency(dimension), options),
        positive, negative, zero,
        "cycle graph " + std::to_string(dimension));
  }

  for(std::size_t first_part = 2; first_part <= 10; ++first_part) {
    for(std::size_t second_part = 2; second_part <= 10; ++second_part) {
      test.check_reliable_signature(
          matrix_signature::calculate_matrix_signature(
              complete_bipartite_adjacency(first_part, second_part), options),
          1, 1, first_part + second_part - 2,
          "complete bipartite graph " + std::to_string(first_part) + "x" +
              std::to_string(second_part));
    }
  }

  for(std::size_t test_case = 0; test_case < 32; ++test_case) {
    const std::size_t component_count = 1 + test_case % 7;
    std::vector<std::size_t> block_sizes;
    std::size_t dimension = 0;

    for(std::size_t component = 0; component < component_count; ++component) {
      const std::size_t block_size =
          1 + (test_case + 3 * component * component) % 8;
      block_sizes.push_back(block_size);
      dimension += block_size;
    }

    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            path_laplacian(block_sizes), options),
        dimension - component_count, 0, component_count,
        "disconnected path Laplacian " + std::to_string(test_case));
  }

  for(std::size_t rows = 1; rows <= 7; ++rows) {
    for(std::size_t columns = rows; columns <= rows + 5; ++columns) {
      test.check_reliable_signature(
          matrix_signature::calculate_matrix_signature(
              saddle_matrix(rows, columns), options),
          rows, rows, columns - rows,
          "saddle matrix " + std::to_string(rows) + "x" +
              std::to_string(columns));

      test.check_reliable_signature(
          matrix_signature::calculate_matrix_signature(
              kkt_matrix(rows, columns), options),
          columns, rows, 0,
          "KKT matrix " + std::to_string(rows) + "x" +
              std::to_string(columns));

      test.check_reliable_signature(
          matrix_signature::calculate_matrix_signature(
              gram_matrix(rows, columns), options),
          rows, 0, columns - rows,
          "Gram matrix " + std::to_string(rows) + "x" +
              std::to_string(columns));
    }
  }

  std::vector<KnownMatrix> known;
  known.push_back(known_matrix(
      diagonal_matrix(std::vector<double>{2.0, -3.0, 0.0}),
      Signature(1, 1, 1), "mixed diagonal"));
  known.push_back(known_matrix(
      Matrix{{0.0, 1.0}, {1.0, 0.0}},
      Signature(1, 1, 0), "exchange"));
  known.push_back(known_matrix(
      Matrix(3, std::vector<double>(3, 1.0)),
      Signature(1, 0, 2), "rank one"));
  known.push_back(known_matrix(
      Matrix{{2.0, -1.0}, {-1.0, 2.0}},
      Signature(2, 0, 0), "positive definite"));
  known.push_back(known_matrix(
      Matrix{{-2.0, 1.0}, {1.0, -2.0}},
      Signature(0, 2, 0), "negative definite"));

  for(std::size_t first = 0; first < known.size(); ++first) {
    for(std::size_t second = 0; second < known.size(); ++second) {
      const Signature direct_signature(
          known[first].signature.positive + known[second].signature.positive,
          known[first].signature.negative + known[second].signature.negative,
          known[first].signature.zero + known[second].signature.zero);
      test.check_reliable_signature(
          matrix_signature::calculate_matrix_signature(
              direct_sum(known[first].matrix, known[second].matrix), options),
          direct_signature.positive, direct_signature.negative,
          direct_signature.zero,
          "direct sum of " + known[first].name + " and " +
              known[second].name);

      const std::size_t positive =
          known[first].signature.positive *
              known[second].signature.positive +
          known[first].signature.negative *
              known[second].signature.negative;
      const std::size_t negative =
          known[first].signature.positive *
              known[second].signature.negative +
          known[first].signature.negative *
              known[second].signature.positive;
      const std::size_t dimension =
          known[first].matrix.size() * known[second].matrix.size();
      test.check_reliable_signature(
          matrix_signature::calculate_matrix_signature(
              kronecker_product(known[first].matrix,
                                known[second].matrix),
              options),
          positive, negative, dimension - positive - negative,
          "Kronecker product of " + known[first].name + " and " +
              known[second].name);
    }
  }

  for(std::size_t dimension = 2; dimension <= 48; ++dimension) {
    const double scale = static_cast<double>(dimension);

    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            shifted_all_ones(dimension, scale, -1.0), options),
        dimension - 1, 0, 1,
        "positive singular aI+bJ matrix " + std::to_string(dimension));
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            shifted_all_ones(dimension, -scale, 1.0), options),
        0, dimension - 1, 1,
        "negative singular aI+bJ matrix " + std::to_string(dimension));
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            shifted_all_ones(dimension, scale, -2.0), options),
        dimension - 1, 1, 0,
        "indefinite aI+bJ matrix " + std::to_string(dimension));
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            shifted_all_ones(dimension, -scale, 2.0), options),
        1, dimension - 1, 0,
        "reversed indefinite aI+bJ matrix " +
            std::to_string(dimension));
  }

  std::mt19937 generator(27491u);
  std::uniform_int_distribution<int> off_diagonal(-5, 5);

  for(std::size_t test_case = 0; test_case < 96; ++test_case) {
    const std::size_t dimension = 1 + test_case % 32;
    Matrix matrix = zero_matrix(dimension);
    std::vector<double> row_sums(dimension, 0.0);

    for(std::size_t i = 0; i < dimension; ++i) {
      for(std::size_t j = i + 1; j < dimension; ++j) {
        const double entry = static_cast<double>(off_diagonal(generator));
        matrix[i][j] = entry;
        matrix[j][i] = entry;
        row_sums[i] += std::fabs(entry);
        row_sums[j] += std::fabs(entry);
      }
    }

    for(std::size_t i = 0; i < dimension; ++i)
      matrix[i][i] = row_sums[i] + 1.0 + static_cast<double>(test_case % 3);

    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(matrix, options),
        dimension, 0, 0,
        "strict positive diagonal dominance " +
            std::to_string(test_case));
    test.check_reliable_signature(
        matrix_signature::calculate_matrix_signature(
            scaled_matrix(matrix, -1.0), options),
        0, dimension, 0,
        "strict negative diagonal dominance " +
            std::to_string(test_case));
  }

  const std::vector<double> cutoffs = {
    std::numeric_limits<double>::denorm_min(),
    std::numeric_limits<double>::min(),
    1.0e-200,
    1.0,
    1.0e200,
    std::numeric_limits<double>::max() / 4.0
  };

  for(std::size_t i = 0; i < cutoffs.size(); ++i) {
    const double cutoff = cutoffs[i];
    const double below = std::nextafter(cutoff, 0.0);
    const double above = std::nextafter(
        cutoff, std::numeric_limits<double>::infinity());
    Options cutoff_options = silent_options();
    cutoff_options.zero_absolute_tolerance = cutoff;
    cutoff_options.zero_relative_tolerance = 0.0;

    const Result result = matrix_signature::calculate_matrix_signature(
        diagonal_matrix(std::vector<double>{
            0.0, below, -below, cutoff, -cutoff, above, -above}),
        cutoff_options);
    test.check_signature(result, 1, 1, 5,
                         "nextafter cutoff " + std::to_string(i));
    test.check(result.zero_tolerance == cutoff,
               "nextafter cutoff is reported exactly " +
                   std::to_string(i));
    test.check(result.numerically_ambiguous,
               "nextafter cutoff is marked ambiguous " +
                   std::to_string(i));
  }

  return test.finish();
}
