#include "symmetric_matrix_signature.hpp"

#if defined(__FAST_MATH__) || \
    (defined(__FINITE_MATH_ONLY__) && __FINITE_MATH_ONLY__ > 0) || \
    defined(__ASSOCIATIVE_MATH__) || defined(__RECIPROCAL_MATH__) || \
    (defined(_M_FP_FAST) && _M_FP_FAST)
#error "symmetric_matrix_signature requires strict IEEE floating-point semantics"
#endif

#if defined(__clang__)
// Clang does not expose individual unsafe transformations as macros.
#pragma float_control(precise, on)
#pragma clang fp reassociate(off)
#pragma clang fp reciprocal(off)
#endif

#include <algorithm>
#include <cfenv>
#include <climits>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <new>
#include <sstream>
#include <stdexcept>
#include <string>

namespace matrix_signature {
namespace {

enum LogLevel {
  SIGNATURE_LOG_INFO,
  SIGNATURE_LOG_WARNING,
  SIGNATURE_LOG_ERROR
};

const double ambiguity_factor = 8.0;
const double roundoff_guard_factor = 8.0;
const double rook_pivot_alpha =
    (1.0 + std::sqrt(17.0)) / 8.0;

const char *log_level_name(LogLevel level) {
  switch(level) {
    case SIGNATURE_LOG_INFO:
      return "INFO";
    case SIGNATURE_LOG_WARNING:
      return "WARNING";
    case SIGNATURE_LOG_ERROR:
      return "ERROR";
  }

  return "ERROR";
}

void write_log(const Options &options, LogLevel level,
               const char *message) noexcept {
  if(options.log_stream == nullptr)
    return;

  try {
    *options.log_stream << log_level_name(level) << ": " << message << '\n';
  }
  catch(...) {
    // Ignore errors from the log stream.
  }
}

void write_log(const Options &options, LogLevel level,
               const std::string &message) noexcept {
  write_log(options, level, message.c_str());
}

Result error_result(Status status, const Options &options,
                    const char *message, int solver_info = 0) noexcept {
  Result result;
  result.status = status;
  result.solver_info = solver_info;
  write_log(options, SIGNATURE_LOG_ERROR, message);

  return result;
}

Result error_result(Status status, const Options &options,
                    const std::string &message, int solver_info = 0) noexcept {
  return error_result(status, options, message.c_str(), solver_info);
}

Signature signature_or_throw(const Result &result) {
  if(result.reliable())
    return result.signature;

  std::ostringstream message;
  message << "calculate_matrix_signature_or_throw(): ";

  if(!result.ok()) {
    message << status_to_string(result.status) << ".";
  }
  else if(result.symmetry_adjusted && result.numerically_ambiguous) {
    message << "Result is not reliable because the input was averaged and "
            << "the classification is numerically ambiguous.";
  }
  else if(result.symmetry_adjusted) {
    message << "Result is not reliable because the input was averaged "
            << "within the symmetry tolerance.";
  }
  else {
    message << "Result is not reliable because the classification is "
            << "numerically ambiguous.";
  }

  throw std::runtime_error(message.str());
}

bool options_are_valid(const Options &options) {
  return std::isfinite(options.symmetry_absolute_tolerance) &&
         std::isfinite(options.symmetry_relative_tolerance) &&
         std::isfinite(options.zero_absolute_tolerance) &&
         std::isfinite(options.zero_relative_tolerance) &&
         options.symmetry_absolute_tolerance >= 0.0 &&
         options.symmetry_relative_tolerance >= 0.0 &&
         options.zero_absolute_tolerance >= 0.0 &&
         options.zero_relative_tolerance >= 0.0;
}

bool floating_point_environment_is_supported() {
  if(!std::numeric_limits<double>::is_iec559 ||
     std::numeric_limits<double>::has_denorm != std::denorm_present ||
     std::fegetround() != FE_TONEAREST)
    return false;

  volatile double denormal = std::numeric_limits<double>::denorm_min();
  volatile double one = 1.0;
  volatile double preserved_denormal = denormal * one;
  return preserved_denormal != 0.0;
}

double multiply_without_overflow(double first, double second) {
  if(first == 0.0 || second == 0.0)
    return 0.0;

  if(first > std::numeric_limits<double>::max() / second)
    return std::numeric_limits<double>::infinity();

  return first * second;
}

double add_without_overflow(double first, double second) {
  if(first > std::numeric_limits<double>::max() - second)
    return std::numeric_limits<double>::infinity();

  return first + second;
}

double multiply_without_range_loss(double first, double second,
                                   double third, double fourth = 1.0) {
  const double factors[4] = {first, second, third, fourth};
  double significand = 1.0;
  int exponent = 0;

  // Keep the exponent separate so that an intermediate product cannot
  // overflow or underflow when the complete product is representable.
  for(std::size_t i = 0; i < 4; ++i) {
    if(factors[i] == 0.0)
      return 0.0;

    int factor_exponent = 0;
    significand *= std::frexp(factors[i], &factor_exponent);
    exponent += factor_exponent;

    int significand_exponent = 0;
    significand = std::frexp(significand, &significand_exponent);
    exponent += significand_exponent;
  }

  return std::ldexp(significand, exponent);
}

long double normalized_mean(double first, double second, double scale) {
  int scale_exponent = 0;
  const double scale_fraction = std::frexp(scale, &scale_exponent);
  long double scaled_first = 0.0L;
  long double scaled_second = 0.0L;

  if(std::numeric_limits<long double>::max_exponent >
     std::numeric_limits<double>::max_exponent) {
    scaled_first =
        std::ldexp(static_cast<long double>(first), -scale_exponent);
    scaled_second =
        std::ldexp(static_cast<long double>(second), -scale_exponent);
  }
  else {
    scaled_first = static_cast<long double>(
        std::ldexp(first, -scale_exponent));
    scaled_second = static_cast<long double>(
        std::ldexp(second, -scale_exponent));
  }

  return (scaled_first + scaled_second) /
         (2.0L * static_cast<long double>(scale_fraction));
}

double power_of_two_scale(double maximum) {
  int exponent = 0;
  std::frexp(maximum, &exponent);
  return std::ldexp(1.0, exponent - 1);
}

enum MatrixPackingStatus {
  MATRIX_PACKING_SUCCESS,
  MATRIX_PACKING_RANGE_ERROR
};

struct FactorizationResult {
  Signature inertia;
  bool success;
  int failure_step;

  FactorizationResult()
      : inertia(), success(true), failure_step(0) {}
};

struct CutoffResult {
  Signature signature;
  bool success;
  bool boundary_singular;
  bool range_error;
  int failure_step;

  CutoffResult()
      : signature(), success(true), boundary_singular(false),
        range_error(false), failure_step(0) {}
};

struct PivotBlock {
  std::size_t first;
  std::size_t second;
  std::size_t size;

  PivotBlock() : first(0), second(0), size(1) {}
};

double &matrix_entry(std::vector<double> &matrix, std::size_t dimension,
                     std::size_t row, std::size_t column) {
  return matrix[row * dimension + column];
}

double matrix_entry(const std::vector<double> &matrix,
                    std::size_t dimension, std::size_t row,
                    std::size_t column) {
  return matrix[row * dimension + column];
}

void swap_symmetric_indices(std::vector<double> &matrix,
                            std::size_t dimension, std::size_t first,
                            std::size_t second) {
  if(first == second)
    return;

  for(std::size_t column = 0; column < dimension; ++column) {
    std::swap(matrix_entry(matrix, dimension, first, column),
              matrix_entry(matrix, dimension, second, column));
  }

  for(std::size_t row = 0; row < dimension; ++row) {
    std::swap(matrix_entry(matrix, dimension, row, first),
              matrix_entry(matrix, dimension, row, second));
  }
}

void largest_off_diagonal_in_row(const std::vector<double> &matrix,
                                 std::size_t dimension,
                                 std::size_t active_start,
                                 std::size_t row,
                                 std::size_t &column,
                                 double &maximum) {
  column = row;
  maximum = 0.0;

  for(std::size_t j = active_start; j < dimension; ++j) {
    if(j == row)
      continue;

    const double candidate = std::fabs(
        matrix_entry(matrix, dimension, row, j));
    if(candidate > maximum) {
      maximum = candidate;
      column = j;
    }
  }
}

bool choose_rook_pivot(const std::vector<double> &matrix,
                       std::size_t dimension, std::size_t active_start,
                       PivotBlock &pivot) {
  pivot.first = active_start;
  pivot.second = active_start;
  pivot.size = 1;

  const double diagonal = std::fabs(
      matrix_entry(matrix, dimension, active_start, active_start));
  std::size_t largest_row = active_start;
  double column_maximum = 0.0;

  for(std::size_t row = active_start + 1; row < dimension; ++row) {
    const double candidate = std::fabs(
        matrix_entry(matrix, dimension, row, active_start));
    if(candidate > column_maximum) {
      column_maximum = candidate;
      largest_row = row;
    }
  }

  if(std::max(diagonal, column_maximum) == 0.0 ||
     diagonal >= rook_pivot_alpha * column_maximum)
    return true;

  // Follow alternating row and column maxima until the bounded rook
  // criterion accepts a 1-by-1 pivot or selects a 2-by-2 pivot.
  std::size_t previous = active_start;
  for(std::size_t search = 0;
      search <= dimension - active_start; ++search) {
    std::size_t largest_column = largest_row;
    double row_maximum = 0.0;
    largest_off_diagonal_in_row(
        matrix, dimension, active_start, largest_row,
        largest_column, row_maximum);

    const double candidate_diagonal = std::fabs(
        matrix_entry(matrix, dimension, largest_row, largest_row));
    if(candidate_diagonal >= rook_pivot_alpha * row_maximum) {
      pivot.first = largest_row;
      return true;
    }

    if(previous == largest_column || row_maximum <= column_maximum) {
      pivot.first = previous;
      pivot.second = largest_row;
      pivot.size = 2;
      return true;
    }

    previous = largest_row;
    column_maximum = row_maximum;
    largest_row = largest_column;
  }

  return false;
}

void move_pivot_to_front(std::vector<double> &matrix,
                         std::size_t dimension,
                         std::size_t active_start,
                         const PivotBlock &pivot) {
  if(pivot.size == 1) {
    swap_symmetric_indices(
        matrix, dimension, active_start, pivot.first);
    return;
  }

  std::size_t second = pivot.second;
  if(pivot.first != active_start) {
    swap_symmetric_indices(
        matrix, dimension, active_start, pivot.first);
    if(second == active_start)
      second = pivot.first;
    else if(second == pivot.first)
      second = active_start;
  }

  swap_symmetric_indices(
      matrix, dimension, active_start + 1, second);
}

bool add_two_by_two_inertia(double first_diagonal, double off_diagonal,
                            double second_diagonal, Signature &inertia,
                            long double &block_scale,
                            long double &scaled_determinant) {
  block_scale = std::max(
      std::fabs(static_cast<long double>(first_diagonal)),
      std::max(std::fabs(static_cast<long double>(off_diagonal)),
               std::fabs(static_cast<long double>(second_diagonal))));

  if(block_scale == 0.0L) {
    inertia.zero += 2;
    scaled_determinant = 0.0L;
    return true;
  }

  const long double first =
      static_cast<long double>(first_diagonal) / block_scale;
  const long double off =
      static_cast<long double>(off_diagonal) / block_scale;
  const long double second =
      static_cast<long double>(second_diagonal) / block_scale;
  scaled_determinant = first * second - off * off;

  // A negative determinant gives opposite signs. Otherwise the trace
  // selects the common sign, with a zero determinant contributing a zero.
  if(scaled_determinant < 0.0L) {
    ++inertia.positive;
    ++inertia.negative;
    return true;
  }

  const long double trace = first + second;
  if(scaled_determinant > 0.0L) {
    if(trace > 0.0L)
      inertia.positive += 2;
    else if(trace < 0.0L)
      inertia.negative += 2;
    else
      return false;

    return true;
  }

  ++inertia.zero;
  if(trace > 0.0L)
    ++inertia.positive;
  else if(trace < 0.0L)
    ++inertia.negative;
  else
    ++inertia.zero;

  return true;
}

bool store_finite_update(std::vector<double> &matrix,
                         std::size_t dimension, std::size_t row,
                         std::size_t column, long double updated) {
  const double value = static_cast<double>(updated);
  if(!std::isfinite(value))
    return false;

  matrix_entry(matrix, dimension, row, column) = value;
  matrix_entry(matrix, dimension, column, row) = value;
  return true;
}

FactorizationResult factor_inertia(std::vector<double> &matrix,
                                   std::size_t dimension,
                                   std::vector<double> &multipliers) {
  FactorizationResult result;
  std::size_t active_start = 0;

  // Bounded Bunch-Kaufman rook pivoting selects 1-by-1 or 2-by-2 diagonal
  // blocks and applies their Schur-complement updates in place.
  while(active_start < dimension) {
    PivotBlock pivot;
    if(!choose_rook_pivot(matrix, dimension, active_start, pivot)) {
      result.success = false;
      result.failure_step = static_cast<int>(active_start + 1);
      return result;
    }

    move_pivot_to_front(matrix, dimension, active_start, pivot);

    if(pivot.size == 1) {
      const double diagonal = matrix_entry(
          matrix, dimension, active_start, active_start);
      if(diagonal > 0.0)
        ++result.inertia.positive;
      else if(diagonal < 0.0)
        ++result.inertia.negative;
      else
        ++result.inertia.zero;

      if(diagonal == 0.0) {
        for(std::size_t row = active_start + 1;
            row < dimension; ++row) {
          if(matrix_entry(matrix, dimension, row, active_start) != 0.0) {
            result.success = false;
            result.failure_step = static_cast<int>(active_start + 1);
            return result;
          }
        }

        ++active_start;
        continue;
      }

      // Divide the pivot column by the 1-by-1 block before updating the
      // trailing symmetric matrix.
      for(std::size_t row = active_start + 1;
          row < dimension; ++row) {
        const long double multiplier =
            static_cast<long double>(matrix_entry(
                matrix, dimension, row, active_start)) /
            static_cast<long double>(diagonal);
        multipliers[row] = static_cast<double>(multiplier);
        if(!std::isfinite(multipliers[row])) {
          result.success = false;
          result.failure_step = static_cast<int>(active_start + 1);
          return result;
        }
      }

      for(std::size_t row = active_start + 1;
          row < dimension; ++row) {
        for(std::size_t column = active_start + 1;
            column <= row; ++column) {
          const long double updated =
              static_cast<long double>(matrix_entry(
                  matrix, dimension, row, column)) -
              static_cast<long double>(matrix_entry(
                  matrix, dimension, row, active_start)) *
              static_cast<long double>(multipliers[column]);
          if(!store_finite_update(
                 matrix, dimension, row, column, updated)) {
            result.success = false;
            result.failure_step = static_cast<int>(active_start + 1);
            return result;
          }
        }
      }

      ++active_start;
      continue;
    }

    const double first_diagonal = matrix_entry(
        matrix, dimension, active_start, active_start);
    const double off_diagonal = matrix_entry(
        matrix, dimension, active_start + 1, active_start);
    const double second_diagonal = matrix_entry(
        matrix, dimension, active_start + 1, active_start + 1);
    long double block_scale = 0.0L;
    long double scaled_determinant = 0.0L;
    if(!add_two_by_two_inertia(
           first_diagonal, off_diagonal, second_diagonal,
           result.inertia, block_scale, scaled_determinant)) {
      result.success = false;
      result.failure_step = static_cast<int>(active_start + 1);
      return result;
    }

    // A 2-by-2 block must be invertible while rows remain below it.
    if(active_start + 2 < dimension && scaled_determinant == 0.0L) {
      result.success = false;
      result.failure_step = static_cast<int>(active_start + 1);
      return result;
    }

    if(scaled_determinant != 0.0L) {
      const long double first =
          static_cast<long double>(first_diagonal) / block_scale;
      const long double off =
          static_cast<long double>(off_diagonal) / block_scale;
      const long double second =
          static_cast<long double>(second_diagonal) / block_scale;

      // Solve the 2-by-2 block for both multipliers before applying its
      // Schur-complement update.
      for(std::size_t row = active_start + 2;
          row < dimension; ++row) {
        const long double first_entry =
            static_cast<long double>(matrix_entry(
                matrix, dimension, row, active_start)) / block_scale;
        const long double second_entry =
            static_cast<long double>(matrix_entry(
                matrix, dimension, row, active_start + 1)) / block_scale;
        const long double first_multiplier =
            (second * first_entry - off * second_entry) /
            scaled_determinant;
        const long double second_multiplier =
            (first * second_entry - off * first_entry) /
            scaled_determinant;
        multipliers[row] = static_cast<double>(first_multiplier);
        multipliers[dimension + row] =
            static_cast<double>(second_multiplier);
        if(!std::isfinite(multipliers[row]) ||
           !std::isfinite(multipliers[dimension + row])) {
          result.success = false;
          result.failure_step = static_cast<int>(active_start + 1);
          return result;
        }
      }

      for(std::size_t row = active_start + 2;
          row < dimension; ++row) {
        for(std::size_t column = active_start + 2;
            column <= row; ++column) {
          const long double updated =
              static_cast<long double>(matrix_entry(
                  matrix, dimension, row, column)) -
              static_cast<long double>(matrix_entry(
                  matrix, dimension, row, active_start)) *
              static_cast<long double>(multipliers[column]) -
              static_cast<long double>(matrix_entry(
                  matrix, dimension, row, active_start + 1)) *
              static_cast<long double>(multipliers[dimension + column]);
          if(!store_finite_update(
                 matrix, dimension, row, column, updated)) {
            result.success = false;
            result.failure_step = static_cast<int>(active_start + 1);
            return result;
          }
        }
      }
    }

    active_start += 2;
  }

  return result;
}

MatrixPackingStatus pack_normalized_matrix(
    const Matrix &matrix, double matrix_scale, double diagonal_shift,
    bool check_input_range, std::vector<double> &packed) {
  const std::size_t dimension = matrix.size();

  for(std::size_t i = 0; i < dimension; ++i) {
    for(std::size_t j = i; j < dimension; ++j) {
      bool entry_is_nonzero = matrix[i][j] != 0.0;
      long double normalized_entry =
          static_cast<long double>(matrix[i][j]) /
          static_cast<long double>(matrix_scale);
      if(i != j) {
        normalized_entry = normalized_mean(
            matrix[i][j], matrix[j][i], matrix_scale);
        entry_is_nonzero = matrix[i][j] != -matrix[j][i];
      }

      const double unshifted = static_cast<double>(normalized_entry);
      if(check_input_range && entry_is_nonzero && unshifted == 0.0)
        return MATRIX_PACKING_RANGE_ERROR;

      long double shifted_entry = static_cast<long double>(unshifted);
      if(i == j)
        shifted_entry -= static_cast<long double>(diagonal_shift);

      const double value = static_cast<double>(shifted_entry);
      if(!std::isfinite(value))
        return MATRIX_PACKING_RANGE_ERROR;

      matrix_entry(packed, dimension, i, j) = value;
      matrix_entry(packed, dimension, j, i) = value;
    }
  }

  return MATRIX_PACKING_SUCCESS;
}

double frobenius_norm(const std::vector<double> &matrix) {
  double scale = 0.0;
  double sum_of_squares = 1.0;

  for(std::size_t i = 0; i < matrix.size(); ++i) {
    const double absolute_entry = std::fabs(matrix[i]);
    if(absolute_entry == 0.0)
      continue;

    if(scale < absolute_entry) {
      const double ratio = scale / absolute_entry;
      sum_of_squares = 1.0 + sum_of_squares * ratio * ratio;
      scale = absolute_entry;
    }
    else {
      const double ratio = absolute_entry / scale;
      sum_of_squares += ratio * ratio;
    }
  }

  return scale == 0.0 ? 0.0 : scale * std::sqrt(sum_of_squares);
}

CutoffResult signature_at_cutoff(
    const Matrix &matrix, double matrix_scale, double matrix_norm,
    double cutoff, std::vector<double> &packed,
    std::vector<double> &multipliers) {
  CutoffResult result;
  const std::size_t dimension = matrix.size();

  if(cutoff > matrix_norm) {
    result.signature = Signature(0, 0, dimension);
    return result;
  }

  // Sylvester's law gives the counts outside [-cutoff, cutoff] from the
  // inertia of A-cutoff*I and A+cutoff*I, without computing eigenvalues.
  if(pack_normalized_matrix(
         matrix, matrix_scale, cutoff, false, packed) !=
     MATRIX_PACKING_SUCCESS) {
    result.success = false;
    result.range_error = true;
    return result;
  }
  const FactorizationResult positive_factorization =
      factor_inertia(packed, dimension, multipliers);
  if(!positive_factorization.success) {
    result.success = false;
    result.failure_step = positive_factorization.failure_step;
    return result;
  }

  if(pack_normalized_matrix(
         matrix, matrix_scale, -cutoff, false, packed) !=
     MATRIX_PACKING_SUCCESS) {
    result.success = false;
    result.range_error = true;
    return result;
  }
  const FactorizationResult negative_factorization =
      factor_inertia(packed, dimension, multipliers);
  if(!negative_factorization.success) {
    result.success = false;
    result.failure_step = negative_factorization.failure_step;
    return result;
  }

  const std::size_t positive =
      positive_factorization.inertia.positive;
  const std::size_t negative =
      negative_factorization.inertia.negative;
  if(positive > dimension || negative > dimension - positive) {
    result.success = false;
    return result;
  }

  result.signature = Signature(
      positive, negative, dimension - positive - negative);
  result.boundary_singular =
      positive_factorization.inertia.zero != 0 ||
      negative_factorization.inertia.zero != 0;
  return result;
}

bool signatures_are_equal(const Signature &first, const Signature &second) {
  return first.positive == second.positive &&
         first.negative == second.negative &&
         first.zero == second.zero;
}

bool signatures_are_monotone(const Signature &lower,
                             const Signature &upper) {
  return lower.positive >= upper.positive &&
         lower.negative >= upper.negative &&
         lower.zero <= upper.zero;
}

Result calculate_signature(const Matrix &matrix, const Options &options) {
  const std::size_t dimension = matrix.size();

  for(std::size_t i = 0; i < dimension; ++i) {
    if(matrix[i].size() != dimension) {
      std::ostringstream message;
      message << "calculate_matrix_signature(): Matrix is not square; row "
              << i << " has " << matrix[i].size() << " entries, expected "
              << dimension << ".";
      return error_result(STATUS_NON_SQUARE_MATRIX, options, message.str());
    }
  }

  if(dimension == 0) {
    Result result;
    result.status = STATUS_SUCCESS;
    result.signature = Signature(0, 0, 0);
    result.zero_tolerance = options.zero_absolute_tolerance;

    if(options.log_success)
      write_log(options, SIGNATURE_LOG_INFO,
                "calculate_matrix_signature(): Empty matrix has signature (0, 0, 0).");

    return result;
  }

  if(dimension > static_cast<std::size_t>(INT_MAX) ||
     dimension > std::numeric_limits<std::size_t>::max() / dimension ||
     dimension > std::numeric_limits<std::size_t>::max() / 2) {
    return error_result(
        STATUS_MATRIX_TOO_LARGE, options,
        "calculate_matrix_signature(): Matrix dimension exceeds the internal "
        "factorization or storage range.");
  }

  double matrix_maximum = 0.0;
  for(std::size_t i = 0; i < dimension; ++i) {
    for(std::size_t j = 0; j < dimension; ++j) {
      if(!std::isfinite(matrix[i][j])) {
        std::ostringstream message;
        message << "calculate_matrix_signature(): Matrix entry (" << i << ", "
                << j << ") is not finite.";
        return error_result(STATUS_NON_FINITE_ENTRY, options, message.str());
      }

      matrix_maximum = std::max(
          matrix_maximum, std::fabs(matrix[i][j]));
    }
  }

  if(matrix_maximum == 0.0) {
    Result result;
    result.status = STATUS_SUCCESS;
    result.signature = Signature(0, 0, dimension);
    result.zero_tolerance = options.zero_absolute_tolerance;

    if(options.log_success)
      write_log(options, SIGNATURE_LOG_INFO,
                "calculate_matrix_signature(): Zero matrix classified successfully.");

    return result;
  }

  const bool exact_symmetry_required =
      options.symmetry_absolute_tolerance == 0.0 &&
      options.symmetry_relative_tolerance == 0.0;
  const long double symmetry_tolerance =
      static_cast<long double>(options.symmetry_absolute_tolerance) +
      static_cast<long double>(options.symmetry_relative_tolerance) *
      static_cast<long double>(matrix_maximum);
  const long double normalized_symmetry_tolerance =
      static_cast<long double>(options.symmetry_absolute_tolerance) /
          static_cast<long double>(matrix_maximum) +
      static_cast<long double>(options.symmetry_relative_tolerance);
  const long double largest_double =
      static_cast<long double>(std::numeric_limits<double>::max());
  long double maximum_asymmetry = 0.0L;
  long double maximum_normalized_asymmetry = 0.0L;
  bool symmetry_adjusted = false;

  for(std::size_t i = 0; i < dimension; ++i) {
    for(std::size_t j = i + 1; j < dimension; ++j) {
      const long double difference = std::fabs(
          static_cast<long double>(matrix[i][j]) -
          static_cast<long double>(matrix[j][i]));
      const long double normalized_difference = std::fabs(
          static_cast<long double>(matrix[i][j]) /
              static_cast<long double>(matrix_maximum) -
          static_cast<long double>(matrix[j][i]) /
              static_cast<long double>(matrix_maximum));
      maximum_asymmetry = std::max(maximum_asymmetry, difference);
      maximum_normalized_asymmetry = std::max(
          maximum_normalized_asymmetry, normalized_difference);

      symmetry_adjusted = symmetry_adjusted || matrix[i][j] != matrix[j][i];

      const bool compare_in_normalized_units =
          !std::isfinite(difference) ||
          !std::isfinite(symmetry_tolerance) ||
          difference > largest_double || symmetry_tolerance > largest_double;
      bool entries_match = matrix[i][j] == matrix[j][i];
      if(!exact_symmetry_required) {
        if(compare_in_normalized_units)
          entries_match = normalized_difference <= normalized_symmetry_tolerance;
        else
          entries_match = difference <= symmetry_tolerance;
      }

      if(!entries_match) {
        std::ostringstream message;
        message << std::setprecision(
            std::numeric_limits<long double>::max_digits10);
        message << "calculate_matrix_signature(): Matrix is not symmetric; entries ("
                << i << ", " << j << ") and (" << j << ", " << i << ") ";
        if(compare_in_normalized_units) {
          message << "have normalized difference " << normalized_difference
                  << ", normalized tolerance is "
                  << normalized_symmetry_tolerance << ".";
        }
        else {
          message << "differ by " << difference << ", tolerance is "
                  << symmetry_tolerance << ".";
        }
        return error_result(STATUS_NON_SYMMETRIC_MATRIX, options, message.str());
      }
    }
  }

  Result result;
  result.symmetry_adjusted = symmetry_adjusted;

  if(symmetry_adjusted) {
    std::ostringstream message;
    message << std::setprecision(
        std::numeric_limits<long double>::max_digits10);
    message << "calculate_matrix_signature(): The matrix is symmetric only "
            << "within tolerance; ";
    if(!std::isfinite(maximum_asymmetry) ||
       !std::isfinite(symmetry_tolerance) ||
       maximum_asymmetry > largest_double ||
       symmetry_tolerance > largest_double) {
      message << "maximum normalized difference is "
              << maximum_normalized_asymmetry
              << ", normalized tolerance is "
              << normalized_symmetry_tolerance;
    }
    else {
      message << "maximum difference is " << maximum_asymmetry
              << ", tolerance is " << symmetry_tolerance;
    }
    message << ". Corresponding entries were averaged.";
    write_log(options, SIGNATURE_LOG_WARNING, message.str());

    // A user-provided log stream can change the floating-point environment.
    // Detect that change before scaling the averaged matrix.
    if(!floating_point_environment_is_supported()) {
      return error_result(
          STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT, options,
          "calculate_matrix_signature(): The floating-point environment must "
          "use IEEE double precision, round-to-nearest and gradual underflow.");
    }
  }

  const std::size_t matrix_size = dimension * dimension;
  std::vector<double> packed_matrix(matrix_size, 0.0);
  std::vector<double> multipliers(2 * dimension, 0.0);
  const double normalization_scale = power_of_two_scale(matrix_maximum);

  // A power-of-two scale keeps binary input values exact whenever they remain
  // representable. Scaling before averaging also keeps finite means in range.
  if(pack_normalized_matrix(
         matrix, normalization_scale, 0.0, true,
         packed_matrix) !=
     MATRIX_PACKING_SUCCESS) {
    std::ostringstream message;
    message << std::setprecision(
        std::numeric_limits<double>::max_digits10);
    message << "calculate_matrix_signature(): Scaling would lose a nonzero "
            << "matrix entry; normalization scale is "
            << normalization_scale << ".";
    return error_result(
        STATUS_NUMERICAL_RANGE_ERROR, options, message.str());
  }

  const double normalized_matrix_norm = frobenius_norm(packed_matrix);
  if(normalized_matrix_norm == 0.0) {
    result.status = STATUS_SUCCESS;
    result.signature = Signature(0, 0, dimension);
    result.zero_tolerance = options.zero_absolute_tolerance;

    if(options.log_success) {
      std::ostringstream message;
      message << "calculate_matrix_signature(): Signature is (0, 0, "
              << dimension << ").";
      write_log(options, SIGNATURE_LOG_INFO, message.str());
    }

    return result;
  }

  const double normalized_relative_zero_tolerance =
      multiply_without_range_loss(
          options.zero_relative_tolerance, normalized_matrix_norm,
          static_cast<double>(dimension));
  const double requested_normalized_zero_tolerance = add_without_overflow(
      options.zero_absolute_tolerance / normalization_scale,
      normalized_relative_zero_tolerance);
  const double normalized_roundoff_guard = multiply_without_range_loss(
      roundoff_guard_factor * std::numeric_limits<double>::epsilon(),
      normalized_matrix_norm, static_cast<double>(dimension));
  const double normalized_zero_tolerance = std::max(
      requested_normalized_zero_tolerance, normalized_roundoff_guard);
  const double relative_zero_tolerance_in_input_units =
      multiply_without_range_loss(
          options.zero_relative_tolerance, normalized_matrix_norm,
          normalization_scale, static_cast<double>(dimension));
  const double requested_zero_tolerance_in_input_units = add_without_overflow(
      options.zero_absolute_tolerance,
      relative_zero_tolerance_in_input_units);
  const double roundoff_guard_in_input_units = multiply_without_range_loss(
      normalized_roundoff_guard, normalization_scale, 1.0);
  const double zero_tolerance_in_input_units = std::max(
      requested_zero_tolerance_in_input_units,
      roundoff_guard_in_input_units);

  if(normalized_roundoff_guard > requested_normalized_zero_tolerance) {
    std::ostringstream message;
    message << std::setprecision(
        std::numeric_limits<double>::max_digits10);
    message << "calculate_matrix_signature(): Requested zero cutoff "
            << requested_zero_tolerance_in_input_units
            << " is below the roundoff floor; effective cutoff "
            << zero_tolerance_in_input_units << " will be used.";
    write_log(options, SIGNATURE_LOG_WARNING, message.str());
  }

  // Check again after the roundoff warning, immediately before factorization.
  if(!floating_point_environment_is_supported()) {
    return error_result(
        STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT, options,
        "calculate_matrix_signature(): The floating-point environment must "
        "use IEEE double precision, round-to-nearest and gradual underflow.");
  }

  CutoffResult signature_result;
  bool ambiguous = false;
  double lower_ambiguity_limit = 0.0;
  double upper_ambiguity_limit = 0.0;

  // Equal counts at the two ends of the ambiguity interval also determine
  // the signature at its interior cutoff. A third count is then unnecessary.
  lower_ambiguity_limit =
      normalized_zero_tolerance / ambiguity_factor;
  upper_ambiguity_limit = multiply_without_overflow(
      normalized_zero_tolerance, ambiguity_factor);

  const CutoffResult lower_result = signature_at_cutoff(
      matrix, normalization_scale, normalized_matrix_norm,
      lower_ambiguity_limit, packed_matrix, multipliers);
  const CutoffResult upper_result = signature_at_cutoff(
      matrix, normalization_scale, normalized_matrix_norm,
      upper_ambiguity_limit, packed_matrix, multipliers);

  if(!lower_result.success || !upper_result.success) {
    const CutoffResult &failed =
        !lower_result.success ? lower_result : upper_result;
    if(failed.range_error) {
      return error_result(
          STATUS_NUMERICAL_RANGE_ERROR, options,
          "calculate_matrix_signature(): The requested zero cutoff is "
          "outside the usable floating-point range after scaling.");
    }

    return error_result(
        STATUS_SOLVER_FAILURE, options,
        "calculate_matrix_signature(): Internal LDLT factorization failed.",
        failed.failure_step);
  }

  if(!signatures_are_monotone(
         lower_result.signature, upper_result.signature)) {
    return error_result(
        STATUS_SOLVER_FAILURE, options,
        "calculate_matrix_signature(): Shifted LDLT inertia counts are "
        "not monotone.");
  }

  ambiguous =
      !signatures_are_equal(
          lower_result.signature, upper_result.signature) ||
      lower_result.boundary_singular ||
      upper_result.boundary_singular;

  if(signatures_are_equal(
         lower_result.signature, upper_result.signature)) {
    signature_result = lower_result;
  }
  else {
    signature_result = signature_at_cutoff(
        matrix, normalization_scale, normalized_matrix_norm,
        normalized_zero_tolerance, packed_matrix, multipliers);

    if(signature_result.success &&
       (!signatures_are_monotone(
            lower_result.signature, signature_result.signature) ||
        !signatures_are_monotone(
            signature_result.signature, upper_result.signature))) {
      signature_result.success = false;
    }
  }

  if(!signature_result.success) {
    if(signature_result.range_error) {
      return error_result(
          STATUS_NUMERICAL_RANGE_ERROR, options,
          "calculate_matrix_signature(): The requested zero cutoff is "
          "outside the usable floating-point range after scaling.");
    }

    return error_result(
        STATUS_SOLVER_FAILURE, options,
        "calculate_matrix_signature(): Internal LDLT factorization failed.",
        signature_result.failure_step);
  }

  result.status = STATUS_SUCCESS;
  result.signature = signature_result.signature;
  result.zero_tolerance = zero_tolerance_in_input_units;
  result.numerically_ambiguous = ambiguous;

  if(ambiguous) {
    std::ostringstream message;
    message << std::setprecision(std::numeric_limits<double>::max_digits10);
    message << "calculate_matrix_signature(): The classification is "
            << "sensitive within the zero-cutoff interval ["
            << multiply_without_overflow(
                   lower_ambiguity_limit, normalization_scale)
            << ", "
            << multiply_without_overflow(
                   upper_ambiguity_limit, normalization_scale)
            << "]; the result at cutoff " << result.zero_tolerance
            << " is tolerance-dependent.";
    write_log(options, SIGNATURE_LOG_WARNING, message.str());
  }

  if(options.log_success) {
    std::ostringstream message;
    message << "calculate_matrix_signature(): Signature is ("
            << result.signature.positive << ", "
            << result.signature.negative << ", "
            << result.signature.zero << ").";
    write_log(options, SIGNATURE_LOG_INFO, message.str());
  }

  return result;
}

} // namespace

Signature::Signature() : positive(0), negative(0), zero(0) {}

Signature::Signature(std::size_t positive_count,
                     std::size_t negative_count,
                     std::size_t zero_count)
    : positive(positive_count),
      negative(negative_count),
      zero(zero_count) {}

Options::Options()
    : symmetry_absolute_tolerance(0.0),
      symmetry_relative_tolerance(
          64.0 * std::numeric_limits<double>::epsilon()),
      zero_absolute_tolerance(0.0),
      zero_relative_tolerance(
          8.0 * std::numeric_limits<double>::epsilon()),
      log_stream(&std::cerr),
      log_success(false) {}

Result::Result()
    : status(STATUS_INTERNAL_ERROR),
      signature(),
      zero_tolerance(0.0),
      symmetry_adjusted(false),
      numerically_ambiguous(false),
      solver_info(0) {}

bool Result::ok() const {
  return status == STATUS_SUCCESS;
}

bool Result::reliable() const {
  return ok() && !numerically_ambiguous && !symmetry_adjusted;
}

Result calculate_matrix_signature(const Matrix &matrix,
                                  const Options &options) {
  if(!options_are_valid(options)) {
    return error_result(
        STATUS_INVALID_OPTIONS, options,
        "calculate_matrix_signature(): Tolerances must be finite and non-negative.");
  }

  if(!floating_point_environment_is_supported()) {
    return error_result(
        STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT, options,
        "calculate_matrix_signature(): The floating-point environment must "
        "use IEEE double precision, round-to-nearest and gradual underflow.");
  }

  try {
    return calculate_signature(matrix, options);
  }
  catch(const std::bad_alloc &) {
    return error_result(
        STATUS_ALLOCATION_FAILURE, options,
        "calculate_matrix_signature(): Memory allocation failed.");
  }
  catch(const std::length_error &) {
    return error_result(
        STATUS_MATRIX_TOO_LARGE, options,
        "calculate_matrix_signature(): Required storage exceeds the container limits.");
  }
  catch(const std::exception &exception) {
    try {
      std::ostringstream message;
      message << "calculate_matrix_signature(): Internal error: "
              << exception.what() << ".";
      return error_result(STATUS_INTERNAL_ERROR, options, message.str());
    }
    catch(...) {
      return error_result(
          STATUS_INTERNAL_ERROR, options,
          "calculate_matrix_signature(): Internal error.");
    }
  }
  catch(...) {
    return error_result(
        STATUS_INTERNAL_ERROR, options,
        "calculate_matrix_signature(): Unknown internal error.");
  }
}

Result calculate_matrix_signature(const Matrix *matrix,
                                  const Options &options) {
  if(!options_are_valid(options)) {
    return error_result(
        STATUS_INVALID_OPTIONS, options,
        "calculate_matrix_signature(): Tolerances must be finite and non-negative.");
  }

  if(matrix == nullptr) {
    return error_result(
        STATUS_NULL_MATRIX, options,
        "calculate_matrix_signature(): Matrix pointer is null.");
  }

  return calculate_matrix_signature(*matrix, options);
}

Signature calculate_matrix_signature_or_throw(
    const Matrix &matrix, const Options &options) {
  return signature_or_throw(calculate_matrix_signature(matrix, options));
}

Signature calculate_matrix_signature_or_throw(
    const Matrix *matrix, const Options &options) {
  return signature_or_throw(calculate_matrix_signature(matrix, options));
}

const char *status_to_string(Status status) {
  switch(status) {
    case STATUS_SUCCESS:
      return "success";
    case STATUS_NULL_MATRIX:
      return "null matrix";
    case STATUS_NON_SQUARE_MATRIX:
      return "non-square matrix";
    case STATUS_NON_SYMMETRIC_MATRIX:
      return "non-symmetric matrix";
    case STATUS_NON_FINITE_ENTRY:
      return "non-finite matrix entry";
    case STATUS_INVALID_OPTIONS:
      return "invalid options";
    case STATUS_MATRIX_TOO_LARGE:
      return "matrix too large";
    case STATUS_NUMERICAL_RANGE_ERROR:
      return "numerical range error";
    case STATUS_ALLOCATION_FAILURE:
      return "allocation failure";
    case STATUS_SOLVER_FAILURE:
      return "factorization failure";
    case STATUS_INTERNAL_ERROR:
      return "internal error";
    case STATUS_UNSUPPORTED_FLOATING_POINT_ENVIRONMENT:
      return "unsupported floating-point environment";
  }

  return "unknown status";
}

} // namespace matrix_signature
