
#include "triangulator.hpp"

unsigned long UniqueIDColor::next_free_uid_number = 1;

Color::~Color()
{
}


void Color::print(){
  cout << "color: " << get_color_name_from_type(type) << " (type " << type << "), value: " << this->get_color_value_as_str() << endl;
}

//string Color::get_color_value_as_str() const
//{
//    return "";
//}

/**
 * @brief Creates new colour and gets its value from string, adding it to the
 * given KSimplex.
 * 
 * @details Uses switch structure to set the right colour class from
 * color_type integer. New types should be added to the switch as they are
 * created.
 * 
 * @param ks KSimplex to add the colour to.
 * @param color_type Type of the colour to be created.
 * @param color_value Value of the colour to be created.
 */

bool Color::colorize_simplex_from_string(KSimplex* simp, const int color_type, const string& color_value)
{
    // This is a horrible solution. We should think of some other way of doing this
    switch(color_type) {
    case TYPE_BOUNDARY:
        return BoundaryColor::colorize_single_simplex(simp);
    case TYPE_PACHNER:
        return PachnerColor::colorize_single_simplex(simp);
    case TYPE_UNIQUE_ID:
        return UniqueIDColor::colorize_single_simplex(simp);
    case TYPE_DRAWING_COORDINATES:
      return DrawingCoordinatesColor::colorize_single_simplex(simp,color_value);
    case TYPE_VOLUME_SQUARED:
      return VolumeSquaredColor::colorize_single_simplex(simp,color_value);
    default:
      log_report(LOG_ERROR,"Color::colorize_simplex_from_string : Color type " + to_string(color_type) + " not recognized! Fix your code!");
      return false;
    }
}

bool Color::is_colorized_with_type(KSimplex* simp, int typecode)
{
    for(auto &color : simp->colors)
        if(color->type == typecode)
            return true;
    return false;
}

Color* Color::find_pointer_to_color_type(KSimplex* simp, int typecode)
{
    for(auto &color : simp->colors)
        if(color->type == typecode)
            return color;
    return nullptr;
}

void Color::remove_color_type_from_simplex(KSimplex* simp, int typecode)
{
    unsigned int i, size;

    while( Color::is_colorized_with_type(simp,typecode) ){
        i = 0;
        while( simp->colors[i]->type != typecode )
            i++;
        delete simp->colors[i];
        size = simp->colors.size(); 
        if(i < size - 1) simp->colors[i] = simp->colors[size-1];
        simp->colors.pop_back();
    }
}

void Color::remove_color_type_from_level(SimpComp* G, int level, int typecode){
    for (auto simp : G->elements[level]) Color::remove_color_type_from_simplex(simp, typecode);
}

void Color::remove_color_type_from_complex(SimpComp* G, int typecode){
    for (int level = 0; level <= G->D; level++) Color::remove_color_type_from_level(G, level, typecode);
}

string get_color_name_from_type(int color_type){
    switch(color_type) {
        case TYPE_BOUNDARY:
            return "Boundary";
        case TYPE_PACHNER:
            return "Pachner";
        case TYPE_UNIQUE_ID:
            return "UniqueID";
        case TYPE_DRAWING_COORDINATES:
            return "DrawingCoordinates";
        case TYPE_VOLUME_SQUARED:
            return "VolumeSquared";
        default:
            return "Unknown color name, type " + to_string(color_type);
    }
}

BoundaryColor::BoundaryColor(){
    type = TYPE_BOUNDARY;
}

BoundaryColor::~BoundaryColor(){
}

bool BoundaryColor::colorize_single_simplex(KSimplex* simp)
{
  bool outcome = true;
  BoundaryColor* color = new(nothrow) BoundaryColor();
  if (color==nullptr) {
    outcome = false;
    log_report(LOG_PANIC,"BoundaryColor::colorize_single_simplex : PANIC!!! CANNOT ALLOCATE MEMORY!!!");
  }
  else simp->colors.push_back(color);
  return outcome;
}

bool BoundaryColor::colorize_simplices_at_level(SimpComp* G, int level)
{
  bool outcome = true;
  bool temp;
  for (auto simplex : G->elements[level]) {
    temp = BoundaryColor::colorize_single_simplex(simplex);
    if (!temp) outcome = false;
    }
  return outcome;
}

void BoundaryColor::remove_color_from_simplex(KSimplex* simp)
{
  Color::remove_color_type_from_simplex(simp, TYPE_BOUNDARY);
}

string BoundaryColor::get_color_value_as_str()
{
    return "true";
}

void BoundaryColor::set_color_value_from_str(const string& source)
{
  if (source=="true") return; // This is a dummy command, do not remove
}









PachnerColor::PachnerColor(){
    type = TYPE_PACHNER;
}

PachnerColor::~PachnerColor(){
}

bool PachnerColor::colorize_single_simplex(KSimplex* simp)
{
  bool outcome = true;
  PachnerColor* color = new(nothrow) PachnerColor();
  if (color==nullptr) {
    outcome = false;
    log_report(LOG_PANIC,"PachnerColor::colorize_single_simplex : PANIC!!! CANNOT ALLOCATE MEMORY!!!");
  }
  else simp->colors.push_back(color);
  return outcome;
}

bool PachnerColor::colorize_simplices_at_level(SimpComp* G, int level)
{
  bool outcome = true;
  bool temp;
  for (auto simplex : G->elements[level]) {
    temp = PachnerColor::colorize_single_simplex(simplex);
    if (!temp) outcome = false;
    }
  return outcome;
}

bool PachnerColor::colorize_entire_complex(SimpComp* G)
{
  bool outcome=true;
  bool temp;
  for (int level = 0; level <= G->D; level++) {
       temp = PachnerColor::colorize_simplices_at_level(G, level);
       if (!temp) outcome = false;
    }
  return outcome;
}

void PachnerColor::remove_color_from_simplex(KSimplex* simp)
{
  Color::remove_color_type_from_simplex(simp, TYPE_PACHNER);
}

void PachnerColor::remove_color_from_level(SimpComp* G, int level)
{
  Color::remove_color_type_from_level(G, level, TYPE_PACHNER);
}

void PachnerColor::remove_color_from_complex(SimpComp* G)
{
  Color::remove_color_type_from_complex(G, TYPE_PACHNER);
}

bool PachnerColor::is_colorized(KSimplex* simp)
{
  return Color::is_colorized_with_type(simp,TYPE_PACHNER);
}

PachnerColor* PachnerColor::find_pointer_to_color(KSimplex* simp)
{
  Color *temp = Color::find_pointer_to_color_type(simp, TYPE_PACHNER);
  return static_cast<PachnerColor*>(temp);
}


string PachnerColor::get_color_value_as_str()
{
  string s="internal: ";
  if (internalSimplex) s = s + "true, external: ";
  else s = s + "false, external: ";
  if (externalSimplex) s = s + "true, immutable: ";
  else s = s + "false, immutable: ";
  if (immutable) s = s + "true.";
  else s = s + "false.";
  return s;
}

void PachnerColor::set_color_value_from_str(const string& source)
{
  if (source=="true") return; // This is a dummy command, do not remove
}






UniqueIDColor::UniqueIDColor(){
    type = TYPE_UNIQUE_ID;
    id = next_free_uid_number++;
}

UniqueIDColor::~UniqueIDColor(){
}

UniqueIDColor::UniqueIDColor(unsigned long uid){
    type = TYPE_UNIQUE_ID;
    id = uid;
}

void UniqueIDColor::print_compact(){
    cout << id;
}


bool UniqueIDColor::colorize_single_simplex(KSimplex* simp)
{
  bool outcome = true;
  UniqueIDColor* color = new(nothrow) UniqueIDColor();
  if (color==nullptr) {
    outcome = false;
    log_report(LOG_PANIC,"UniqueIDColor::colorize_single_simplex : PANIC!!! CANNOT ALLOCATE MEMORY!!!");
  }
  else simp->colors.push_back(color);
  return outcome;
}

bool UniqueIDColor::colorize_simplices_at_level(SimpComp* G, int level)
{
  bool outcome = true;
  bool temp;
  for (auto simplex : G->elements[level]) {
    temp = UniqueIDColor::colorize_single_simplex(simplex);
    if (!temp) outcome = false;
    }
  return outcome;
}

bool UniqueIDColor::colorize_entire_complex(SimpComp* G)
{
  bool outcome=true;
  bool temp;
  for (int level = 0; level <= G->D; level++) {
       temp = UniqueIDColor::colorize_simplices_at_level(G, level);
       if (!temp) outcome = false;
    }
  return outcome;
}

bool UniqueIDColor::is_colorized(KSimplex* simp)
{
  return Color::is_colorized_with_type(simp,TYPE_UNIQUE_ID);
}

bool UniqueIDColor::append_color_to_single_simplex(KSimplex* simp)
{
  bool outcome=true;
  if (UniqueIDColor::is_colorized(simp)) return true;
  else outcome = UniqueIDColor::colorize_single_simplex(simp);
  return outcome;
}

bool UniqueIDColor::append_color_to_simplices_at_level(SimpComp* G, int level)
{
  bool outcome = true;
  bool temp;
  for (auto simplex : G->elements[level]) {
    temp = UniqueIDColor::append_color_to_single_simplex(simplex);
    if (!temp) outcome = false;
    }
  return outcome;
}

bool UniqueIDColor::append_color_to_entire_complex(SimpComp* G)
{
  bool outcome=true;
  bool temp;
  for (int level = 0; level <= G->D; level++) {
       temp = UniqueIDColor::append_color_to_simplices_at_level(G, level);
       if (!temp) outcome = false;
    }

  return outcome;
}

bool UniqueIDColor::relabel_everything( void )
{
  bool outcome = true;
  unsigned long N=1;
  for (auto simpComp : triangulator_global::seededComplexes) {
    for (auto scelem : simpComp->elements) {
      for (auto ksimplex : scelem) {
	for (auto col : ksimplex->colors) {
	  if (col->type == TYPE_UNIQUE_ID) {
	    static_cast<UniqueIDColor*>(col)->id = N;
	    N++;
	  }
        }
      }
    }
  }
  UniqueIDColor::next_free_uid_number = N;

  return outcome;
}

string UniqueIDColor::get_color_value_as_str()
{
    return to_string(this->id);
}

void UniqueIDColor::set_color_value_from_str(const string& source) {
    id = stoi(source);
}








DrawingCoordinatesColor::DrawingCoordinatesColor(){
    type = TYPE_DRAWING_COORDINATES;
}

DrawingCoordinatesColor::~DrawingCoordinatesColor(){
}

bool DrawingCoordinatesColor::colorize_single_simplex(KSimplex* simp)
{
  // Check if the simplex is a vertex or not
  if(simp->k != 0){
    log_report(LOG_INFO,"This simplex is not a vertex, DrawingCoordinatesColor is meant only for vertices, skipping...");
    return true;
  }

  // Check if the simplex is already colorized
  if( DrawingCoordinatesColor::is_colorized(simp) ) return true;

  // Colorize the simplex
  DrawingCoordinatesColor* color = new(nothrow) DrawingCoordinatesColor();
  if (color==nullptr){
    log_report(LOG_PANIC,"DrawingCoordinatesColor::colorize_single_simplex : PANIC!!! CANNOT ALLOCATE MEMORY!!!");
    return false;
  }
  simp->colors.push_back(color);
  return true;
}

bool DrawingCoordinatesColor::colorize_single_simplex(KSimplex* simp, const string& source)
{
  bool outcome;
  DrawingCoordinatesColor *color;

  // Check if the simplex is a vertex or not
  if(simp->k != 0){
    log_report(LOG_INFO,"This simplex is not a vertex, DrawingCoordinatesColor is meant only for vertices, skipping...");
    return true;
  }
  
  // Colorize the simplex
  outcome = DrawingCoordinatesColor::colorize_single_simplex(simp);
  if (!outcome) {
    log_report(LOG_PANIC,"DrawingCoordinatesColor::colorize_single_simplex : PANIC!!! Failed to colorize the simplex!!!");
    return false;
  }
  
  // Find the pointer to the color
  color = DrawingCoordinatesColor::find_pointer_to_color(simp);
  if (color == nullptr){
    log_report(LOG_PANIC,"Could not assign DrawingCoordinatesColor to a simplex!!!");
    return false;
  }

  // Fill in the color values from the string
  color->set_color_value_from_str(source);
  return true;
}

bool DrawingCoordinatesColor::colorize_entire_complex(SimpComp* simpComp){
  bool outcome=true;
  bool temp;
  
  for(auto &simp : simpComp->elements[0]){
    temp = DrawingCoordinatesColor::colorize_single_simplex(simp);
    if (!temp) outcome = false;
  }
  return outcome;
}

bool DrawingCoordinatesColor::is_colorized(KSimplex* simp)
{
  return Color::is_colorized_with_type(simp,TYPE_DRAWING_COORDINATES);
}

DrawingCoordinatesColor* DrawingCoordinatesColor::find_pointer_to_color(KSimplex* simp)
{
  Color *temp = Color::find_pointer_to_color_type(simp, TYPE_DRAWING_COORDINATES);
  return static_cast<DrawingCoordinatesColor*>(temp);
}

void DrawingCoordinatesColor::print(){
  long unsigned int i;

  cout << "Intrinsic coordinates:  ";
  for(i = 0; i < q.size(); i++) cout << q[i] << "  ";
  cout << endl << "Embedding coordinates:  ";
  for(i = 0; i < x.size(); i++) cout << x[i] << "  ";
  cout << endl << "Ambient space dimension: Damb = " << Damb << endl;
}

string DrawingCoordinatesColor::double_to_string_with_precision(double number, int decdigits){
  stringstream ss;

  ss << std::fixed << std::setprecision(decdigits) << number;
  return ss.str();
}

string DrawingCoordinatesColor::get_color_value_as_str()
{
  long unsigned int i;
  // TODO:
  // Serialize vectors qMin and qMax?
  // Design the output that is good both for XML and for the GUI?

  // The output below is currently optimized for GUI only:
  string output;
  output = "Int: ( " + double_to_string_with_precision(q[0],2);
  for(i = 1; i < q.size(); i++)
    output += " , " + double_to_string_with_precision(q[i],2);
  output += " )";
  output += "<br>";
  output += "Emb: ( "
    + double_to_string_with_precision(x[0],2);
  for(i = 1; i < x.size(); i++)
    output += " , " + double_to_string_with_precision(x[i],2);
  output += " )";
  output += "<br>";
  output += "Emb dim: " + to_string(Damb); 

  return output;
}

void DrawingCoordinatesColor::set_color_value_from_str(const string& source) // TODO
{
  if (source=="true") return; // This is a dummy command, do not remove
  // deserialize vector q
  // deserialize vectors qMin and qMax?
  // deserialize vector x
  // deserialize Damb?
}









DrawingAnchorColor::DrawingAnchorColor(){
    type = TYPE_DRAWING_ANCHOR;
}

DrawingAnchorColor::~DrawingAnchorColor(){
}

bool DrawingAnchorColor::colorize_single_vertex(KSimplex* simp)
{
  DrawingAnchorColor* color = new(nothrow) DrawingAnchorColor();
  if(color == nullptr){
    log_report(LOG_PANIC,"DrawingAnchorColor::colorize_single_vertex : PANIC!!! CANNOT ALLOCATE MEMORY!!!");
    return false;
  }
  if(simp == nullptr){
    log_report(LOG_ERROR,"DrawingAnchorColor::colorize_single_vertex : You tried to colorize a nullptr, fix your code!");
    return false;
  }
  if(simp->k > 1){
    log_report(LOG_WARN,"DrawingAnchorColor::colorize_single_vertex : You are trying to colorize a non-vertex with drawing anchor color.");
    log_report(LOG_WARN,"DrawingAnchorColor::colorize_single_vertex : I will do it, but this is probably not what you intended.");
  }
  simp->colors.push_back(color);
  return true;
}

bool DrawingAnchorColor::colorize_vertices_of_simplex(KSimplex *simp)
{
  bool outcome = true;
  bool temp;
  for(auto vertex : simp->neighbors->elements[0]){
    temp = DrawingAnchorColor::colorize_single_vertex(vertex);
    if (!temp) outcome = false;
  }
  return outcome;
}

void DrawingAnchorColor::remove_color_from_vertex(KSimplex* simp)
{
  Color::remove_color_type_from_simplex(simp, TYPE_DRAWING_ANCHOR);
}

void DrawingAnchorColor::remove_color_from_simplex(KSimplex *simp)
{
  for(auto vertex : simp->neighbors->elements[0])
    DrawingAnchorColor::remove_color_from_vertex(vertex);
}

string DrawingAnchorColor::get_color_value_as_str()
{
    return "true";
}

void DrawingAnchorColor::set_color_value_from_str(const string& source)
{
  if (source=="true") return; // This is a dummy command, do not remove
}









VolumeSquaredColor::VolumeSquaredColor(){
    type = TYPE_VOLUME_SQUARED;
    // initial default values for any simplex:
    vsq = 1.0;
    vsqMin = 1.0;
    vsqMax = 1.0;
}

VolumeSquaredColor::~VolumeSquaredColor(){
}

bool VolumeSquaredColor::colorize_single_simplex(KSimplex* simp)
{

  // Check if the simplex is already colorized
  if( VolumeSquaredColor::is_colorized(simp) ) return true;
  
  // Colorize the simplex
  VolumeSquaredColor* color = new(nothrow) VolumeSquaredColor();
  if (color==nullptr){
    log_report(LOG_PANIC,"VolumeSquaredColor::colorize_single_simplex : PANIC!!! CANNOT ALLOCATE MEMORY!!!");
    return false;
  }
  simp->colors.push_back(color);
  return true;
}

bool VolumeSquaredColor::colorize_single_simplex(KSimplex* simp, const string& source)
{
  bool outcome;
  VolumeSquaredColor *color;
  
  // Colorize the simplex
  outcome = VolumeSquaredColor::colorize_single_simplex(simp);
  if (!outcome) {
    log_report(LOG_PANIC,"VolumeSquaredColor::colorize_single_simplex : PANIC!!! Failed to colorize the simplex!!!");
    return false;
  }
  
  // Find the pointer to the color
  color = VolumeSquaredColor::find_pointer_to_color(simp);
  if (color == nullptr){
    log_report(LOG_PANIC,"Could not assign VolumeSquaredColor to a simplex!!!");
    return false;
  }

  // Fill in the color values from the string
  color->set_color_value_from_str(source);
  return true;
}

bool VolumeSquaredColor::colorize_simplices_at_level(SimpComp* G, int level)
{
  bool outcome = true;
  bool temp;
  for (auto simplex : G->elements[level]) {
    temp = VolumeSquaredColor::colorize_single_simplex(simplex);
    if (!temp) outcome = false;
    }
  return outcome;
}

bool VolumeSquaredColor::colorize_entire_complex(SimpComp* G)
{
  bool outcome=true;
  bool temp;
  for (int level = 0; level <= G->D; level++) {
       temp = VolumeSquaredColor::colorize_simplices_at_level(G, level);
       if (!temp) outcome = false;
    }
  return outcome;
}

bool VolumeSquaredColor::is_colorized(KSimplex* simp)
{
  return Color::is_colorized_with_type(simp,TYPE_VOLUME_SQUARED);
}

VolumeSquaredColor* VolumeSquaredColor::find_pointer_to_color(KSimplex* simp)
{
  Color *temp = Color::find_pointer_to_color_type(simp, TYPE_VOLUME_SQUARED);
  return static_cast<VolumeSquaredColor*>(temp);
}

void VolumeSquaredColor::print()
{
  cout << "Squared volume: vsq = " << vsq << endl;
}

string VolumeSquaredColor::double_to_string_with_precision(double number, int decdigits){
  stringstream ss;

  ss << std::fixed << std::setprecision(decdigits) << number;
  return ss.str();
}

string VolumeSquaredColor::get_color_value_as_str()
{
  // TODO:
  // Serialize double vsq, vsqMin and vsqMax?
  // Design the output that is good both for XML and for the GUI?

  // The output below is currently optimized for GUI only:
  string output;
  output = "Vol^2: " + double_to_string_with_precision(vsq,2);
  return output;
}

void VolumeSquaredColor::set_color_value_from_str(const string& source) // TODO
{
  if (source=="true") return; // This is a dummy command, do not remove
  // deserialize vector q
  // deserialize vectors qMin and qMax?
  // deserialize vector x
  // deserialize Damb?
}








