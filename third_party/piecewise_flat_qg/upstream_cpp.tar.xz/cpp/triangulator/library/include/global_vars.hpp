
#ifndef TRIANGULATOR_GLOBAL_VARS_H_INCLUDED
#define TRIANGULATOR_GLOBAL_VARS_H_INCLUDED

using namespace std;

namespace triangulator_global{
  // Vector of all instantiated simplicial complexes:
  extern vector<SimpComp*> seededComplexes;

  // Default logging parameters:
  extern string logFilename;
  extern int logLevel;

  // Parameters governing the potential minimization function
  extern int potential_global_retries_number;
  extern int potential_max_iteration_number;
  extern int potential_max_test_coordinates;
  extern double potential_shake_step;
  extern long unsigned int potential_bitmask_linear_topology;
  extern long unsigned int potential_bitmask_sphere_topology;
  
  // Overall scale parameters for linear and sphere topologies
  extern double sphere_topology_drawing_radius;
  extern double linear_topology_drawing_domain_size;

  // Default constants for various potentials:
  extern double potential_spring_edge_interaction;
  extern double potential_spring_edge_length;
  extern double potential_spring_non_edge_interaction;
  extern double potential_spring_non_edge_length;
  extern double potential_inverse_distance_interaction;
  extern double potential_inverse_bounding_sphere_interaction;
  extern double potential_linear_well_interaction;

  //Constant that specifies the critical dimension of the determinant
  extern unsigned int critical_determinant_size;
}

#endif

