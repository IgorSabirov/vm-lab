#include "triangulator.hpp"
#include "symmetric_matrix_signature.hpp"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <random>
#include <string>
#include <vector>
#include <ctime>

int count_boundary_tetrahedra(SimpComp *triangulation){
    int boundary_tetrahedra = 0;

    for(auto tetrahedron : triangulation->elements[3])
        if(tetrahedron->is_a_boundary())
            boundary_tetrahedra++;

    return boundary_tetrahedra;
}

vector<int> vertex_indices(KSimplex *simplex, KSimplex *subsimplex){
    vector<int> indices;

    for(auto vertex : subsimplex->neighbors->elements[0]){
        for(int i = 0; i < (int)simplex->neighbors->elements[0].size(); i++){
            if(vertex == simplex->neighbors->elements[0][i]){
                indices.push_back(i);
                break;
            }
        }
    }

    sort(indices.begin(), indices.end());
    return indices;
}

KSimplex *find_subsimplex(KSimplex *simplex, int level, const vector<int> &indices){
    for(auto subsimplex : simplex->neighbors->elements[level])
        if(vertex_indices(simplex, subsimplex) == indices)
            return subsimplex;

    return nullptr;
}

double squared_edge_length(KSimplex *simplex, int i, int j){
    vector<int> indices = {i,j};
    sort(indices.begin(), indices.end());
    KSimplex *edge = find_subsimplex(simplex, 1, indices);
    return VolumeSquaredColor::find_pointer_to_color(edge)->vsq;
}

matrix_signature::Matrix metric_matrix(KSimplex *simplex,
                                       const vector<int> &indices){
    int dimension = indices.size() - 1;
    int reference = indices.back();
    matrix_signature::Matrix metric(dimension, vector<double>(dimension, 0.0));

    for(int i = 0; i < dimension; i++){
        double squared_length_i = squared_edge_length(simplex, indices[i], reference);
        metric[i][i] = squared_length_i > 0.0 ? 1.0 : -1.0;

        for(int j = i + 1; j < dimension; j++){
            double squared_length_j = squared_edge_length(simplex, indices[j], reference);
            double squared_length_ij = squared_edge_length(simplex, indices[i], indices[j]);
            metric[i][j] = (squared_length_i + squared_length_j - squared_length_ij)
                         / (2.0 * sqrt(fabs(squared_length_i))
                                * sqrt(fabs(squared_length_j)));
            metric[j][i] = metric[i][j];
        }
    }

    return metric;
}

matrix_signature::Signature metric_signature(KSimplex *simplex,
                                             const vector<int> &indices){
    matrix_signature::Matrix metric = metric_matrix(simplex, indices);
    return matrix_signature::calculate_matrix_signature_or_throw(metric);
}

string signature_string(const matrix_signature::Signature &signature){
    return "(" + to_string(signature.positive) + ";"
               + to_string(signature.negative) + ";"
               + to_string(signature.zero) + ")";
}

vector<vector<double>> cayley_menger_matrix_from_neighbors(KSimplex *simplex){
    vector<vector<double>> matrix = cayley_menger_matrix(simplex);

    for(int i = 0; i < simplex->k + 1; i++){
        for(int j = i + 1; j < simplex->k + 1; j++){
            vector<int> indices = {i,j};
            KSimplex *edge = find_subsimplex(simplex, 1, indices);
            VolumeSquaredColor *color = VolumeSquaredColor::find_pointer_to_color(edge);
            matrix[i][j] = color->vsq;
            matrix[j][i] = color->vsq;
        }
    }

    return matrix;
}

int determinant_sign(double determinant){
    if(fabs(determinant) < 1e-30)
        return 0;
    if(determinant > 0.0)
        return 1;
    return -1;
}

string face_name(const vector<int> &indices){
    string name;

    for(auto index : indices)
        name += to_string(index);

    return name;
}

int main(){
    int D = 4;
    // Production values:
    //    int desired_boundary_tetrahedra = 35000;
    int desired_four_simplices = 100000;

    // Small values for development and testing:
    //    int desired_boundary_tetrahedra = 350;
    //    int desired_four_simplices = 1000;

    std::random_device rd;
    std::seed_seq random_seed{rd(), rd(), rd(), rd(), rd(), rd(), rd(), rd()};

    srand(static_cast<unsigned int>(time(nullptr)));
    mt19937 generator(random_seed);
    triangulator_global::logLevel = LOG_ERROR;

    SimpComp *triangulation = seed_sphere(D, "4-sphere");

    /*
    while(count_boundary_tetrahedra(triangulation) <= desired_boundary_tetrahedra){
        int i = rand() % triangulation->elements[3].size();
        KSimplex *tetrahedron = triangulation->elements[3][i];

        if(tetrahedron->is_a_boundary())
            attach_new_simplex_to_boundary(tetrahedron, triangulation);
    }

    int FinalNumBoundTet = count_boundary_tetrahedra(triangulation);
    cout << "Constructed number of boundary tetrahedra: " << FinalNumBoundTet << endl;
    */
    
    std::uniform_real_distribution<double> pachner_range(0.6, 0.8);
    double pachner_coef = pachner_range(generator);
    
    while((int)triangulation->elements[4].size() <= pachner_coef * desired_four_simplices){
        int i = rand() % triangulation->elements[4].size();
        KSimplex *simplex = triangulation->elements[4][i];
        Pachner_move(simplex, triangulation);
    }

    cout << "Finished the loop for 1-to-5 Pachner moves" << endl;
        
    /* Alternative to the subsequent loop; enable only one of the two.
       This loop implements the truly random choice of a tetrahedron.
    while((int)triangulation->elements[4].size() <= desired_four_simplices){
        int i = rand() % triangulation->elements[3].size();
        KSimplex *tetrahedron = triangulation->elements[3][i];
        Pachner_move(tetrahedron, triangulation);
    }
    */
    /*
      This loop implements the optimal choice of a zeroth-tetrahedron.
    */
       while((int)triangulation->elements[4].size() <= desired_four_simplices){
        int i = rand() % triangulation->elements[4].size();
        KSimplex *simplex = triangulation->elements[4][i];
        KSimplex *tetrahedron = simplex->neighbors->elements[3][0];
        Pachner_move(tetrahedron, triangulation);
    }

    cout << "Finished the loop for 2-to-4 Pachner moves" << endl;
    cout << "The parameters of the resulting triangulation:" << endl;
    cout << "Total number of vertices   : " << triangulation->elements[0].size() << endl;
    cout << "Total number of edges      : " << triangulation->elements[1].size() << endl;
    cout << "Total number of triangles  : " << triangulation->elements[2].size() << endl;
    cout << "Total number of tetrahedra : " << triangulation->elements[3].size() << endl;
    cout << "Total number of 4-simplices: " << triangulation->elements[4].size() << endl << endl;

    vector<vector<int>> edge_order = {
        {0,1}, {0,2}, {0,3}, {0,4}, {1,2},
        {1,3}, {1,4}, {2,3}, {2,4}, {3,4}
    };
    vector<vector<int>> tetrahedron_order = {
        {0,1,2,3}, {0,1,2,4}, {0,1,3,4}, {0,2,3,4}, {1,2,3,4}
    };
    vector<vector<int>> triangle_order = {
        {0,1,2}, {0,1,3}, {0,1,4}, {0,2,3}, {0,2,4},
        {0,3,4}, {1,2,3}, {1,2,4}, {1,3,4}, {2,3,4}
    };
    vector<int> simplex_indices = {0,1,2,3,4};

    VolumeSquaredColor::colorize_entire_complex(triangulation);

    for(int run = 0; run < 10; run++){
    for(int domain = 0; domain < 30; domain++){
      int domaintype = domain / 10;
      int domainscale = domain % 10;
      
        double minimum_length = domainscale;
        double maximum_length = 10.0;
        uniform_real_distribution<double> random_length(minimum_length, maximum_length);
        bernoulli_distribution random_spacelike(0.5);

        for(auto edge : triangulation->elements[1]){
            double length;
            do{
                length = random_length(generator);
            } while(length == 0.0);

	    bool timelike = false;
	    if(domaintype == 0) timelike = false;
	    if(domaintype == 1) timelike = true;
            if(domaintype == 2) timelike = !random_spacelike(generator);

            VolumeSquaredColor *color = VolumeSquaredColor::find_pointer_to_color(edge);
            color->vsq = timelike ? -length * length : length * length;
	    color->vsqMin = 0.0;
            color->vsqMax = 100.0;
        }

        for(int n = 0; n <= D; n++){
            if(n == 1)
                continue;

            for(auto simplex : triangulation->elements[n]){
                VolumeSquaredColor *color = VolumeSquaredColor::find_pointer_to_color(simplex);
                vector<vector<double>> matrix = cayley_menger_matrix_from_neighbors(simplex);
                color->vsqMin = 0.0;
                color->vsqMax = 0.0;
                color->vsq = real_valued_determinant(&matrix);
            }
        }

	string domaintypestr;
        if(domaintype == 0) domaintypestr = "spacelike";
        if(domaintype == 1) domaintypestr = "timelike";
        if(domaintype == 2) domaintypestr = "mixed";

	string domainscalestr = to_string(domainscale);
	
        string filename="Sphere---run-"+to_string(run)+"---"+domaintypestr+"-domain---cutoff-"+domainscalestr+".csv";

	cout << "Generating file: " << filename << endl;
	
        ofstream output(filename);
        output << setprecision(17);
        output << "CM4Sign,Metric4Signature";

        for(int i = 0; i < (int)tetrahedron_order.size(); i++){
            string name = face_name(tetrahedron_order[i]);
            output << ",Tetrahedron" << i + 1 << "_" << name << "_CMSign"
                   << ",Tetrahedron" << i + 1 << "_" << name << "_Signature";
        }

        for(int i = 0; i < (int)triangle_order.size(); i++){
            string name = face_name(triangle_order[i]);
            output << ",Triangle" << i + 1 << "_" << name << "_CMSign"
                   << ",Triangle" << i + 1 << "_" << name << "_Signature";
        }

        output << ",EdgeLengths";
        for(auto indices : edge_order)
            output << "_" << face_name(indices);
        output << '\n';

        for(auto simplex : triangulation->elements[4]){
            VolumeSquaredColor *color = VolumeSquaredColor::find_pointer_to_color(simplex);
            matrix_signature::Signature signature = metric_signature(simplex, simplex_indices);
            output << determinant_sign(color->vsq) << ","
                   << signature_string(signature) << ",";

            for(auto indices : tetrahedron_order){
                KSimplex *tetrahedron = find_subsimplex(simplex, 3, indices);
                color = VolumeSquaredColor::find_pointer_to_color(tetrahedron);
                signature = metric_signature(simplex, indices);
                output << determinant_sign(color->vsq) << ","
                       << signature_string(signature) << ",";
            }

            for(auto indices : triangle_order){
                KSimplex *triangle = find_subsimplex(simplex, 2, indices);
                color = VolumeSquaredColor::find_pointer_to_color(triangle);
                signature = metric_signature(simplex, indices);
                output << determinant_sign(color->vsq) << ","
                       << signature_string(signature) << ",";
            }

            for(int i = 0; i < (int)edge_order.size(); i++){
                KSimplex *edge = find_subsimplex(simplex, 1, edge_order[i]);
                color = VolumeSquaredColor::find_pointer_to_color(edge);
                if(i > 0)
                    output << ";";
                output << sqrt(fabs(color->vsq));
                if(color->vsq < 0.0)
                    output << "*I";
            }
            output << '\n';
        }
    }
    }

    unseed_everything();
    return 0;
}
