
This C++ source tree produces three static executables,

  ball-generator
  sphere-generator
  simplex-generator

each of which (1) constructs a triangulation of a 4-dimensional manifold
of appropriate size for the corresponding topology, and (2) generates a
number of .csv files by putting randomly chosen edge lengths on the
triangulation and evaluating the metric signature and the Cayley-Menger
determinant for all simplices in the triangulation. The .csv files have
appropriate title line explaining the column data, and have descriptive
filenames.

The data from the .csv files can then be distilled further using the
Wolfram Mathematica notebooks (provided in the separate directory).

The source is set up to be built using CMake. Simply do the following:

  mkdir my_build_dir
  cmake -B my_build_dir
  cmake --build my_build_dir

After the build, the three executables can be found in my_build_dir. You
can transfer each to its target directory, and run it. Depending on your
hardware, it can take several hours to finish.

Each executable logs the stages of its work to stdout as it goes, so the
user can keep track of its progress. The stdout can of course be
redirected into a file, as needed.

Each executable produces *a lot* of large .csv files, and drops them in
the current directory. Make sure you have hundreds of GiB of free
storage available, to accommodate all generated files.

Running multiple instances of the executables will correspond to different
triangulations of the 4-manifold, since the triangulation is randomly
generated each time, no two triangulations will be the same.

For any questions or comments, feel free to send us an e-mail. ;-)

Cheers, :-)

Mihailo Djordjevic
Igor Prlina
Marko Vojinovic

